﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReservation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReservation))
        Dim Style1 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style2 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style3 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style4 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style5 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style6 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style7 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style8 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style9 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style10 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style11 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style12 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style13 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style14 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style15 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style16 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Me.txtReservationNo = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.chkBlockLetters = New System.Windows.Forms.CheckBox
        Me.cmbProject = New C1.Win.C1List.C1Combo
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtReservationDate = New C1.Win.C1Input.C1DateEdit
        Me.cmdAdd = New System.Windows.Forms.Button
        Me.cmdExit = New System.Windows.Forms.Button
        Me.cmdUndo = New System.Windows.Forms.Button
        Me.cmdSearch = New System.Windows.Forms.Button
        Me.cmdEdit = New System.Windows.Forms.Button
        Me.cmdSave = New System.Windows.Forms.Button
        Me.cmdDelete = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cmdClearApplicant = New System.Windows.Forms.Button
        Me.txtCustomerEmail2 = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.cmdCustomerList2 = New System.Windows.Forms.Button
        Me.txtCustomerNIC2 = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtCustomerMobile2 = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtCustomerTel2 = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtCustomerName2 = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.txtCustomerCode2 = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtCustomerEmail1 = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.cmdCustomerList1 = New System.Windows.Forms.Button
        Me.Label16 = New System.Windows.Forms.Label
        Me.txtCustomerNIC1 = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.txtCustomerMobile1 = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtCustomerTel1 = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtCustomerName1 = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtCustomerCode1 = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label46 = New System.Windows.Forms.Label
        Me.txtNoofMonths = New C1.Win.C1Input.C1NumericEdit
        Me.txtOfficialService = New C1.Win.C1Input.C1NumericEdit
        Me.Label44 = New System.Windows.Forms.Label
        Me.txtOfficialCash = New C1.Win.C1Input.C1NumericEdit
        Me.Label45 = New System.Windows.Forms.Label
        Me.chkNonActive = New System.Windows.Forms.CheckBox
        Me.cmdAgent = New System.Windows.Forms.Button
        Me.cmbAgent = New C1.Win.C1List.C1Combo
        Me.Label43 = New System.Windows.Forms.Label
        Me.cmbAreaIn = New System.Windows.Forms.ComboBox
        Me.chkApplyExtraLand = New System.Windows.Forms.CheckBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.txtExtraSqFeetYds = New C1.Win.C1Input.C1NumericEdit
        Me.Label41 = New System.Windows.Forms.Label
        Me.txtPerSqFeetCharges = New C1.Win.C1Input.C1NumericEdit
        Me.Label40 = New System.Windows.Forms.Label
        Me.txtExtraLandCharges = New C1.Win.C1Input.C1NumericEdit
        Me.lblRefundPaid = New System.Windows.Forms.Label
        Me.txtRefundPaid = New C1.Win.C1Input.C1NumericEdit
        Me.lblRefundAmount = New System.Windows.Forms.Label
        Me.txtRefundAmount = New C1.Win.C1Input.C1NumericEdit
        Me.Label39 = New System.Windows.Forms.Label
        Me.txtPenaltyPer = New C1.Win.C1Input.C1NumericEdit
        Me.Label38 = New System.Windows.Forms.Label
        Me.txtCreditDays = New C1.Win.C1Input.C1NumericEdit
        Me.Label36 = New System.Windows.Forms.Label
        Me.txtAddOtherCharges = New C1.Win.C1Input.C1NumericEdit
        Me.Label35 = New System.Windows.Forms.Label
        Me.txtCancelCharges = New C1.Win.C1Input.C1NumericEdit
        Me.Label34 = New System.Windows.Forms.Label
        Me.txtCancelDate = New C1.Win.C1Input.C1DateEdit
        Me.chkCancel = New System.Windows.Forms.CheckBox
        Me.cmdScheme = New System.Windows.Forms.Button
        Me.cmbScheme = New C1.Win.C1List.C1Combo
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.txtDiscount = New C1.Win.C1Input.C1NumericEdit
        Me.cmdPickPlan = New System.Windows.Forms.Button
        Me.Label29 = New System.Windows.Forms.Label
        Me.txtExtraCharges = New C1.Win.C1Input.C1NumericEdit
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.txtTotalRevenue = New C1.Win.C1Input.C1NumericEdit
        Me.txtLoanAmount = New C1.Win.C1Input.C1NumericEdit
        Me.txtCashAmount = New C1.Win.C1Input.C1NumericEdit
        Me.cmdStandardPaymentPlan = New System.Windows.Forms.Button
        Me.Label19 = New System.Windows.Forms.Label
        Me.txtStandardPlanNo = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.cmbPaymentPlan = New System.Windows.Forms.ComboBox
        Me.cmdUnitType = New System.Windows.Forms.Button
        Me.cmbUnitType = New C1.Win.C1List.C1Combo
        Me.Label27 = New System.Windows.Forms.Label
        Me.cmdUnit = New System.Windows.Forms.Button
        Me.cmbUnit = New C1.Win.C1List.C1Combo
        Me.Label21 = New System.Windows.Forms.Label
        Me.tdbPaymentType = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.tdbGridPaymentPlan = New C1.Win.C1TrueDBGrid.C1TrueDBGrid
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.txtLastPaymentDate = New C1.Win.C1Input.C1DateEdit
        Me.cmdRescheduleAdd = New System.Windows.Forms.Button
        Me.cmdRescheduleDelete = New System.Windows.Forms.Button
        Me.txtDelayDays = New C1.Win.C1Input.C1NumericEdit
        Me.Label32 = New System.Windows.Forms.Label
        Me.cmdClear = New System.Windows.Forms.Button
        Me.cmdExtraCharges = New System.Windows.Forms.Button
        Me.cmbExtraCharges = New C1.Win.C1List.C1Combo
        Me.Label30 = New System.Windows.Forms.Label
        Me.cmdDeletePlan = New System.Windows.Forms.Button
        Me.cmdUpdate = New System.Windows.Forms.Button
        Me.chkNotDecided = New System.Windows.Forms.CheckBox
        Me.cmdGenerate = New System.Windows.Forms.Button
        Me.txtDueDays = New C1.Win.C1Input.C1NumericEdit
        Me.Label20 = New System.Windows.Forms.Label
        Me.txtInstallments = New C1.Win.C1Input.C1NumericEdit
        Me.Label22 = New System.Windows.Forms.Label
        Me.txtAmount = New C1.Win.C1Input.C1NumericEdit
        Me.Label23 = New System.Windows.Forms.Label
        Me.cmbPaymentType = New C1.Win.C1List.C1Combo
        Me.Label24 = New System.Windows.Forms.Label
        Me.tdbExtraCharges = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.chkAuthorityLetter = New System.Windows.Forms.CheckBox
        Me.chkPhotograph = New System.Windows.Forms.CheckBox
        Me.chkPassport = New System.Windows.Forms.CheckBox
        Me.chkNICMakingBooking = New System.Windows.Forms.CheckBox
        Me.chkCustomerNIC = New System.Windows.Forms.CheckBox
        Me.cmdPrint = New System.Windows.Forms.Button
        Me.cmdPreview = New System.Windows.Forms.Button
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.cmbProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtReservationDate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.txtNoofMonths, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtOfficialService, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtOfficialCash, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbAgent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtExtraSqFeetYds, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPerSqFeetCharges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtExtraLandCharges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtRefundPaid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtRefundAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPenaltyPer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCreditDays, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAddOtherCharges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCancelCharges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCancelDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbScheme, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDiscount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtExtraCharges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTotalRevenue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLoanAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCashAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbUnitType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbUnit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbPaymentType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbGridPaymentPlan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.txtLastPaymentDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDelayDays, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDueDays, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtInstallments, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbPaymentType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbExtraCharges, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtReservationNo
        '
        Me.txtReservationNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtReservationNo.Location = New System.Drawing.Point(101, 12)
        Me.txtReservationNo.Name = "txtReservationNo"
        Me.txtReservationNo.Size = New System.Drawing.Size(100, 20)
        Me.txtReservationNo.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Reservation #"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1})
        Me.ToolStrip1.Location = New System.Drawing.Point(2, 4)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(833, 56)
        Me.ToolStrip1.TabIndex = 112
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Trebuchet MS", 24.0!, System.Drawing.FontStyle.Bold)
        Me.ToolStripLabel1.ForeColor = System.Drawing.SystemColors.Desktop
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(312, 53)
        Me.ToolStripLabel1.Text = "RESERVATION FORM"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkBlockLetters)
        Me.GroupBox2.Controls.Add(Me.cmbProject)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtReservationDate)
        Me.GroupBox2.Controls.Add(Me.txtReservationNo)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 59)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(389, 102)
        Me.GroupBox2.TabIndex = 113
        Me.GroupBox2.TabStop = False
        '
        'chkBlockLetters
        '
        Me.chkBlockLetters.AutoSize = True
        Me.chkBlockLetters.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBlockLetters.Location = New System.Drawing.Point(12, 70)
        Me.chkBlockLetters.Name = "chkBlockLetters"
        Me.chkBlockLetters.Size = New System.Drawing.Size(88, 17)
        Me.chkBlockLetters.TabIndex = 239
        Me.chkBlockLetters.Text = "Block Letters"
        Me.chkBlockLetters.UseVisualStyleBackColor = True
        '
        'cmbProject
        '
        Me.cmbProject.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbProject.Caption = ""
        Me.cmbProject.CaptionHeight = 17
        Me.cmbProject.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbProject.ColumnCaptionHeight = 17
        Me.cmbProject.ColumnFooterHeight = 17
        Me.cmbProject.ContentHeight = 15
        Me.cmbProject.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbProject.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbProject.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProject.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbProject.EditorHeight = 15
        Me.cmbProject.Images.Add(CType(resources.GetObject("cmbProject.Images"), System.Drawing.Image))
        Me.cmbProject.ItemHeight = 15
        Me.cmbProject.Location = New System.Drawing.Point(101, 35)
        Me.cmbProject.MatchEntryTimeout = CType(2000, Long)
        Me.cmbProject.MaxDropDownItems = CType(5, Short)
        Me.cmbProject.MaxLength = 32767
        Me.cmbProject.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbProject.Name = "cmbProject"
        Me.cmbProject.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbProject.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbProject.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbProject.Size = New System.Drawing.Size(278, 21)
        Me.cmbProject.TabIndex = 237
        Me.cmbProject.PropBag = resources.GetString("cmbProject.PropBag")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 238
        Me.Label3.Text = "Project"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(211, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 196
        Me.Label2.Text = "Date"
        '
        'txtReservationDate
        '
        Me.txtReservationDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtReservationDate.Calendar.AnnuallyBoldedDates = New Date(-1) {}
        Me.txtReservationDate.Calendar.BoldedDates = New Date(-1) {}
        Me.txtReservationDate.Calendar.ClearText = "&Clear"
        Me.txtReservationDate.Calendar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReservationDate.Calendar.Margin = New System.Windows.Forms.Padding(0)
        Me.txtReservationDate.Calendar.MonthlyBoldedDates = New Date(-1) {}
        Me.txtReservationDate.Calendar.SelectedDate = New Date(2008, 7, 11, 0, 0, 0, 0)
        Me.txtReservationDate.Calendar.TodayText = "&Today"
        Me.txtReservationDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.System
        Me.txtReservationDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.System
        Me.txtReservationDate.Culture = 1056
        Me.txtReservationDate.CustomFormat = "dd/MM/yyyy"
        Me.txtReservationDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtReservationDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtReservationDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReservationDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtReservationDate.Location = New System.Drawing.Point(253, 11)
        Me.txtReservationDate.Name = "txtReservationDate"
        Me.txtReservationDate.Size = New System.Drawing.Size(126, 19)
        Me.txtReservationDate.TabIndex = 195
        Me.txtReservationDate.Tag = Nothing
        Me.txtReservationDate.TrimEnd = False
        Me.txtReservationDate.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtReservationDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtReservationDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'cmdAdd
        '
        Me.cmdAdd.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdAdd.Image = Global.General_Ledger.My.Resources.Resources.folder_add
        Me.cmdAdd.Location = New System.Drawing.Point(521, 4)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(51, 56)
        Me.cmdAdd.TabIndex = 0
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdAdd.UseVisualStyleBackColor = True
        '
        'cmdExit
        '
        Me.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdExit.Image = Global.General_Ledger.My.Resources.Resources.folder_out
        Me.cmdExit.Location = New System.Drawing.Point(779, 4)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(51, 56)
        Me.cmdExit.TabIndex = 7
        Me.cmdExit.Text = "E&xit"
        Me.cmdExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdExit.UseVisualStyleBackColor = True
        '
        'cmdUndo
        '
        Me.cmdUndo.Image = Global.General_Ledger.My.Resources.Resources.folder_refresh
        Me.cmdUndo.Location = New System.Drawing.Point(728, 4)
        Me.cmdUndo.Name = "cmdUndo"
        Me.cmdUndo.Size = New System.Drawing.Size(51, 56)
        Me.cmdUndo.TabIndex = 5
        Me.cmdUndo.Text = "&Undo"
        Me.cmdUndo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdUndo.UseVisualStyleBackColor = True
        '
        'cmdSearch
        '
        Me.cmdSearch.Image = Global.General_Ledger.My.Resources.Resources.folder_view
        Me.cmdSearch.Location = New System.Drawing.Point(469, 4)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.Size = New System.Drawing.Size(51, 56)
        Me.cmdSearch.TabIndex = 1
        Me.cmdSearch.Text = "Searc&h"
        Me.cmdSearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdSearch.UseVisualStyleBackColor = True
        '
        'cmdEdit
        '
        Me.cmdEdit.Image = Global.General_Ledger.My.Resources.Resources.folder_edit
        Me.cmdEdit.Location = New System.Drawing.Point(573, 4)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(51, 56)
        Me.cmdEdit.TabIndex = 2
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdEdit.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Image = Global.General_Ledger.My.Resources.Resources.folder_new
        Me.cmdSave.Location = New System.Drawing.Point(625, 4)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(51, 56)
        Me.cmdSave.TabIndex = 2
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cmdDelete
        '
        Me.cmdDelete.Image = Global.General_Ledger.My.Resources.Resources.folder_delete
        Me.cmdDelete.Location = New System.Drawing.Point(676, 4)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(51, 56)
        Me.cmdDelete.TabIndex = 4
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdDelete.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmdClearApplicant)
        Me.GroupBox1.Controls.Add(Me.txtCustomerEmail2)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.cmdCustomerList2)
        Me.GroupBox1.Controls.Add(Me.txtCustomerNIC2)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.txtCustomerMobile2)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.txtCustomerTel2)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.txtCustomerName2)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.txtCustomerCode2)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.txtCustomerEmail1)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.cmdCustomerList1)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.txtCustomerNIC1)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtCustomerMobile1)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtCustomerTel1)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtCustomerName1)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtCustomerCode1)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(4, 161)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(831, 141)
        Me.GroupBox1.TabIndex = 114
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Customer Information"
        '
        'cmdClearApplicant
        '
        Me.cmdClearApplicant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClearApplicant.Location = New System.Drawing.Point(642, 30)
        Me.cmdClearApplicant.Name = "cmdClearApplicant"
        Me.cmdClearApplicant.Size = New System.Drawing.Size(39, 23)
        Me.cmdClearApplicant.TabIndex = 259
        Me.cmdClearApplicant.Text = "Clear"
        Me.cmdClearApplicant.UseVisualStyleBackColor = True
        '
        'txtCustomerEmail2
        '
        Me.txtCustomerEmail2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomerEmail2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerEmail2.Location = New System.Drawing.Point(517, 117)
        Me.txtCustomerEmail2.Name = "txtCustomerEmail2"
        Me.txtCustomerEmail2.ReadOnly = True
        Me.txtCustomerEmail2.Size = New System.Drawing.Size(302, 20)
        Me.txtCustomerEmail2.TabIndex = 258
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(425, 120)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(32, 13)
        Me.Label11.TabIndex = 257
        Me.Label11.Text = "Email"
        '
        'cmdCustomerList2
        '
        Me.cmdCustomerList2.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdCustomerList2.Image = Global.General_Ledger.My.Resources.Resources.Find_Small
        Me.cmdCustomerList2.Location = New System.Drawing.Point(620, 32)
        Me.cmdCustomerList2.Name = "cmdCustomerList2"
        Me.cmdCustomerList2.Size = New System.Drawing.Size(22, 21)
        Me.cmdCustomerList2.TabIndex = 256
        Me.cmdCustomerList2.UseVisualStyleBackColor = True
        '
        'txtCustomerNIC2
        '
        Me.txtCustomerNIC2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomerNIC2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerNIC2.Location = New System.Drawing.Point(694, 96)
        Me.txtCustomerNIC2.Name = "txtCustomerNIC2"
        Me.txtCustomerNIC2.ReadOnly = True
        Me.txtCustomerNIC2.Size = New System.Drawing.Size(125, 20)
        Me.txtCustomerNIC2.TabIndex = 255
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(653, 99)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(35, 13)
        Me.Label12.TabIndex = 254
        Me.Label12.Text = "NIC #"
        '
        'txtCustomerMobile2
        '
        Me.txtCustomerMobile2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomerMobile2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerMobile2.Location = New System.Drawing.Point(517, 96)
        Me.txtCustomerMobile2.Name = "txtCustomerMobile2"
        Me.txtCustomerMobile2.ReadOnly = True
        Me.txtCustomerMobile2.Size = New System.Drawing.Size(125, 20)
        Me.txtCustomerMobile2.TabIndex = 253
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(425, 99)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 13)
        Me.Label13.TabIndex = 252
        Me.Label13.Text = "Mobile #"
        '
        'txtCustomerTel2
        '
        Me.txtCustomerTel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomerTel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerTel2.Location = New System.Drawing.Point(517, 75)
        Me.txtCustomerTel2.Name = "txtCustomerTel2"
        Me.txtCustomerTel2.ReadOnly = True
        Me.txtCustomerTel2.Size = New System.Drawing.Size(302, 20)
        Me.txtCustomerTel2.TabIndex = 251
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(425, 78)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(35, 13)
        Me.Label14.TabIndex = 250
        Me.Label14.Text = "Tel # "
        '
        'txtCustomerName2
        '
        Me.txtCustomerName2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomerName2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerName2.Location = New System.Drawing.Point(517, 54)
        Me.txtCustomerName2.Name = "txtCustomerName2"
        Me.txtCustomerName2.ReadOnly = True
        Me.txtCustomerName2.Size = New System.Drawing.Size(302, 20)
        Me.txtCustomerName2.TabIndex = 249
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(425, 57)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(82, 13)
        Me.Label15.TabIndex = 248
        Me.Label15.Text = "Customer Name"
        '
        'txtCustomerCode2
        '
        Me.txtCustomerCode2.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtCustomerCode2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerCode2.Location = New System.Drawing.Point(517, 32)
        Me.txtCustomerCode2.Name = "txtCustomerCode2"
        Me.txtCustomerCode2.ReadOnly = True
        Me.txtCustomerCode2.Size = New System.Drawing.Size(100, 20)
        Me.txtCustomerCode2.TabIndex = 247
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(425, 35)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(79, 13)
        Me.Label18.TabIndex = 246
        Me.Label18.Text = "Customer Code"
        '
        'txtCustomerEmail1
        '
        Me.txtCustomerEmail1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomerEmail1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerEmail1.Location = New System.Drawing.Point(100, 118)
        Me.txtCustomerEmail1.Name = "txtCustomerEmail1"
        Me.txtCustomerEmail1.ReadOnly = True
        Me.txtCustomerEmail1.Size = New System.Drawing.Size(317, 20)
        Me.txtCustomerEmail1.TabIndex = 245
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(8, 121)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(32, 13)
        Me.Label17.TabIndex = 244
        Me.Label17.Text = "Email"
        '
        'cmdCustomerList1
        '
        Me.cmdCustomerList1.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdCustomerList1.Image = Global.General_Ledger.My.Resources.Resources.Find_Small
        Me.cmdCustomerList1.Location = New System.Drawing.Point(203, 32)
        Me.cmdCustomerList1.Name = "cmdCustomerList1"
        Me.cmdCustomerList1.Size = New System.Drawing.Size(22, 21)
        Me.cmdCustomerList1.TabIndex = 242
        Me.cmdCustomerList1.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Blue
        Me.Label16.Location = New System.Drawing.Point(423, 17)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(71, 13)
        Me.Label16.TabIndex = 12
        Me.Label16.Text = "Applicant 2"
        '
        'txtCustomerNIC1
        '
        Me.txtCustomerNIC1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomerNIC1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerNIC1.Location = New System.Drawing.Point(292, 96)
        Me.txtCustomerNIC1.Name = "txtCustomerNIC1"
        Me.txtCustomerNIC1.ReadOnly = True
        Me.txtCustomerNIC1.Size = New System.Drawing.Size(125, 20)
        Me.txtCustomerNIC1.TabIndex = 11
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(251, 99)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 13)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "NIC #"
        '
        'txtCustomerMobile1
        '
        Me.txtCustomerMobile1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomerMobile1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerMobile1.Location = New System.Drawing.Point(100, 96)
        Me.txtCustomerMobile1.Name = "txtCustomerMobile1"
        Me.txtCustomerMobile1.ReadOnly = True
        Me.txtCustomerMobile1.Size = New System.Drawing.Size(125, 20)
        Me.txtCustomerMobile1.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(8, 99)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Mobile #"
        '
        'txtCustomerTel1
        '
        Me.txtCustomerTel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomerTel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerTel1.Location = New System.Drawing.Point(100, 75)
        Me.txtCustomerTel1.Name = "txtCustomerTel1"
        Me.txtCustomerTel1.ReadOnly = True
        Me.txtCustomerTel1.Size = New System.Drawing.Size(317, 20)
        Me.txtCustomerTel1.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(8, 78)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(35, 13)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Tel # "
        '
        'txtCustomerName1
        '
        Me.txtCustomerName1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtCustomerName1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerName1.Location = New System.Drawing.Point(100, 54)
        Me.txtCustomerName1.Name = "txtCustomerName1"
        Me.txtCustomerName1.ReadOnly = True
        Me.txtCustomerName1.Size = New System.Drawing.Size(317, 20)
        Me.txtCustomerName1.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(8, 57)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(82, 13)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Customer Name"
        '
        'txtCustomerCode1
        '
        Me.txtCustomerCode1.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtCustomerCode1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerCode1.Location = New System.Drawing.Point(100, 32)
        Me.txtCustomerCode1.Name = "txtCustomerCode1"
        Me.txtCustomerCode1.ReadOnly = True
        Me.txtCustomerCode1.Size = New System.Drawing.Size(100, 20)
        Me.txtCustomerCode1.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 35)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Customer Code"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Blue
        Me.Label5.Location = New System.Drawing.Point(8, 17)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Applicant 1"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label46)
        Me.GroupBox3.Controls.Add(Me.txtNoofMonths)
        Me.GroupBox3.Controls.Add(Me.txtOfficialService)
        Me.GroupBox3.Controls.Add(Me.Label44)
        Me.GroupBox3.Controls.Add(Me.txtOfficialCash)
        Me.GroupBox3.Controls.Add(Me.Label45)
        Me.GroupBox3.Controls.Add(Me.chkNonActive)
        Me.GroupBox3.Controls.Add(Me.cmdAgent)
        Me.GroupBox3.Controls.Add(Me.cmbAgent)
        Me.GroupBox3.Controls.Add(Me.Label43)
        Me.GroupBox3.Controls.Add(Me.cmbAreaIn)
        Me.GroupBox3.Controls.Add(Me.chkApplyExtraLand)
        Me.GroupBox3.Controls.Add(Me.Label42)
        Me.GroupBox3.Controls.Add(Me.txtExtraSqFeetYds)
        Me.GroupBox3.Controls.Add(Me.Label41)
        Me.GroupBox3.Controls.Add(Me.txtPerSqFeetCharges)
        Me.GroupBox3.Controls.Add(Me.Label40)
        Me.GroupBox3.Controls.Add(Me.txtExtraLandCharges)
        Me.GroupBox3.Controls.Add(Me.lblRefundPaid)
        Me.GroupBox3.Controls.Add(Me.txtRefundPaid)
        Me.GroupBox3.Controls.Add(Me.lblRefundAmount)
        Me.GroupBox3.Controls.Add(Me.txtRefundAmount)
        Me.GroupBox3.Controls.Add(Me.Label39)
        Me.GroupBox3.Controls.Add(Me.txtPenaltyPer)
        Me.GroupBox3.Controls.Add(Me.Label38)
        Me.GroupBox3.Controls.Add(Me.txtCreditDays)
        Me.GroupBox3.Controls.Add(Me.Label36)
        Me.GroupBox3.Controls.Add(Me.txtAddOtherCharges)
        Me.GroupBox3.Controls.Add(Me.Label35)
        Me.GroupBox3.Controls.Add(Me.txtCancelCharges)
        Me.GroupBox3.Controls.Add(Me.Label34)
        Me.GroupBox3.Controls.Add(Me.txtCancelDate)
        Me.GroupBox3.Controls.Add(Me.chkCancel)
        Me.GroupBox3.Controls.Add(Me.cmdScheme)
        Me.GroupBox3.Controls.Add(Me.cmbScheme)
        Me.GroupBox3.Controls.Add(Me.Label33)
        Me.GroupBox3.Controls.Add(Me.Label31)
        Me.GroupBox3.Controls.Add(Me.txtDiscount)
        Me.GroupBox3.Controls.Add(Me.cmdPickPlan)
        Me.GroupBox3.Controls.Add(Me.Label29)
        Me.GroupBox3.Controls.Add(Me.txtExtraCharges)
        Me.GroupBox3.Controls.Add(Me.Label25)
        Me.GroupBox3.Controls.Add(Me.Label26)
        Me.GroupBox3.Controls.Add(Me.Label28)
        Me.GroupBox3.Controls.Add(Me.txtTotalRevenue)
        Me.GroupBox3.Controls.Add(Me.txtLoanAmount)
        Me.GroupBox3.Controls.Add(Me.txtCashAmount)
        Me.GroupBox3.Controls.Add(Me.cmdStandardPaymentPlan)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.txtStandardPlanNo)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.cmbPaymentPlan)
        Me.GroupBox3.Controls.Add(Me.cmdUnitType)
        Me.GroupBox3.Controls.Add(Me.cmbUnitType)
        Me.GroupBox3.Controls.Add(Me.Label27)
        Me.GroupBox3.Controls.Add(Me.cmdUnit)
        Me.GroupBox3.Controls.Add(Me.cmbUnit)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(3, 301)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(834, 185)
        Me.GroupBox3.TabIndex = 115
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Unit Details"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(309, 89)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(42, 13)
        Me.Label46.TabIndex = 307
        Me.Label46.Text = "Months"
        '
        'txtNoofMonths
        '
        Me.txtNoofMonths.AutoSize = False
        Me.txtNoofMonths.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNoofMonths.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtNoofMonths.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtNoofMonths.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtNoofMonths.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoofMonths.Location = New System.Drawing.Point(352, 85)
        Me.txtNoofMonths.Name = "txtNoofMonths"
        Me.txtNoofMonths.Size = New System.Drawing.Size(51, 20)
        Me.txtNoofMonths.TabIndex = 306
        Me.txtNoofMonths.Tag = Nothing
        Me.txtNoofMonths.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtNoofMonths.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtNoofMonths.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtNoofMonths.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtNoofMonths.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'txtOfficialService
        '
        Me.txtOfficialService.AutoSize = False
        Me.txtOfficialService.BackColor = System.Drawing.Color.White
        Me.txtOfficialService.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOfficialService.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtOfficialService.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtOfficialService.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtOfficialService.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOfficialService.Location = New System.Drawing.Point(551, 158)
        Me.txtOfficialService.Name = "txtOfficialService"
        Me.txtOfficialService.Size = New System.Drawing.Size(42, 20)
        Me.txtOfficialService.TabIndex = 305
        Me.txtOfficialService.Tag = Nothing
        Me.txtOfficialService.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtOfficialService.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtOfficialService.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtOfficialService.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtOfficialService.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(471, 161)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(78, 13)
        Me.Label44.TabIndex = 304
        Me.Label44.Text = "Official Service"
        '
        'txtOfficialCash
        '
        Me.txtOfficialCash.AutoSize = False
        Me.txtOfficialCash.BackColor = System.Drawing.Color.White
        Me.txtOfficialCash.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOfficialCash.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtOfficialCash.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtOfficialCash.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtOfficialCash.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOfficialCash.Location = New System.Drawing.Point(430, 158)
        Me.txtOfficialCash.Name = "txtOfficialCash"
        Me.txtOfficialCash.Size = New System.Drawing.Size(38, 20)
        Me.txtOfficialCash.TabIndex = 303
        Me.txtOfficialCash.Tag = Nothing
        Me.txtOfficialCash.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtOfficialCash.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtOfficialCash.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtOfficialCash.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtOfficialCash.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(366, 162)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(66, 13)
        Me.Label45.TabIndex = 302
        Me.Label45.Text = "Official Cash"
        '
        'chkNonActive
        '
        Me.chkNonActive.AutoSize = True
        Me.chkNonActive.Enabled = False
        Me.chkNonActive.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkNonActive.Location = New System.Drawing.Point(397, 41)
        Me.chkNonActive.Name = "chkNonActive"
        Me.chkNonActive.Size = New System.Drawing.Size(79, 17)
        Me.chkNonActive.TabIndex = 299
        Me.chkNonActive.Text = "Non Active"
        Me.chkNonActive.UseVisualStyleBackColor = True
        '
        'cmdAgent
        '
        Me.cmdAgent.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdAgent.Image = Global.General_Ledger.My.Resources.Resources.Find_Small
        Me.cmdAgent.Location = New System.Drawing.Point(609, 13)
        Me.cmdAgent.Name = "cmdAgent"
        Me.cmdAgent.Size = New System.Drawing.Size(22, 21)
        Me.cmdAgent.TabIndex = 301
        Me.cmdAgent.UseVisualStyleBackColor = True
        '
        'cmbAgent
        '
        Me.cmbAgent.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbAgent.Caption = ""
        Me.cmbAgent.CaptionHeight = 17
        Me.cmbAgent.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbAgent.ColumnCaptionHeight = 17
        Me.cmbAgent.ColumnFooterHeight = 17
        Me.cmbAgent.ContentHeight = 15
        Me.cmbAgent.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbAgent.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbAgent.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbAgent.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbAgent.EditorHeight = 15
        Me.cmbAgent.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbAgent.Images.Add(CType(resources.GetObject("cmbAgent.Images"), System.Drawing.Image))
        Me.cmbAgent.ItemHeight = 15
        Me.cmbAgent.Location = New System.Drawing.Point(430, 13)
        Me.cmbAgent.MatchEntryTimeout = CType(2000, Long)
        Me.cmbAgent.MaxDropDownItems = CType(5, Short)
        Me.cmbAgent.MaxLength = 32767
        Me.cmbAgent.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbAgent.Name = "cmbAgent"
        Me.cmbAgent.ReadOnly = True
        Me.cmbAgent.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbAgent.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbAgent.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbAgent.Size = New System.Drawing.Size(178, 21)
        Me.cmbAgent.TabIndex = 299
        Me.cmbAgent.PropBag = resources.GetString("cmbAgent.PropBag")
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(394, 16)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(35, 13)
        Me.Label43.TabIndex = 300
        Me.Label43.Text = "Agent"
        '
        'cmbAreaIn
        '
        Me.cmbAreaIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbAreaIn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbAreaIn.FormattingEnabled = True
        Me.cmbAreaIn.Items.AddRange(New Object() {"Sq. Feet", "Sq. Yds"})
        Me.cmbAreaIn.Location = New System.Drawing.Point(409, 121)
        Me.cmbAreaIn.Name = "cmbAreaIn"
        Me.cmbAreaIn.Size = New System.Drawing.Size(64, 21)
        Me.cmbAreaIn.TabIndex = 298
        '
        'chkApplyExtraLand
        '
        Me.chkApplyExtraLand.AutoSize = True
        Me.chkApplyExtraLand.Enabled = False
        Me.chkApplyExtraLand.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkApplyExtraLand.Location = New System.Drawing.Point(325, 123)
        Me.chkApplyExtraLand.Name = "chkApplyExtraLand"
        Me.chkApplyExtraLand.Size = New System.Drawing.Size(52, 17)
        Me.chkApplyExtraLand.TabIndex = 297
        Me.chkApplyExtraLand.Text = "Apply"
        Me.chkApplyExtraLand.UseVisualStyleBackColor = True
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(378, 125)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(29, 13)
        Me.Label42.TabIndex = 296
        Me.Label42.Text = "Area"
        '
        'txtExtraSqFeetYds
        '
        Me.txtExtraSqFeetYds.AutoSize = False
        Me.txtExtraSqFeetYds.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtExtraSqFeetYds.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtExtraSqFeetYds.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtExtraSqFeetYds.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtExtraSqFeetYds.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtExtraSqFeetYds.Location = New System.Drawing.Point(476, 121)
        Me.txtExtraSqFeetYds.Name = "txtExtraSqFeetYds"
        Me.txtExtraSqFeetYds.Size = New System.Drawing.Size(51, 20)
        Me.txtExtraSqFeetYds.TabIndex = 295
        Me.txtExtraSqFeetYds.Tag = Nothing
        Me.txtExtraSqFeetYds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtExtraSqFeetYds.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtExtraSqFeetYds.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtExtraSqFeetYds.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtExtraSqFeetYds.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(531, 125)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(46, 13)
        Me.Label41.TabIndex = 294
        Me.Label41.Text = "Charges"
        '
        'txtPerSqFeetCharges
        '
        Me.txtPerSqFeetCharges.AutoSize = False
        Me.txtPerSqFeetCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPerSqFeetCharges.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtPerSqFeetCharges.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtPerSqFeetCharges.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtPerSqFeetCharges.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPerSqFeetCharges.Location = New System.Drawing.Point(580, 121)
        Me.txtPerSqFeetCharges.Name = "txtPerSqFeetCharges"
        Me.txtPerSqFeetCharges.Size = New System.Drawing.Size(51, 20)
        Me.txtPerSqFeetCharges.TabIndex = 293
        Me.txtPerSqFeetCharges.Tag = Nothing
        Me.txtPerSqFeetCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtPerSqFeetCharges.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtPerSqFeetCharges.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtPerSqFeetCharges.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtPerSqFeetCharges.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(637, 123)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(100, 13)
        Me.Label40.TabIndex = 292
        Me.Label40.Text = "Extra Land Charges"
        '
        'txtExtraLandCharges
        '
        Me.txtExtraLandCharges.AutoSize = False
        Me.txtExtraLandCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtExtraLandCharges.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtExtraLandCharges.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtExtraLandCharges.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtExtraLandCharges.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtExtraLandCharges.Location = New System.Drawing.Point(743, 119)
        Me.txtExtraLandCharges.Name = "txtExtraLandCharges"
        Me.txtExtraLandCharges.ReadOnly = True
        Me.txtExtraLandCharges.Size = New System.Drawing.Size(88, 20)
        Me.txtExtraLandCharges.TabIndex = 291
        Me.txtExtraLandCharges.Tag = Nothing
        Me.txtExtraLandCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtExtraLandCharges.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtExtraLandCharges.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtExtraLandCharges.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtExtraLandCharges.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'lblRefundPaid
        '
        Me.lblRefundPaid.AutoSize = True
        Me.lblRefundPaid.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRefundPaid.Location = New System.Drawing.Point(637, 167)
        Me.lblRefundPaid.Name = "lblRefundPaid"
        Me.lblRefundPaid.Size = New System.Drawing.Size(66, 13)
        Me.lblRefundPaid.TabIndex = 290
        Me.lblRefundPaid.Text = "Refund Paid"
        Me.lblRefundPaid.Visible = False
        '
        'txtRefundPaid
        '
        Me.txtRefundPaid.AutoSize = False
        Me.txtRefundPaid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRefundPaid.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtRefundPaid.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtRefundPaid.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtRefundPaid.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRefundPaid.Location = New System.Drawing.Point(743, 163)
        Me.txtRefundPaid.Name = "txtRefundPaid"
        Me.txtRefundPaid.Size = New System.Drawing.Size(88, 20)
        Me.txtRefundPaid.TabIndex = 289
        Me.txtRefundPaid.Tag = Nothing
        Me.txtRefundPaid.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtRefundPaid.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtRefundPaid.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtRefundPaid.Visible = False
        Me.txtRefundPaid.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtRefundPaid.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'lblRefundAmount
        '
        Me.lblRefundAmount.AutoSize = True
        Me.lblRefundAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRefundAmount.Location = New System.Drawing.Point(315, -119)
        Me.lblRefundAmount.Name = "lblRefundAmount"
        Me.lblRefundAmount.Size = New System.Drawing.Size(81, 13)
        Me.lblRefundAmount.TabIndex = 288
        Me.lblRefundAmount.Text = "Refund Amount"
        Me.lblRefundAmount.Visible = False
        '
        'txtRefundAmount
        '
        Me.txtRefundAmount.AutoSize = False
        Me.txtRefundAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRefundAmount.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtRefundAmount.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtRefundAmount.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtRefundAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRefundAmount.Location = New System.Drawing.Point(417, -123)
        Me.txtRefundAmount.Name = "txtRefundAmount"
        Me.txtRefundAmount.Size = New System.Drawing.Size(88, 20)
        Me.txtRefundAmount.TabIndex = 287
        Me.txtRefundAmount.Tag = Nothing
        Me.txtRefundAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtRefundAmount.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtRefundAmount.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtRefundAmount.Visible = False
        Me.txtRefundAmount.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtRefundAmount.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(208, 114)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(53, 13)
        Me.Label39.TabIndex = 284
        Me.Label39.Text = "Penalty %"
        '
        'txtPenaltyPer
        '
        Me.txtPenaltyPer.AutoSize = False
        Me.txtPenaltyPer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPenaltyPer.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtPenaltyPer.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtPenaltyPer.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtPenaltyPer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPenaltyPer.Location = New System.Drawing.Point(268, 110)
        Me.txtPenaltyPer.Name = "txtPenaltyPer"
        Me.txtPenaltyPer.Size = New System.Drawing.Size(51, 20)
        Me.txtPenaltyPer.TabIndex = 283
        Me.txtPenaltyPer.Tag = Nothing
        Me.txtPenaltyPer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtPenaltyPer.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtPenaltyPer.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtPenaltyPer.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtPenaltyPer.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(9, 114)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(61, 13)
        Me.Label38.TabIndex = 282
        Me.Label38.Text = "Credit Days"
        '
        'txtCreditDays
        '
        Me.txtCreditDays.AutoSize = False
        Me.txtCreditDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCreditDays.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtCreditDays.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtCreditDays.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtCreditDays.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCreditDays.Location = New System.Drawing.Point(91, 110)
        Me.txtCreditDays.Name = "txtCreditDays"
        Me.txtCreditDays.Size = New System.Drawing.Size(88, 20)
        Me.txtCreditDays.TabIndex = 281
        Me.txtCreditDays.Tag = Nothing
        Me.txtCreditDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtCreditDays.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtCreditDays.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtCreditDays.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtCreditDays.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(637, 101)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(55, 13)
        Me.Label36.TabIndex = 280
        Me.Label36.Text = "Add Other"
        '
        'txtAddOtherCharges
        '
        Me.txtAddOtherCharges.AutoSize = False
        Me.txtAddOtherCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAddOtherCharges.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtAddOtherCharges.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtAddOtherCharges.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtAddOtherCharges.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddOtherCharges.Location = New System.Drawing.Point(743, 97)
        Me.txtAddOtherCharges.Name = "txtAddOtherCharges"
        Me.txtAddOtherCharges.Size = New System.Drawing.Size(88, 20)
        Me.txtAddOtherCharges.TabIndex = 279
        Me.txtAddOtherCharges.Tag = Nothing
        Me.txtAddOtherCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtAddOtherCharges.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtAddOtherCharges.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtAddOtherCharges.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtAddOtherCharges.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(201, 162)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(85, 13)
        Me.Label35.TabIndex = 278
        Me.Label35.Text = "Service Charges"
        '
        'txtCancelCharges
        '
        Me.txtCancelCharges.AutoSize = False
        Me.txtCancelCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCancelCharges.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtCancelCharges.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtCancelCharges.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtCancelCharges.Enabled = False
        Me.txtCancelCharges.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCancelCharges.Location = New System.Drawing.Point(295, 158)
        Me.txtCancelCharges.Name = "txtCancelCharges"
        Me.txtCancelCharges.ReadOnly = True
        Me.txtCancelCharges.Size = New System.Drawing.Size(65, 20)
        Me.txtCancelCharges.TabIndex = 277
        Me.txtCancelCharges.Tag = Nothing
        Me.txtCancelCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtCancelCharges.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtCancelCharges.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtCancelCharges.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtCancelCharges.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(12, 162)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(66, 13)
        Me.Label34.TabIndex = 276
        Me.Label34.Text = "Cancel Date"
        '
        'txtCancelDate
        '
        Me.txtCancelDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtCancelDate.Calendar.AnnuallyBoldedDates = New Date(-1) {}
        Me.txtCancelDate.Calendar.BoldedDates = New Date(-1) {}
        Me.txtCancelDate.Calendar.ClearText = "&Clear"
        Me.txtCancelDate.Calendar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCancelDate.Calendar.Margin = New System.Windows.Forms.Padding(0)
        Me.txtCancelDate.Calendar.MonthlyBoldedDates = New Date(-1) {}
        Me.txtCancelDate.Calendar.SelectedDate = New Date(2008, 7, 11, 0, 0, 0, 0)
        Me.txtCancelDate.Calendar.TodayText = "&Today"
        Me.txtCancelDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.System
        Me.txtCancelDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.System
        Me.txtCancelDate.Culture = 1056
        Me.txtCancelDate.CustomFormat = "dd/MM/yyyy"
        Me.txtCancelDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtCancelDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtCancelDate.Enabled = False
        Me.txtCancelDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCancelDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtCancelDate.Location = New System.Drawing.Point(91, 159)
        Me.txtCancelDate.Name = "txtCancelDate"
        Me.txtCancelDate.Size = New System.Drawing.Size(106, 19)
        Me.txtCancelDate.TabIndex = 275
        Me.txtCancelDate.Tag = Nothing
        Me.txtCancelDate.TrimEnd = False
        Me.txtCancelDate.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtCancelDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtCancelDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'chkCancel
        '
        Me.chkCancel.AutoSize = True
        Me.chkCancel.Enabled = False
        Me.chkCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCancel.Location = New System.Drawing.Point(12, 136)
        Me.chkCancel.Name = "chkCancel"
        Me.chkCancel.Size = New System.Drawing.Size(59, 17)
        Me.chkCancel.TabIndex = 274
        Me.chkCancel.Text = "Cancel"
        Me.chkCancel.UseVisualStyleBackColor = True
        '
        'cmdScheme
        '
        Me.cmdScheme.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdScheme.Image = Global.General_Ledger.My.Resources.Resources.Find_Small
        Me.cmdScheme.Location = New System.Drawing.Point(370, 62)
        Me.cmdScheme.Name = "cmdScheme"
        Me.cmdScheme.Size = New System.Drawing.Size(22, 21)
        Me.cmdScheme.TabIndex = 273
        Me.cmdScheme.UseVisualStyleBackColor = True
        '
        'cmbScheme
        '
        Me.cmbScheme.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbScheme.Caption = ""
        Me.cmbScheme.CaptionHeight = 17
        Me.cmbScheme.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbScheme.ColumnCaptionHeight = 17
        Me.cmbScheme.ColumnFooterHeight = 17
        Me.cmbScheme.ContentHeight = 15
        Me.cmbScheme.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbScheme.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbScheme.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbScheme.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbScheme.EditorHeight = 15
        Me.cmbScheme.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbScheme.Images.Add(CType(resources.GetObject("cmbScheme.Images"), System.Drawing.Image))
        Me.cmbScheme.ItemHeight = 15
        Me.cmbScheme.Location = New System.Drawing.Point(91, 62)
        Me.cmbScheme.MatchEntryTimeout = CType(2000, Long)
        Me.cmbScheme.MaxDropDownItems = CType(5, Short)
        Me.cmbScheme.MaxLength = 32767
        Me.cmbScheme.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbScheme.Name = "cmbScheme"
        Me.cmbScheme.ReadOnly = True
        Me.cmbScheme.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbScheme.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbScheme.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbScheme.Size = New System.Drawing.Size(278, 21)
        Me.cmbScheme.TabIndex = 271
        Me.cmbScheme.PropBag = resources.GetString("cmbScheme.PropBag")
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(9, 66)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(46, 13)
        Me.Label33.TabIndex = 272
        Me.Label33.Text = "Scheme"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(637, 79)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(54, 13)
        Me.Label31.TabIndex = 270
        Me.Label31.Text = "Discounts"
        '
        'txtDiscount
        '
        Me.txtDiscount.AutoSize = False
        Me.txtDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDiscount.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtDiscount.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtDiscount.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtDiscount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDiscount.Location = New System.Drawing.Point(743, 75)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(88, 20)
        Me.txtDiscount.TabIndex = 269
        Me.txtDiscount.Tag = Nothing
        Me.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtDiscount.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtDiscount.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtDiscount.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtDiscount.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'cmdPickPlan
        '
        Me.cmdPickPlan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPickPlan.Location = New System.Drawing.Point(592, 85)
        Me.cmdPickPlan.Name = "cmdPickPlan"
        Me.cmdPickPlan.Size = New System.Drawing.Size(36, 22)
        Me.cmdPickPlan.TabIndex = 268
        Me.cmdPickPlan.Text = "Pick Plan"
        Me.cmdPickPlan.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(637, 57)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(73, 13)
        Me.Label29.TabIndex = 267
        Me.Label29.Text = "Extra Charges"
        '
        'txtExtraCharges
        '
        Me.txtExtraCharges.AutoSize = False
        Me.txtExtraCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtExtraCharges.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtExtraCharges.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtExtraCharges.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtExtraCharges.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtExtraCharges.Location = New System.Drawing.Point(743, 53)
        Me.txtExtraCharges.Name = "txtExtraCharges"
        Me.txtExtraCharges.Size = New System.Drawing.Size(88, 20)
        Me.txtExtraCharges.TabIndex = 266
        Me.txtExtraCharges.Tag = Nothing
        Me.txtExtraCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtExtraCharges.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtExtraCharges.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtExtraCharges.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtExtraCharges.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(637, 144)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(78, 13)
        Me.Label25.TabIndex = 265
        Me.Label25.Text = "Total Revenue"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(637, 34)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(70, 13)
        Me.Label26.TabIndex = 264
        Me.Label26.Text = "Loan Amount"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(637, 12)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(70, 13)
        Me.Label28.TabIndex = 263
        Me.Label28.Text = "Cash Amount"
        '
        'txtTotalRevenue
        '
        Me.txtTotalRevenue.AutoSize = False
        Me.txtTotalRevenue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotalRevenue.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtTotalRevenue.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtTotalRevenue.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtTotalRevenue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalRevenue.Location = New System.Drawing.Point(743, 141)
        Me.txtTotalRevenue.Name = "txtTotalRevenue"
        Me.txtTotalRevenue.ReadOnly = True
        Me.txtTotalRevenue.Size = New System.Drawing.Size(88, 20)
        Me.txtTotalRevenue.TabIndex = 262
        Me.txtTotalRevenue.Tag = Nothing
        Me.txtTotalRevenue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtTotalRevenue.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtTotalRevenue.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtTotalRevenue.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtTotalRevenue.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtTotalRevenue.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'txtLoanAmount
        '
        Me.txtLoanAmount.AutoSize = False
        Me.txtLoanAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLoanAmount.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtLoanAmount.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtLoanAmount.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtLoanAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLoanAmount.Location = New System.Drawing.Point(743, 31)
        Me.txtLoanAmount.Name = "txtLoanAmount"
        Me.txtLoanAmount.Size = New System.Drawing.Size(88, 20)
        Me.txtLoanAmount.TabIndex = 261
        Me.txtLoanAmount.Tag = Nothing
        Me.txtLoanAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtLoanAmount.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtLoanAmount.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtLoanAmount.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtLoanAmount.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'txtCashAmount
        '
        Me.txtCashAmount.AutoSize = False
        Me.txtCashAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCashAmount.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtCashAmount.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtCashAmount.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtCashAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCashAmount.Location = New System.Drawing.Point(743, 9)
        Me.txtCashAmount.Name = "txtCashAmount"
        Me.txtCashAmount.Size = New System.Drawing.Size(88, 20)
        Me.txtCashAmount.TabIndex = 260
        Me.txtCashAmount.Tag = Nothing
        Me.txtCashAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtCashAmount.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtCashAmount.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtCashAmount.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtCashAmount.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'cmdStandardPaymentPlan
        '
        Me.cmdStandardPaymentPlan.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdStandardPaymentPlan.Image = Global.General_Ledger.My.Resources.Resources.Find_Small
        Me.cmdStandardPaymentPlan.Location = New System.Drawing.Point(570, 86)
        Me.cmdStandardPaymentPlan.Name = "cmdStandardPaymentPlan"
        Me.cmdStandardPaymentPlan.Size = New System.Drawing.Size(22, 21)
        Me.cmdStandardPaymentPlan.TabIndex = 259
        Me.cmdStandardPaymentPlan.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(409, 90)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(54, 13)
        Me.Label19.TabIndex = 258
        Me.Label19.Text = "St. Plan #"
        '
        'txtStandardPlanNo
        '
        Me.txtStandardPlanNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtStandardPlanNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStandardPlanNo.Location = New System.Drawing.Point(469, 86)
        Me.txtStandardPlanNo.Name = "txtStandardPlanNo"
        Me.txtStandardPlanNo.Size = New System.Drawing.Size(100, 20)
        Me.txtStandardPlanNo.TabIndex = 257
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(9, 89)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 13)
        Me.Label4.TabIndex = 256
        Me.Label4.Text = "Payment Plan"
        '
        'cmbPaymentPlan
        '
        Me.cmbPaymentPlan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPaymentPlan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbPaymentPlan.FormattingEnabled = True
        Me.cmbPaymentPlan.Items.AddRange(New Object() {"Standard", "Customize (Cash + Loan - Extra)", "Customize (Cash + Loan + Extra)", "Customize (Cash + Extra - Loan)"})
        Me.cmbPaymentPlan.Location = New System.Drawing.Point(91, 85)
        Me.cmbPaymentPlan.Name = "cmbPaymentPlan"
        Me.cmbPaymentPlan.Size = New System.Drawing.Size(212, 21)
        Me.cmbPaymentPlan.TabIndex = 255
        '
        'cmdUnitType
        '
        Me.cmdUnitType.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdUnitType.Image = Global.General_Ledger.My.Resources.Resources.Find_Small
        Me.cmdUnitType.Location = New System.Drawing.Point(370, 14)
        Me.cmdUnitType.Name = "cmdUnitType"
        Me.cmdUnitType.Size = New System.Drawing.Size(22, 21)
        Me.cmdUnitType.TabIndex = 254
        Me.cmdUnitType.UseVisualStyleBackColor = True
        '
        'cmbUnitType
        '
        Me.cmbUnitType.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbUnitType.Caption = ""
        Me.cmbUnitType.CaptionHeight = 17
        Me.cmbUnitType.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbUnitType.ColumnCaptionHeight = 17
        Me.cmbUnitType.ColumnFooterHeight = 17
        Me.cmbUnitType.ContentHeight = 15
        Me.cmbUnitType.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbUnitType.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbUnitType.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbUnitType.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbUnitType.EditorHeight = 15
        Me.cmbUnitType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbUnitType.Images.Add(CType(resources.GetObject("cmbUnitType.Images"), System.Drawing.Image))
        Me.cmbUnitType.ItemHeight = 15
        Me.cmbUnitType.Location = New System.Drawing.Point(91, 14)
        Me.cmbUnitType.MatchEntryTimeout = CType(2000, Long)
        Me.cmbUnitType.MaxDropDownItems = CType(5, Short)
        Me.cmbUnitType.MaxLength = 32767
        Me.cmbUnitType.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbUnitType.Name = "cmbUnitType"
        Me.cmbUnitType.ReadOnly = True
        Me.cmbUnitType.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbUnitType.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbUnitType.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbUnitType.Size = New System.Drawing.Size(278, 21)
        Me.cmbUnitType.TabIndex = 252
        Me.cmbUnitType.PropBag = resources.GetString("cmbUnitType.PropBag")
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(9, 18)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(53, 13)
        Me.Label27.TabIndex = 253
        Me.Label27.Text = "Unit Type"
        '
        'cmdUnit
        '
        Me.cmdUnit.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdUnit.Image = Global.General_Ledger.My.Resources.Resources.Find_Small
        Me.cmdUnit.Location = New System.Drawing.Point(369, 38)
        Me.cmdUnit.Name = "cmdUnit"
        Me.cmdUnit.Size = New System.Drawing.Size(22, 21)
        Me.cmdUnit.TabIndex = 251
        Me.cmdUnit.UseVisualStyleBackColor = True
        '
        'cmbUnit
        '
        Me.cmbUnit.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbUnit.Caption = ""
        Me.cmbUnit.CaptionHeight = 17
        Me.cmbUnit.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbUnit.ColumnCaptionHeight = 17
        Me.cmbUnit.ColumnFooterHeight = 17
        Me.cmbUnit.ContentHeight = 15
        Me.cmbUnit.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbUnit.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbUnit.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbUnit.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbUnit.EditorHeight = 15
        Me.cmbUnit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbUnit.Images.Add(CType(resources.GetObject("cmbUnit.Images"), System.Drawing.Image))
        Me.cmbUnit.ItemHeight = 15
        Me.cmbUnit.Location = New System.Drawing.Point(91, 38)
        Me.cmbUnit.MatchEntryTimeout = CType(2000, Long)
        Me.cmbUnit.MaxDropDownItems = CType(5, Short)
        Me.cmbUnit.MaxLength = 32767
        Me.cmbUnit.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbUnit.Name = "cmbUnit"
        Me.cmbUnit.ReadOnly = True
        Me.cmbUnit.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbUnit.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbUnit.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbUnit.Size = New System.Drawing.Size(278, 21)
        Me.cmbUnit.TabIndex = 249
        Me.cmbUnit.PropBag = resources.GetString("cmbUnit.PropBag")
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(9, 42)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(36, 13)
        Me.Label21.TabIndex = 250
        Me.Label21.Text = "Unit #"
        '
        'tdbPaymentType
        '
        Me.tdbPaymentType.AllowColMove = True
        Me.tdbPaymentType.AllowColSelect = True
        Me.tdbPaymentType.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbPaymentType.AlternatingRows = False
        Me.tdbPaymentType.CaptionStyle = Style1
        Me.tdbPaymentType.ColumnCaptionHeight = 17
        Me.tdbPaymentType.ColumnFooterHeight = 17
        Me.tdbPaymentType.EvenRowStyle = Style2
        Me.tdbPaymentType.FetchRowStyles = False
        Me.tdbPaymentType.FooterStyle = Style3
        Me.tdbPaymentType.HeadingStyle = Style4
        Me.tdbPaymentType.HighLightRowStyle = Style5
        Me.tdbPaymentType.Images.Add(CType(resources.GetObject("tdbPaymentType.Images"), System.Drawing.Image))
        Me.tdbPaymentType.Location = New System.Drawing.Point(15, 604)
        Me.tdbPaymentType.Name = "tdbPaymentType"
        Me.tdbPaymentType.OddRowStyle = Style6
        Me.tdbPaymentType.RecordSelectorStyle = Style7
        Me.tdbPaymentType.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbPaymentType.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbPaymentType.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbPaymentType.ScrollTips = False
        Me.tdbPaymentType.Size = New System.Drawing.Size(388, 158)
        Me.tdbPaymentType.Style = Style8
        Me.tdbPaymentType.TabIndex = 242
        Me.tdbPaymentType.TabStop = False
        Me.tdbPaymentType.Text = "C1TrueDBDropdown1"
        Me.tdbPaymentType.ValueTranslate = True
        Me.tdbPaymentType.Visible = False
        Me.tdbPaymentType.PropBag = resources.GetString("tdbPaymentType.PropBag")
        '
        'tdbGridPaymentPlan
        '
        Me.tdbGridPaymentPlan.AllowAddNew = True
        Me.tdbGridPaymentPlan.AllowDelete = True
        Me.tdbGridPaymentPlan.ColumnFooters = True
        Me.tdbGridPaymentPlan.EmptyRows = True
        Me.tdbGridPaymentPlan.GroupByCaption = "Drag a column header here to group by that column"
        Me.tdbGridPaymentPlan.Images.Add(CType(resources.GetObject("tdbGridPaymentPlan.Images"), System.Drawing.Image))
        Me.tdbGridPaymentPlan.Images.Add(CType(resources.GetObject("tdbGridPaymentPlan.Images1"), System.Drawing.Image))
        Me.tdbGridPaymentPlan.Images.Add(CType(resources.GetObject("tdbGridPaymentPlan.Images2"), System.Drawing.Image))
        Me.tdbGridPaymentPlan.Location = New System.Drawing.Point(4, 586)
        Me.tdbGridPaymentPlan.Name = "tdbGridPaymentPlan"
        Me.tdbGridPaymentPlan.PreviewInfo.Location = New System.Drawing.Point(0, 0)
        Me.tdbGridPaymentPlan.PreviewInfo.Size = New System.Drawing.Size(0, 0)
        Me.tdbGridPaymentPlan.PreviewInfo.ZoomFactor = 75
        Me.tdbGridPaymentPlan.PrintInfo.PageSettings = CType(resources.GetObject("tdbGridPaymentPlan.PrintInfo.PageSettings"), System.Drawing.Printing.PageSettings)
        Me.tdbGridPaymentPlan.RecordSelectors = False
        Me.tdbGridPaymentPlan.Size = New System.Drawing.Size(836, 148)
        Me.tdbGridPaymentPlan.TabIndex = 241
        Me.tdbGridPaymentPlan.Text = "C1TrueDBGrid1"
        Me.tdbGridPaymentPlan.VisualStyle = C1.Win.C1TrueDBGrid.VisualStyle.Office2007Silver
        Me.tdbGridPaymentPlan.WrapCellPointer = True
        Me.tdbGridPaymentPlan.PropBag = resources.GetString("tdbGridPaymentPlan.PropBag")
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label37)
        Me.GroupBox4.Controls.Add(Me.txtLastPaymentDate)
        Me.GroupBox4.Controls.Add(Me.cmdRescheduleAdd)
        Me.GroupBox4.Controls.Add(Me.cmdRescheduleDelete)
        Me.GroupBox4.Controls.Add(Me.txtDelayDays)
        Me.GroupBox4.Controls.Add(Me.Label32)
        Me.GroupBox4.Controls.Add(Me.cmdClear)
        Me.GroupBox4.Controls.Add(Me.cmdExtraCharges)
        Me.GroupBox4.Controls.Add(Me.cmbExtraCharges)
        Me.GroupBox4.Controls.Add(Me.Label30)
        Me.GroupBox4.Controls.Add(Me.cmdDeletePlan)
        Me.GroupBox4.Controls.Add(Me.cmdUpdate)
        Me.GroupBox4.Controls.Add(Me.chkNotDecided)
        Me.GroupBox4.Controls.Add(Me.cmdGenerate)
        Me.GroupBox4.Controls.Add(Me.txtDueDays)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Controls.Add(Me.txtInstallments)
        Me.GroupBox4.Controls.Add(Me.Label22)
        Me.GroupBox4.Controls.Add(Me.txtAmount)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.Controls.Add(Me.cmbPaymentType)
        Me.GroupBox4.Controls.Add(Me.Label24)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(4, 490)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(834, 93)
        Me.GroupBox4.TabIndex = 240
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Payment Generation (from Date of Reservation)"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(3, 73)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(97, 13)
        Me.Label37.TabIndex = 268
        Me.Label37.Text = "Last Payment Date"
        '
        'txtLastPaymentDate
        '
        Me.txtLastPaymentDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtLastPaymentDate.Calendar.AnnuallyBoldedDates = New Date(-1) {}
        Me.txtLastPaymentDate.Calendar.BoldedDates = New Date(-1) {}
        Me.txtLastPaymentDate.Calendar.ClearText = "&Clear"
        Me.txtLastPaymentDate.Calendar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastPaymentDate.Calendar.Margin = New System.Windows.Forms.Padding(0)
        Me.txtLastPaymentDate.Calendar.MonthlyBoldedDates = New Date(-1) {}
        Me.txtLastPaymentDate.Calendar.SelectedDate = New Date(2008, 7, 11, 0, 0, 0, 0)
        Me.txtLastPaymentDate.Calendar.TodayText = "&Today"
        Me.txtLastPaymentDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.System
        Me.txtLastPaymentDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.System
        Me.txtLastPaymentDate.Culture = 1056
        Me.txtLastPaymentDate.CustomFormat = "dd/MM/yyyy"
        Me.txtLastPaymentDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtLastPaymentDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtLastPaymentDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastPaymentDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtLastPaymentDate.Location = New System.Drawing.Point(108, 69)
        Me.txtLastPaymentDate.Name = "txtLastPaymentDate"
        Me.txtLastPaymentDate.Size = New System.Drawing.Size(126, 19)
        Me.txtLastPaymentDate.TabIndex = 267
        Me.txtLastPaymentDate.Tag = Nothing
        Me.txtLastPaymentDate.TrimEnd = False
        Me.txtLastPaymentDate.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtLastPaymentDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtLastPaymentDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'cmdRescheduleAdd
        '
        Me.cmdRescheduleAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRescheduleAdd.ForeColor = System.Drawing.Color.Blue
        Me.cmdRescheduleAdd.Location = New System.Drawing.Point(356, 68)
        Me.cmdRescheduleAdd.Name = "cmdRescheduleAdd"
        Me.cmdRescheduleAdd.Size = New System.Drawing.Size(104, 23)
        Me.cmdRescheduleAdd.TabIndex = 266
        Me.cmdRescheduleAdd.Text = "Reschedule Insert"
        Me.cmdRescheduleAdd.UseVisualStyleBackColor = True
        '
        'cmdRescheduleDelete
        '
        Me.cmdRescheduleDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRescheduleDelete.ForeColor = System.Drawing.Color.Blue
        Me.cmdRescheduleDelete.Location = New System.Drawing.Point(244, 68)
        Me.cmdRescheduleDelete.Name = "cmdRescheduleDelete"
        Me.cmdRescheduleDelete.Size = New System.Drawing.Size(111, 23)
        Me.cmdRescheduleDelete.TabIndex = 265
        Me.cmdRescheduleDelete.Text = "Reschedule Delete"
        Me.cmdRescheduleDelete.UseVisualStyleBackColor = True
        '
        'txtDelayDays
        '
        Me.txtDelayDays.AutoSize = False
        Me.txtDelayDays.BackColor = System.Drawing.Color.White
        Me.txtDelayDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDelayDays.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtDelayDays.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtDelayDays.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtDelayDays.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDelayDays.Location = New System.Drawing.Point(474, 41)
        Me.txtDelayDays.Name = "txtDelayDays"
        Me.txtDelayDays.Size = New System.Drawing.Size(50, 20)
        Me.txtDelayDays.TabIndex = 264
        Me.txtDelayDays.Tag = Nothing
        Me.txtDelayDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtDelayDays.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtDelayDays.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtDelayDays.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtDelayDays.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(466, 24)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(61, 13)
        Me.Label32.TabIndex = 263
        Me.Label32.Text = "Delay Days"
        '
        'cmdClear
        '
        Me.cmdClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClear.Location = New System.Drawing.Point(339, 40)
        Me.cmdClear.Name = "cmdClear"
        Me.cmdClear.Size = New System.Drawing.Size(40, 21)
        Me.cmdClear.TabIndex = 262
        Me.cmdClear.Text = "Clear"
        Me.cmdClear.UseVisualStyleBackColor = True
        '
        'cmdExtraCharges
        '
        Me.cmdExtraCharges.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdExtraCharges.Image = Global.General_Ledger.My.Resources.Resources.Find_Small
        Me.cmdExtraCharges.Location = New System.Drawing.Point(317, 40)
        Me.cmdExtraCharges.Name = "cmdExtraCharges"
        Me.cmdExtraCharges.Size = New System.Drawing.Size(22, 21)
        Me.cmdExtraCharges.TabIndex = 261
        Me.cmdExtraCharges.UseVisualStyleBackColor = True
        '
        'cmbExtraCharges
        '
        Me.cmbExtraCharges.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges.Caption = ""
        Me.cmbExtraCharges.CaptionHeight = 17
        Me.cmbExtraCharges.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges.ColumnCaptionHeight = 17
        Me.cmbExtraCharges.ColumnFooterHeight = 17
        Me.cmbExtraCharges.ContentHeight = 15
        Me.cmbExtraCharges.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges.EditorHeight = 15
        Me.cmbExtraCharges.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges.Images.Add(CType(resources.GetObject("cmbExtraCharges.Images"), System.Drawing.Image))
        Me.cmbExtraCharges.ItemHeight = 15
        Me.cmbExtraCharges.Location = New System.Drawing.Point(179, 40)
        Me.cmbExtraCharges.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges.MaxLength = 32767
        Me.cmbExtraCharges.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges.Name = "cmbExtraCharges"
        Me.cmbExtraCharges.ReadOnly = True
        Me.cmbExtraCharges.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges.Size = New System.Drawing.Size(139, 21)
        Me.cmbExtraCharges.TabIndex = 148
        Me.cmbExtraCharges.PropBag = resources.GetString("cmbExtraCharges.PropBag")
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(212, 23)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(73, 13)
        Me.Label30.TabIndex = 147
        Me.Label30.Text = "Extra Charges"
        '
        'cmdDeletePlan
        '
        Me.cmdDeletePlan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDeletePlan.Location = New System.Drawing.Point(754, 54)
        Me.cmdDeletePlan.Name = "cmdDeletePlan"
        Me.cmdDeletePlan.Size = New System.Drawing.Size(77, 23)
        Me.cmdDeletePlan.TabIndex = 146
        Me.cmdDeletePlan.Text = "Delete"
        Me.cmdDeletePlan.UseVisualStyleBackColor = True
        '
        'cmdUpdate
        '
        Me.cmdUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdUpdate.Location = New System.Drawing.Point(754, 32)
        Me.cmdUpdate.Name = "cmdUpdate"
        Me.cmdUpdate.Size = New System.Drawing.Size(77, 23)
        Me.cmdUpdate.TabIndex = 145
        Me.cmdUpdate.Text = "Update"
        Me.cmdUpdate.UseVisualStyleBackColor = True
        '
        'chkNotDecided
        '
        Me.chkNotDecided.AutoSize = True
        Me.chkNotDecided.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkNotDecided.Location = New System.Drawing.Point(667, 41)
        Me.chkNotDecided.Name = "chkNotDecided"
        Me.chkNotDecided.Size = New System.Drawing.Size(86, 17)
        Me.chkNotDecided.TabIndex = 143
        Me.chkNotDecided.Text = "Not Decided"
        Me.chkNotDecided.UseVisualStyleBackColor = True
        '
        'cmdGenerate
        '
        Me.cmdGenerate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdGenerate.Location = New System.Drawing.Point(754, 10)
        Me.cmdGenerate.Name = "cmdGenerate"
        Me.cmdGenerate.Size = New System.Drawing.Size(77, 23)
        Me.cmdGenerate.TabIndex = 144
        Me.cmdGenerate.Text = "Generate"
        Me.cmdGenerate.UseVisualStyleBackColor = True
        '
        'txtDueDays
        '
        Me.txtDueDays.AutoSize = False
        Me.txtDueDays.BackColor = System.Drawing.Color.White
        Me.txtDueDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDueDays.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtDueDays.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtDueDays.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtDueDays.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDueDays.Location = New System.Drawing.Point(600, 40)
        Me.txtDueDays.Name = "txtDueDays"
        Me.txtDueDays.Size = New System.Drawing.Size(57, 20)
        Me.txtDueDays.TabIndex = 142
        Me.txtDueDays.Tag = Nothing
        Me.txtDueDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtDueDays.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtDueDays.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtDueDays.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtDueDays.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(596, 23)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(65, 13)
        Me.Label20.TabIndex = 141
        Me.Label20.Text = "Due in Days"
        '
        'txtInstallments
        '
        Me.txtInstallments.AutoSize = False
        Me.txtInstallments.BackColor = System.Drawing.Color.White
        Me.txtInstallments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtInstallments.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtInstallments.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtInstallments.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtInstallments.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInstallments.Location = New System.Drawing.Point(544, 40)
        Me.txtInstallments.Name = "txtInstallments"
        Me.txtInstallments.Size = New System.Drawing.Size(50, 20)
        Me.txtInstallments.TabIndex = 140
        Me.txtInstallments.Tag = Nothing
        Me.txtInstallments.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtInstallments.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtInstallments.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtInstallments.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtInstallments.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(543, 23)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(46, 13)
        Me.Label22.TabIndex = 139
        Me.Label22.Text = "# of Inst"
        '
        'txtAmount
        '
        Me.txtAmount.AutoSize = False
        Me.txtAmount.BackColor = System.Drawing.Color.White
        Me.txtAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAmount.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtAmount.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtAmount.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAmount.Location = New System.Drawing.Point(387, 40)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(74, 20)
        Me.txtAmount.TabIndex = 138
        Me.txtAmount.Tag = Nothing
        Me.txtAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtAmount.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtAmount.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtAmount.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtAmount.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(403, 23)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(43, 13)
        Me.Label23.TabIndex = 137
        Me.Label23.Text = "Amount"
        '
        'cmbPaymentType
        '
        Me.cmbPaymentType.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbPaymentType.Caption = ""
        Me.cmbPaymentType.CaptionHeight = 17
        Me.cmbPaymentType.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbPaymentType.ColumnCaptionHeight = 17
        Me.cmbPaymentType.ColumnFooterHeight = 17
        Me.cmbPaymentType.ContentHeight = 15
        Me.cmbPaymentType.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbPaymentType.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbPaymentType.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbPaymentType.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbPaymentType.EditorHeight = 15
        Me.cmbPaymentType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbPaymentType.Images.Add(CType(resources.GetObject("cmbPaymentType.Images"), System.Drawing.Image))
        Me.cmbPaymentType.ItemHeight = 15
        Me.cmbPaymentType.Location = New System.Drawing.Point(8, 40)
        Me.cmbPaymentType.MatchEntryTimeout = CType(2000, Long)
        Me.cmbPaymentType.MaxDropDownItems = CType(5, Short)
        Me.cmbPaymentType.MaxLength = 32767
        Me.cmbPaymentType.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbPaymentType.Name = "cmbPaymentType"
        Me.cmbPaymentType.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbPaymentType.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbPaymentType.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbPaymentType.Size = New System.Drawing.Size(163, 21)
        Me.cmbPaymentType.TabIndex = 136
        Me.cmbPaymentType.PropBag = resources.GetString("cmbPaymentType.PropBag")
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(52, 23)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(75, 13)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "Payment Type"
        '
        'tdbExtraCharges
        '
        Me.tdbExtraCharges.AllowColMove = True
        Me.tdbExtraCharges.AllowColSelect = True
        Me.tdbExtraCharges.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbExtraCharges.AlternatingRows = False
        Me.tdbExtraCharges.CaptionStyle = Style9
        Me.tdbExtraCharges.ColumnCaptionHeight = 17
        Me.tdbExtraCharges.ColumnFooterHeight = 17
        Me.tdbExtraCharges.EvenRowStyle = Style10
        Me.tdbExtraCharges.FetchRowStyles = False
        Me.tdbExtraCharges.FooterStyle = Style11
        Me.tdbExtraCharges.HeadingStyle = Style12
        Me.tdbExtraCharges.HighLightRowStyle = Style13
        Me.tdbExtraCharges.Images.Add(CType(resources.GetObject("tdbExtraCharges.Images"), System.Drawing.Image))
        Me.tdbExtraCharges.Location = New System.Drawing.Point(343, 604)
        Me.tdbExtraCharges.Name = "tdbExtraCharges"
        Me.tdbExtraCharges.OddRowStyle = Style14
        Me.tdbExtraCharges.RecordSelectorStyle = Style15
        Me.tdbExtraCharges.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbExtraCharges.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbExtraCharges.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbExtraCharges.ScrollTips = False
        Me.tdbExtraCharges.Size = New System.Drawing.Size(388, 158)
        Me.tdbExtraCharges.Style = Style16
        Me.tdbExtraCharges.TabIndex = 243
        Me.tdbExtraCharges.TabStop = False
        Me.tdbExtraCharges.Text = "C1TrueDBDropdown1"
        Me.tdbExtraCharges.ValueTranslate = True
        Me.tdbExtraCharges.Visible = False
        Me.tdbExtraCharges.PropBag = resources.GetString("tdbExtraCharges.PropBag")
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.chkAuthorityLetter)
        Me.GroupBox5.Controls.Add(Me.chkPhotograph)
        Me.GroupBox5.Controls.Add(Me.chkPassport)
        Me.GroupBox5.Controls.Add(Me.chkNICMakingBooking)
        Me.GroupBox5.Controls.Add(Me.chkCustomerNIC)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(394, 60)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(442, 101)
        Me.GroupBox5.TabIndex = 244
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Documents Required"
        '
        'chkAuthorityLetter
        '
        Me.chkAuthorityLetter.AutoSize = True
        Me.chkAuthorityLetter.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkAuthorityLetter.Location = New System.Drawing.Point(5, 79)
        Me.chkAuthorityLetter.Name = "chkAuthorityLetter"
        Me.chkAuthorityLetter.Size = New System.Drawing.Size(353, 17)
        Me.chkAuthorityLetter.TabIndex = 4
        Me.chkAuthorityLetter.Text = "Authority Letter from the person under whose name the unit is booked"
        Me.chkAuthorityLetter.UseVisualStyleBackColor = True
        '
        'chkPhotograph
        '
        Me.chkPhotograph.AutoSize = True
        Me.chkPhotograph.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPhotograph.Location = New System.Drawing.Point(172, 57)
        Me.chkPhotograph.Name = "chkPhotograph"
        Me.chkPhotograph.Size = New System.Drawing.Size(187, 17)
        Me.chkPhotograph.TabIndex = 3
        Me.chkPhotograph.Text = "Four (6) Passport Size Photograph"
        Me.chkPhotograph.UseVisualStyleBackColor = True
        '
        'chkPassport
        '
        Me.chkPassport.AutoSize = True
        Me.chkPassport.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPassport.Location = New System.Drawing.Point(5, 57)
        Me.chkPassport.Name = "chkPassport"
        Me.chkPassport.Size = New System.Drawing.Size(166, 17)
        Me.chkPassport.TabIndex = 2
        Me.chkPassport.Text = "Copy of Passport (if Required)"
        Me.chkPassport.UseVisualStyleBackColor = True
        '
        'chkNICMakingBooking
        '
        Me.chkNICMakingBooking.AutoSize = True
        Me.chkNICMakingBooking.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkNICMakingBooking.Location = New System.Drawing.Point(5, 36)
        Me.chkNICMakingBooking.Name = "chkNICMakingBooking"
        Me.chkNICMakingBooking.Size = New System.Drawing.Size(248, 17)
        Me.chkNICMakingBooking.TabIndex = 1
        Me.chkNICMakingBooking.Text = "Copy of NIC Person who is making the booking"
        Me.chkNICMakingBooking.UseVisualStyleBackColor = True
        '
        'chkCustomerNIC
        '
        Me.chkCustomerNIC.AutoSize = True
        Me.chkCustomerNIC.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCustomerNIC.Location = New System.Drawing.Point(5, 16)
        Me.chkCustomerNIC.Name = "chkCustomerNIC"
        Me.chkCustomerNIC.Size = New System.Drawing.Size(299, 17)
        Me.chkCustomerNIC.TabIndex = 0
        Me.chkCustomerNIC.Text = "Copy of NIC Person under whose name the unit is booked"
        Me.chkCustomerNIC.UseVisualStyleBackColor = True
        '
        'cmdPrint
        '
        Me.cmdPrint.Image = Global.General_Ledger.My.Resources.Resources.folder_document
        Me.cmdPrint.Location = New System.Drawing.Point(364, 4)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.Size = New System.Drawing.Size(49, 56)
        Me.cmdPrint.TabIndex = 250
        Me.cmdPrint.Text = "&Print"
        Me.cmdPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdPrint.UseVisualStyleBackColor = True
        '
        'cmdPreview
        '
        Me.cmdPreview.Image = Global.General_Ledger.My.Resources.Resources.folder_document
        Me.cmdPreview.Location = New System.Drawing.Point(414, 4)
        Me.cmdPreview.Name = "cmdPreview"
        Me.cmdPreview.Size = New System.Drawing.Size(54, 56)
        Me.cmdPreview.TabIndex = 249
        Me.cmdPreview.Text = "&Preview"
        Me.cmdPreview.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdPreview.UseVisualStyleBackColor = True
        '
        'frmReservation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(843, 701)
        Me.Controls.Add(Me.cmdPrint)
        Me.Controls.Add(Me.cmdPreview)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.tdbExtraCharges)
        Me.Controls.Add(Me.tdbPaymentType)
        Me.Controls.Add(Me.tdbGridPaymentPlan)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmdAdd)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.cmdUndo)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.GroupBox2)
        Me.MaximizeBox = False
        Me.Name = "frmReservation"
        Me.Text = "Reservation Form"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.cmbProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtReservationDate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.txtNoofMonths, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtOfficialService, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtOfficialCash, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbAgent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtExtraSqFeetYds, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPerSqFeetCharges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtExtraLandCharges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtRefundPaid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtRefundAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPenaltyPer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCreditDays, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAddOtherCharges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCancelCharges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCancelDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbScheme, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDiscount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtExtraCharges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTotalRevenue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLoanAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCashAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbUnitType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbUnit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbPaymentType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbGridPaymentPlan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.txtLastPaymentDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDelayDays, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDueDays, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtInstallments, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbPaymentType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbExtraCharges, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents cmdUndo As System.Windows.Forms.Button
    Friend WithEvents cmdEdit As System.Windows.Forms.Button
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents txtReservationNo As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdSearch As System.Windows.Forms.Button
    Friend WithEvents cmdExit As System.Windows.Forms.Button
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtReservationDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbProject As C1.Win.C1List.C1Combo
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCustomerName1 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerCode1 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerEmail2 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cmdCustomerList2 As System.Windows.Forms.Button
    Friend WithEvents txtCustomerNIC2 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerMobile2 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerTel2 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerName2 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerCode2 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerEmail1 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents cmdCustomerList1 As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerNIC1 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerMobile1 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerTel1 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdUnit As System.Windows.Forms.Button
    Friend WithEvents cmbUnit As C1.Win.C1List.C1Combo
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmbPaymentPlan As System.Windows.Forms.ComboBox
    Friend WithEvents cmdUnitType As System.Windows.Forms.Button
    Friend WithEvents cmbUnitType As C1.Win.C1List.C1Combo
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents cmdStandardPaymentPlan As System.Windows.Forms.Button
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtStandardPlanNo As System.Windows.Forms.TextBox
    Friend WithEvents tdbPaymentType As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents tdbGridPaymentPlan As C1.Win.C1TrueDBGrid.C1TrueDBGrid
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdGenerate As System.Windows.Forms.Button
    Friend WithEvents txtDueDays As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtInstallments As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtAmount As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents cmbPaymentType As C1.Win.C1List.C1Combo
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtTotalRevenue As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents txtLoanAmount As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents txtCashAmount As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtExtraCharges As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents cmdUpdate As System.Windows.Forms.Button
    Friend WithEvents chkNotDecided As System.Windows.Forms.CheckBox
    Friend WithEvents cmdDeletePlan As System.Windows.Forms.Button
    Friend WithEvents tdbExtraCharges As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents cmbExtraCharges As C1.Win.C1List.C1Combo
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents cmdPickPlan As System.Windows.Forms.Button
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtDiscount As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents cmdExtraCharges As System.Windows.Forms.Button
    Friend WithEvents cmdClear As System.Windows.Forms.Button
    Friend WithEvents txtDelayDays As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents cmdScheme As System.Windows.Forms.Button
    Friend WithEvents cmbScheme As C1.Win.C1List.C1Combo
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtCancelCharges As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txtCancelDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents chkCancel As System.Windows.Forms.CheckBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents txtAddOtherCharges As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents cmdRescheduleDelete As System.Windows.Forms.Button
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents txtLastPaymentDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents cmdRescheduleAdd As System.Windows.Forms.Button
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents txtCreditDays As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents chkNICMakingBooking As System.Windows.Forms.CheckBox
    Friend WithEvents chkCustomerNIC As System.Windows.Forms.CheckBox
    Friend WithEvents chkPassport As System.Windows.Forms.CheckBox
    Friend WithEvents chkAuthorityLetter As System.Windows.Forms.CheckBox
    Friend WithEvents chkPhotograph As System.Windows.Forms.CheckBox
    Friend WithEvents cmdClearApplicant As System.Windows.Forms.Button
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents txtPenaltyPer As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents lblRefundAmount As System.Windows.Forms.Label
    Friend WithEvents txtRefundAmount As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents lblRefundPaid As System.Windows.Forms.Label
    Friend WithEvents txtRefundPaid As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents txtExtraSqFeetYds As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents txtPerSqFeetCharges As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtExtraLandCharges As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents chkApplyExtraLand As System.Windows.Forms.CheckBox
    Friend WithEvents cmbAreaIn As System.Windows.Forms.ComboBox
    Friend WithEvents cmdAgent As System.Windows.Forms.Button
    Friend WithEvents cmbAgent As C1.Win.C1List.C1Combo
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents chkNonActive As System.Windows.Forms.CheckBox
    Friend WithEvents cmdPrint As System.Windows.Forms.Button
    Friend WithEvents cmdPreview As System.Windows.Forms.Button
    Friend WithEvents txtOfficialService As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtOfficialCash As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents txtNoofMonths As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents chkBlockLetters As System.Windows.Forms.CheckBox
    'Friend WithEvents CachedReport1 As CrystalDecisions.ReportSource.CachedReport
End Class
