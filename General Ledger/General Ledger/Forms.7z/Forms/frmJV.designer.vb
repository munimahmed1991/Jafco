<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmJv
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Style1 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style2 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style3 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style4 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style5 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmJv))
        Dim Style6 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style7 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style8 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style9 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style10 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style11 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style12 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style13 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style14 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style15 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style16 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style17 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style18 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style19 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style20 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style21 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style22 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style23 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style24 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style25 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style26 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style27 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style28 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style29 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style30 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style31 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style32 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style33 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style34 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style35 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style36 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style37 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style38 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style39 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style40 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Me.cmdAdd = New System.Windows.Forms.Button
        Me.cmdExit = New System.Windows.Forms.Button
        Me.cmdUndo = New System.Windows.Forms.Button
        Me.cmdSearch = New System.Windows.Forms.Button
        Me.cmdEdit = New System.Windows.Forms.Button
        Me.cmdDelete = New System.Windows.Forms.Button
        Me.cmdPrint = New System.Windows.Forms.Button
        Me.cmdSave = New System.Windows.Forms.Button
        Me.txtDescription = New System.Windows.Forms.TextBox
        Me.txtVoucherNo = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.tdbAccountName = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.txtDate = New C1.Win.C1Input.C1DateEdit
        Me.Label3 = New System.Windows.Forms.Label
        Me.tdbAccountCode = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.Label4 = New System.Windows.Forms.Label
        Me.lblVoucherType = New System.Windows.Forms.Label
        Me.cmbVoucherType = New System.Windows.Forms.ComboBox
        Me.TDBGrid1 = New C1.Win.C1TrueDBGrid.C1TrueDBGrid
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.lblHeading = New System.Windows.Forms.ToolStripLabel
        Me.tdbLocation = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.tdbTag = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.tdbEmployee = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.cmdRefresh = New System.Windows.Forms.Button
        Me.txtTotalDebit = New System.Windows.Forms.Label
        Me.txtTotalCredit = New System.Windows.Forms.Label
        Me.txtChequeNo = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtPaidTo = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        CType(Me.tdbAccountName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbAccountCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TDBGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.tdbLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbTag, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbEmployee, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdAdd
        '
        Me.cmdAdd.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdAdd.Image = Global.General_Ledger.My.Resources.Resources.folder_add
        Me.cmdAdd.Location = New System.Drawing.Point(390, 14)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(51, 60)
        Me.cmdAdd.TabIndex = 0
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdAdd.UseVisualStyleBackColor = True
        Me.cmdAdd.Visible = False
        '
        'cmdExit
        '
        Me.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdExit.Image = Global.General_Ledger.My.Resources.Resources.folder_out
        Me.cmdExit.Location = New System.Drawing.Point(697, 14)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(51, 60)
        Me.cmdExit.TabIndex = 7
        Me.cmdExit.Text = "E&xit"
        Me.cmdExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdExit.UseVisualStyleBackColor = True
        '
        'cmdUndo
        '
        Me.cmdUndo.Image = Global.General_Ledger.My.Resources.Resources.folder_into
        Me.cmdUndo.Location = New System.Drawing.Point(595, 14)
        Me.cmdUndo.Name = "cmdUndo"
        Me.cmdUndo.Size = New System.Drawing.Size(51, 60)
        Me.cmdUndo.TabIndex = 5
        Me.cmdUndo.Text = "&Undo"
        Me.cmdUndo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdUndo.UseVisualStyleBackColor = True
        Me.cmdUndo.Visible = False
        '
        'cmdSearch
        '
        Me.cmdSearch.Image = Global.General_Ledger.My.Resources.Resources.folder_view
        Me.cmdSearch.Location = New System.Drawing.Point(339, 14)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.Size = New System.Drawing.Size(51, 60)
        Me.cmdSearch.TabIndex = 1
        Me.cmdSearch.Text = "Searc&h"
        Me.cmdSearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdSearch.UseVisualStyleBackColor = True
        Me.cmdSearch.Visible = False
        '
        'cmdEdit
        '
        Me.cmdEdit.Image = Global.General_Ledger.My.Resources.Resources.folder_edit
        Me.cmdEdit.Location = New System.Drawing.Point(442, 14)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(51, 60)
        Me.cmdEdit.TabIndex = 2
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdEdit.UseVisualStyleBackColor = True
        Me.cmdEdit.Visible = False
        '
        'cmdDelete
        '
        Me.cmdDelete.Image = Global.General_Ledger.My.Resources.Resources.folder_delete
        Me.cmdDelete.Location = New System.Drawing.Point(544, 14)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(51, 60)
        Me.cmdDelete.TabIndex = 4
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdDelete.UseVisualStyleBackColor = True
        Me.cmdDelete.Visible = False
        '
        'cmdPrint
        '
        Me.cmdPrint.Image = Global.General_Ledger.My.Resources.Resources.folder_document
        Me.cmdPrint.Location = New System.Drawing.Point(646, 14)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.Size = New System.Drawing.Size(51, 60)
        Me.cmdPrint.TabIndex = 6
        Me.cmdPrint.Text = "&Print"
        Me.cmdPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdPrint.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Image = Global.General_Ledger.My.Resources.Resources.folder_new
        Me.cmdSave.Location = New System.Drawing.Point(493, 14)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(51, 60)
        Me.cmdSave.TabIndex = 3
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdSave.UseVisualStyleBackColor = True
        Me.cmdSave.Visible = False
        '
        'txtDescription
        '
        Me.txtDescription.Location = New System.Drawing.Point(122, 148)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(626, 20)
        Me.txtDescription.TabIndex = 13
        '
        'txtVoucherNo
        '
        Me.txtVoucherNo.Location = New System.Drawing.Point(122, 123)
        Me.txtVoucherNo.Name = "txtVoucherNo"
        Me.txtVoucherNo.Size = New System.Drawing.Size(153, 20)
        Me.txtVoucherNo.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 151)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Description :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 126)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Voucher No. :"
        '
        'tdbAccountName
        '
        Me.tdbAccountName.AllowColMove = True
        Me.tdbAccountName.AllowColSelect = True
        Me.tdbAccountName.AllowDrop = True
        Me.tdbAccountName.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbAccountName.AlternatingRows = True
        Me.tdbAccountName.BackColor = System.Drawing.SystemColors.Control
        Me.tdbAccountName.CaptionStyle = Style1
        Me.tdbAccountName.ColumnCaptionHeight = 17
        Me.tdbAccountName.ColumnFooterHeight = 17
        Me.tdbAccountName.EvenRowStyle = Style2
        Me.tdbAccountName.FetchRowStyles = False
        Me.tdbAccountName.FooterStyle = Style3
        Me.tdbAccountName.HeadingStyle = Style4
        Me.tdbAccountName.HighLightRowStyle = Style5
        Me.tdbAccountName.Images.Add(CType(resources.GetObject("tdbAccountName.Images"), System.Drawing.Image))
        Me.tdbAccountName.Location = New System.Drawing.Point(29, 247)
        Me.tdbAccountName.Name = "tdbAccountName"
        Me.tdbAccountName.OddRowStyle = Style6
        Me.tdbAccountName.RecordSelectorStyle = Style7
        Me.tdbAccountName.RowDivider.Color = System.Drawing.Color.Blue
        Me.tdbAccountName.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbAccountName.RowSubDividerColor = System.Drawing.Color.Blue
        Me.tdbAccountName.ScrollTips = False
        Me.tdbAccountName.Size = New System.Drawing.Size(513, 215)
        Me.tdbAccountName.Style = Style8
        Me.tdbAccountName.TabIndex = 22
        Me.tdbAccountName.TabStop = False
        Me.tdbAccountName.Text = "C1TrueDBDropdown1"
        Me.tdbAccountName.ValueTranslate = True
        Me.tdbAccountName.Visible = False
        Me.tdbAccountName.VisualStyle = C1.Win.C1TrueDBGrid.VisualStyle.Office2007Blue
        Me.tdbAccountName.PropBag = resources.GetString("tdbAccountName.PropBag")
        '
        'txtDate
        '
        Me.txtDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtDate.Calendar.AnnuallyBoldedDates = New Date(-1) {}
        Me.txtDate.Calendar.BoldedDates = New Date(-1) {}
        Me.txtDate.Calendar.ClearText = "&Clear"
        Me.txtDate.Calendar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDate.Calendar.Margin = New System.Windows.Forms.Padding(0)
        Me.txtDate.Calendar.MonthlyBoldedDates = New Date(-1) {}
        Me.txtDate.Calendar.SelectedDate = New Date(2008, 7, 11, 0, 0, 0, 0)
        Me.txtDate.Calendar.TodayText = "&Today"
        Me.txtDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.System
        Me.txtDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.System
        Me.txtDate.Culture = 1056
        Me.txtDate.CustomFormat = "dd/MM/yyyy"
        Me.txtDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtDate.Location = New System.Drawing.Point(340, 122)
        Me.txtDate.Name = "txtDate"
        Me.txtDate.Size = New System.Drawing.Size(186, 19)
        Me.txtDate.TabIndex = 10
        Me.txtDate.Tag = Nothing
        Me.txtDate.TrimEnd = False
        Me.txtDate.Value = New Date(2008, 7, 1, 0, 0, 0, 0)
        Me.txtDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(518, 505)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Total :"
        '
        'tdbAccountCode
        '
        Me.tdbAccountCode.AllowColMove = True
        Me.tdbAccountCode.AllowColSelect = True
        Me.tdbAccountCode.AllowDrop = True
        Me.tdbAccountCode.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbAccountCode.AlternatingRows = True
        Me.tdbAccountCode.CaptionStyle = Style9
        Me.tdbAccountCode.ColumnCaptionHeight = 17
        Me.tdbAccountCode.ColumnFooterHeight = 17
        Me.tdbAccountCode.EvenRowStyle = Style10
        Me.tdbAccountCode.FetchRowStyles = False
        Me.tdbAccountCode.FooterStyle = Style11
        Me.tdbAccountCode.HeadingStyle = Style12
        Me.tdbAccountCode.HighLightRowStyle = Style13
        Me.tdbAccountCode.Images.Add(CType(resources.GetObject("tdbAccountCode.Images"), System.Drawing.Image))
        Me.tdbAccountCode.Location = New System.Drawing.Point(304, 247)
        Me.tdbAccountCode.Name = "tdbAccountCode"
        Me.tdbAccountCode.OddRowStyle = Style14
        Me.tdbAccountCode.RecordSelectorStyle = Style15
        Me.tdbAccountCode.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbAccountCode.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbAccountCode.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbAccountCode.ScrollTips = False
        Me.tdbAccountCode.Size = New System.Drawing.Size(404, 215)
        Me.tdbAccountCode.Style = Style16
        Me.tdbAccountCode.TabIndex = 25
        Me.tdbAccountCode.Text = "C1TrueDBDropdown2"
        Me.tdbAccountCode.ValueTranslate = True
        Me.tdbAccountCode.Visible = False
        Me.tdbAccountCode.VisualStyle = C1.Win.C1TrueDBGrid.VisualStyle.Office2007Blue
        Me.tdbAccountCode.PropBag = resources.GetString("tdbAccountCode.PropBag")
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(298, 125)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Date :"
        '
        'lblVoucherType
        '
        Me.lblVoucherType.AutoSize = True
        Me.lblVoucherType.Location = New System.Drawing.Point(33, 98)
        Me.lblVoucherType.Name = "lblVoucherType"
        Me.lblVoucherType.Size = New System.Drawing.Size(80, 13)
        Me.lblVoucherType.TabIndex = 31
        Me.lblVoucherType.Text = "Voucher Type :"
        Me.lblVoucherType.Visible = False
        '
        'cmbVoucherType
        '
        Me.cmbVoucherType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbVoucherType.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbVoucherType.FormattingEnabled = True
        Me.cmbVoucherType.Items.AddRange(New Object() {"Payment Voucher", "Receipt Voucher"})
        Me.cmbVoucherType.Location = New System.Drawing.Point(122, 95)
        Me.cmbVoucherType.Name = "cmbVoucherType"
        Me.cmbVoucherType.Size = New System.Drawing.Size(153, 21)
        Me.cmbVoucherType.TabIndex = 8
        Me.cmbVoucherType.Visible = False
        '
        'TDBGrid1
        '
        Me.TDBGrid1.AllowAddNew = True
        Me.TDBGrid1.AllowColSelect = False
        Me.TDBGrid1.AllowDelete = True
        Me.TDBGrid1.AllowFilter = False
        Me.TDBGrid1.AllowSort = False
        Me.TDBGrid1.AlternatingRows = True
        Me.TDBGrid1.CaptionHeight = 17
        Me.TDBGrid1.EmptyRows = True
        Me.TDBGrid1.GroupByCaption = "Drag a column header here to group by that column"
        Me.TDBGrid1.Images.Add(CType(resources.GetObject("TDBGrid1.Images"), System.Drawing.Image))
        Me.TDBGrid1.Images.Add(CType(resources.GetObject("TDBGrid1.Images1"), System.Drawing.Image))
        Me.TDBGrid1.Images.Add(CType(resources.GetObject("TDBGrid1.Images2"), System.Drawing.Image))
        Me.TDBGrid1.Images.Add(CType(resources.GetObject("TDBGrid1.Images3"), System.Drawing.Image))
        Me.TDBGrid1.Location = New System.Drawing.Point(12, 203)
        Me.TDBGrid1.Name = "TDBGrid1"
        Me.TDBGrid1.PreviewInfo.Location = New System.Drawing.Point(0, 0)
        Me.TDBGrid1.PreviewInfo.Size = New System.Drawing.Size(0, 0)
        Me.TDBGrid1.PreviewInfo.ZoomFactor = 75
        Me.TDBGrid1.PrintInfo.PageSettings = CType(resources.GetObject("TDBGrid1.PrintInfo.PageSettings"), System.Drawing.Printing.PageSettings)
        Me.TDBGrid1.RecordSelectors = False
        Me.TDBGrid1.Size = New System.Drawing.Size(738, 292)
        Me.TDBGrid1.TabIndex = 14
        Me.TDBGrid1.Text = "C1TrueDBGrid1"
        Me.TDBGrid1.VisualStyle = C1.Win.C1TrueDBGrid.VisualStyle.Office2007Blue
        Me.TDBGrid1.WrapCellPointer = True
        Me.TDBGrid1.PropBag = resources.GetString("TDBGrid1.PropBag")
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblHeading})
        Me.ToolStrip1.Location = New System.Drawing.Point(-1, 9)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(760, 71)
        Me.ToolStrip1.TabIndex = 33
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'lblHeading
        '
        Me.lblHeading.Font = New System.Drawing.Font("Trebuchet MS", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(54, 68)
        Me.lblHeading.Text = "JV"
        '
        'tdbLocation
        '
        Me.tdbLocation.AllowColMove = True
        Me.tdbLocation.AllowColSelect = True
        Me.tdbLocation.AllowDrop = True
        Me.tdbLocation.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbLocation.AlternatingRows = True
        Me.tdbLocation.CaptionStyle = Style17
        Me.tdbLocation.ColumnCaptionHeight = 17
        Me.tdbLocation.ColumnFooterHeight = 17
        Me.tdbLocation.EvenRowStyle = Style18
        Me.tdbLocation.FetchRowStyles = False
        Me.tdbLocation.FooterStyle = Style19
        Me.tdbLocation.HeadingStyle = Style20
        Me.tdbLocation.HighLightRowStyle = Style21
        Me.tdbLocation.Images.Add(CType(resources.GetObject("tdbLocation.Images"), System.Drawing.Image))
        Me.tdbLocation.Location = New System.Drawing.Point(356, 265)
        Me.tdbLocation.Name = "tdbLocation"
        Me.tdbLocation.OddRowStyle = Style22
        Me.tdbLocation.RecordSelectorStyle = Style23
        Me.tdbLocation.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbLocation.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbLocation.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbLocation.ScrollTips = False
        Me.tdbLocation.Size = New System.Drawing.Size(352, 203)
        Me.tdbLocation.Style = Style24
        Me.tdbLocation.TabIndex = 38
        Me.tdbLocation.TabStop = False
        Me.tdbLocation.Text = "C1TrueDBDropdown2"
        Me.tdbLocation.ValueTranslate = True
        Me.tdbLocation.Visible = False
        Me.tdbLocation.VisualStyle = C1.Win.C1TrueDBGrid.VisualStyle.Office2007Blue
        Me.tdbLocation.PropBag = resources.GetString("tdbLocation.PropBag")
        '
        'tdbTag
        '
        Me.tdbTag.AllowColMove = True
        Me.tdbTag.AllowColSelect = True
        Me.tdbTag.AllowDrop = True
        Me.tdbTag.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbTag.AlternatingRows = True
        Me.tdbTag.CaptionStyle = Style25
        Me.tdbTag.ColumnCaptionHeight = 17
        Me.tdbTag.ColumnFooterHeight = 17
        Me.tdbTag.EvenRowStyle = Style26
        Me.tdbTag.FetchRowStyles = False
        Me.tdbTag.FooterStyle = Style27
        Me.tdbTag.HeadingStyle = Style28
        Me.tdbTag.HighLightRowStyle = Style29
        Me.tdbTag.Images.Add(CType(resources.GetObject("tdbTag.Images"), System.Drawing.Image))
        Me.tdbTag.Location = New System.Drawing.Point(356, 253)
        Me.tdbTag.Name = "tdbTag"
        Me.tdbTag.OddRowStyle = Style30
        Me.tdbTag.RecordSelectorStyle = Style31
        Me.tdbTag.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbTag.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbTag.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbTag.ScrollTips = False
        Me.tdbTag.Size = New System.Drawing.Size(202, 215)
        Me.tdbTag.Style = Style32
        Me.tdbTag.TabIndex = 37
        Me.tdbTag.TabStop = False
        Me.tdbTag.Text = "C1TrueDBDropdown2"
        Me.tdbTag.ValueTranslate = True
        Me.tdbTag.Visible = False
        Me.tdbTag.VisualStyle = C1.Win.C1TrueDBGrid.VisualStyle.Office2007Blue
        Me.tdbTag.PropBag = resources.GetString("tdbTag.PropBag")
        '
        'tdbEmployee
        '
        Me.tdbEmployee.AllowColMove = True
        Me.tdbEmployee.AllowColSelect = True
        Me.tdbEmployee.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbEmployee.AlternatingRows = False
        Me.tdbEmployee.CaptionStyle = Style33
        Me.tdbEmployee.ColumnCaptionHeight = 17
        Me.tdbEmployee.ColumnFooterHeight = 17
        Me.tdbEmployee.EvenRowStyle = Style34
        Me.tdbEmployee.FetchRowStyles = False
        Me.tdbEmployee.FooterStyle = Style35
        Me.tdbEmployee.HeadingStyle = Style36
        Me.tdbEmployee.HighLightRowStyle = Style37
        Me.tdbEmployee.Images.Add(CType(resources.GetObject("tdbEmployee.Images"), System.Drawing.Image))
        Me.tdbEmployee.Location = New System.Drawing.Point(392, 283)
        Me.tdbEmployee.Name = "tdbEmployee"
        Me.tdbEmployee.OddRowStyle = Style38
        Me.tdbEmployee.RecordSelectorStyle = Style39
        Me.tdbEmployee.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbEmployee.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbEmployee.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbEmployee.ScrollTips = False
        Me.tdbEmployee.Size = New System.Drawing.Size(224, 181)
        Me.tdbEmployee.Style = Style40
        Me.tdbEmployee.TabIndex = 39
        Me.tdbEmployee.TabStop = False
        Me.tdbEmployee.Text = "C1TrueDBDropdown1"
        Me.tdbEmployee.ValueTranslate = True
        Me.tdbEmployee.Visible = False
        Me.tdbEmployee.PropBag = resources.GetString("tdbEmployee.PropBag")
        '
        'cmdRefresh
        '
        Me.cmdRefresh.Image = Global.General_Ledger.My.Resources.Resources.folder_refresh
        Me.cmdRefresh.Location = New System.Drawing.Point(285, 15)
        Me.cmdRefresh.Name = "cmdRefresh"
        Me.cmdRefresh.Size = New System.Drawing.Size(52, 58)
        Me.cmdRefresh.TabIndex = 40
        Me.cmdRefresh.Text = "&Refresh"
        Me.cmdRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdRefresh.UseVisualStyleBackColor = True
        Me.cmdRefresh.Visible = False
        '
        'txtTotalDebit
        '
        Me.txtTotalDebit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtTotalDebit.Location = New System.Drawing.Point(561, 501)
        Me.txtTotalDebit.Name = "txtTotalDebit"
        Me.txtTotalDebit.Size = New System.Drawing.Size(90, 20)
        Me.txtTotalDebit.TabIndex = 25
        Me.txtTotalDebit.Text = "0"
        Me.txtTotalDebit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTotalCredit
        '
        Me.txtTotalCredit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtTotalCredit.Location = New System.Drawing.Point(657, 501)
        Me.txtTotalCredit.Name = "txtTotalCredit"
        Me.txtTotalCredit.Size = New System.Drawing.Size(90, 20)
        Me.txtTotalCredit.TabIndex = 25
        Me.txtTotalCredit.Text = "0"
        Me.txtTotalCredit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtChequeNo
        '
        Me.txtChequeNo.Location = New System.Drawing.Point(621, 123)
        Me.txtChequeNo.Name = "txtChequeNo"
        Me.txtChequeNo.Size = New System.Drawing.Size(126, 20)
        Me.txtChequeNo.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(539, 126)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 13)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Cheque No. :"
        '
        'txtPaidTo
        '
        Me.txtPaidTo.Location = New System.Drawing.Point(122, 174)
        Me.txtPaidTo.MaxLength = 200
        Me.txtPaidTo.Name = "txtPaidTo"
        Me.txtPaidTo.Size = New System.Drawing.Size(626, 20)
        Me.txtPaidTo.TabIndex = 41
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(33, 177)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 42
        Me.Label6.Text = "Paid To"
        '
        'frmJv
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.cmdExit
        Me.ClientSize = New System.Drawing.Size(759, 527)
        Me.Controls.Add(Me.txtPaidTo)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtDescription)
        Me.Controls.Add(Me.txtTotalCredit)
        Me.Controls.Add(Me.cmdRefresh)
        Me.Controls.Add(Me.txtTotalDebit)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tdbEmployee)
        Me.Controls.Add(Me.tdbLocation)
        Me.Controls.Add(Me.tdbTag)
        Me.Controls.Add(Me.cmdAdd)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.cmdUndo)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdPrint)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.lblVoucherType)
        Me.Controls.Add(Me.cmbVoucherType)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tdbAccountCode)
        Me.Controls.Add(Me.txtDate)
        Me.Controls.Add(Me.tdbAccountName)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtChequeNo)
        Me.Controls.Add(Me.txtVoucherNo)
        Me.Controls.Add(Me.TDBGrid1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmJv"
        Me.Text = "Journal Voucher"
        CType(Me.tdbAccountName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbAccountCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TDBGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        CType(Me.tdbLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbTag, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbEmployee, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdExit As System.Windows.Forms.Button
    Friend WithEvents cmdUndo As System.Windows.Forms.Button
    Friend WithEvents cmdSearch As System.Windows.Forms.Button
    Friend WithEvents cmdEdit As System.Windows.Forms.Button
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
    Friend WithEvents cmdPrint As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents txtVoucherNo As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tdbAccountName As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents txtDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tdbAccountCode As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents lblVoucherType As System.Windows.Forms.Label
    Friend WithEvents cmbVoucherType As System.Windows.Forms.ComboBox
    Friend WithEvents TDBGrid1 As C1.Win.C1TrueDBGrid.C1TrueDBGrid
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents lblHeading As System.Windows.Forms.ToolStripLabel
    Friend WithEvents tdbLocation As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents tdbTag As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents tdbEmployee As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents cmdRefresh As System.Windows.Forms.Button
    Friend WithEvents txtTotalDebit As System.Windows.Forms.Label
    Friend WithEvents txtTotalCredit As System.Windows.Forms.Label
    Friend WithEvents txtChequeNo As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtPaidTo As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
