﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRecoveryFollowup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRecoveryFollowup))
        Dim Style1 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style2 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style3 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style4 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style5 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style6 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style7 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style8 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style9 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style10 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style11 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style12 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style13 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style14 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style15 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style16 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style17 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style18 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style19 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style20 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style21 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style22 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style23 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style24 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style25 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style26 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style27 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style28 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style29 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style30 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style31 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style32 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style33 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style34 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style35 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style36 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style37 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style38 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style39 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style40 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style41 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style42 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style43 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style44 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style45 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style46 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style47 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Dim Style48 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtDate = New C1.Win.C1Input.C1DateEdit
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmbFollowupType = New System.Windows.Forms.ComboBox
        Me.tdbGridFollowup = New C1.Win.C1TrueDBGrid.C1TrueDBGrid
        Me.cmdRefresh = New System.Windows.Forms.Button
        Me.cmdExit = New System.Windows.Forms.Button
        Me.cmdSave = New System.Windows.Forms.Button
        Me.tdbUnit = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.tdbCustomer = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.tdbMobile = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.tdbPhone = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.tdbEmail = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        Me.cmbProject = New C1.Win.C1List.C1Combo
        Me.Label2 = New System.Windows.Forms.Label
        Me.tdbUnitType = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown
        CType(Me.txtDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbGridFollowup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbUnit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbMobile, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbPhone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbEmail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbUnitType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 15)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Followup Date :"
        '
        'txtDate
        '
        Me.txtDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtDate.Calendar.AnnuallyBoldedDates = New Date(-1) {}
        Me.txtDate.Calendar.BoldedDates = New Date(-1) {}
        Me.txtDate.Calendar.ClearText = "&Clear"
        Me.txtDate.Calendar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDate.Calendar.Margin = New System.Windows.Forms.Padding(0)
        Me.txtDate.Calendar.MonthlyBoldedDates = New Date(-1) {}
        Me.txtDate.Calendar.SelectedDate = New Date(2008, 7, 11, 0, 0, 0, 0)
        Me.txtDate.Calendar.TodayText = "&Today"
        Me.txtDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.System
        Me.txtDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.System
        Me.txtDate.Culture = 1056
        Me.txtDate.CustomFormat = "dd/MM/yyyy"
        Me.txtDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtDate.Location = New System.Drawing.Point(100, 12)
        Me.txtDate.Name = "txtDate"
        Me.txtDate.Size = New System.Drawing.Size(135, 19)
        Me.txtDate.TabIndex = 12
        Me.txtDate.Tag = Nothing
        Me.txtDate.TrimEnd = False
        Me.txtDate.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(260, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Followup Type"
        '
        'cmbFollowupType
        '
        Me.cmbFollowupType.FormattingEnabled = True
        Me.cmbFollowupType.Items.AddRange(New Object() {"30 Days", "60 Days", "90 Days", "Over 90 Days"})
        Me.cmbFollowupType.Location = New System.Drawing.Point(343, 11)
        Me.cmbFollowupType.Name = "cmbFollowupType"
        Me.cmbFollowupType.Size = New System.Drawing.Size(141, 21)
        Me.cmbFollowupType.TabIndex = 14
        '
        'tdbGridFollowup
        '
        Me.tdbGridFollowup.AllowDelete = True
        Me.tdbGridFollowup.ColumnFooters = True
        Me.tdbGridFollowup.EmptyRows = True
        Me.tdbGridFollowup.GroupByCaption = "Drag a column header here to group by that column"
        Me.tdbGridFollowup.Images.Add(CType(resources.GetObject("tdbGridFollowup.Images"), System.Drawing.Image))
        Me.tdbGridFollowup.Location = New System.Drawing.Point(12, 38)
        Me.tdbGridFollowup.Name = "tdbGridFollowup"
        Me.tdbGridFollowup.PreviewInfo.Location = New System.Drawing.Point(0, 0)
        Me.tdbGridFollowup.PreviewInfo.Size = New System.Drawing.Size(0, 0)
        Me.tdbGridFollowup.PreviewInfo.ZoomFactor = 75
        Me.tdbGridFollowup.PrintInfo.PageSettings = CType(resources.GetObject("tdbGridFollowup.PrintInfo.PageSettings"), System.Drawing.Printing.PageSettings)
        Me.tdbGridFollowup.RecordSelectors = False
        Me.tdbGridFollowup.Size = New System.Drawing.Size(902, 432)
        Me.tdbGridFollowup.TabIndex = 180
        Me.tdbGridFollowup.Text = "C1TrueDBGrid1"
        Me.tdbGridFollowup.VisualStyle = C1.Win.C1TrueDBGrid.VisualStyle.Office2007Silver
        Me.tdbGridFollowup.WrapCellPointer = True
        Me.tdbGridFollowup.PropBag = resources.GetString("tdbGridFollowup.PropBag")
        '
        'cmdRefresh
        '
        Me.cmdRefresh.Location = New System.Drawing.Point(839, 10)
        Me.cmdRefresh.Name = "cmdRefresh"
        Me.cmdRefresh.Size = New System.Drawing.Size(75, 23)
        Me.cmdRefresh.TabIndex = 181
        Me.cmdRefresh.Text = "Refresh"
        Me.cmdRefresh.UseVisualStyleBackColor = True
        '
        'cmdExit
        '
        Me.cmdExit.Location = New System.Drawing.Point(839, 477)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(75, 23)
        Me.cmdExit.TabIndex = 182
        Me.cmdExit.Text = "E&xit"
        Me.cmdExit.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(763, 477)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(75, 23)
        Me.cmdSave.TabIndex = 183
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'tdbUnit
        '
        Me.tdbUnit.AllowColMove = True
        Me.tdbUnit.AllowColSelect = True
        Me.tdbUnit.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbUnit.AlternatingRows = False
        Me.tdbUnit.CaptionStyle = Style1
        Me.tdbUnit.ColumnCaptionHeight = 17
        Me.tdbUnit.ColumnFooterHeight = 17
        Me.tdbUnit.EvenRowStyle = Style2
        Me.tdbUnit.FetchRowStyles = False
        Me.tdbUnit.FooterStyle = Style3
        Me.tdbUnit.HeadingStyle = Style4
        Me.tdbUnit.HighLightRowStyle = Style5
        Me.tdbUnit.Images.Add(CType(resources.GetObject("tdbUnit.Images"), System.Drawing.Image))
        Me.tdbUnit.Location = New System.Drawing.Point(15, 71)
        Me.tdbUnit.Name = "tdbUnit"
        Me.tdbUnit.OddRowStyle = Style6
        Me.tdbUnit.RecordSelectorStyle = Style7
        Me.tdbUnit.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbUnit.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbUnit.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbUnit.ScrollTips = False
        Me.tdbUnit.Size = New System.Drawing.Size(388, 209)
        Me.tdbUnit.Style = Style8
        Me.tdbUnit.TabIndex = 187
        Me.tdbUnit.TabStop = False
        Me.tdbUnit.Text = "C1TrueDBDropdown1"
        Me.tdbUnit.ValueTranslate = True
        Me.tdbUnit.Visible = False
        Me.tdbUnit.PropBag = resources.GetString("tdbUnit.PropBag")
        '
        'tdbCustomer
        '
        Me.tdbCustomer.AllowColMove = True
        Me.tdbCustomer.AllowColSelect = True
        Me.tdbCustomer.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbCustomer.AlternatingRows = False
        Me.tdbCustomer.CaptionStyle = Style9
        Me.tdbCustomer.ColumnCaptionHeight = 17
        Me.tdbCustomer.ColumnFooterHeight = 17
        Me.tdbCustomer.EvenRowStyle = Style10
        Me.tdbCustomer.FetchRowStyles = False
        Me.tdbCustomer.FooterStyle = Style11
        Me.tdbCustomer.HeadingStyle = Style12
        Me.tdbCustomer.HighLightRowStyle = Style13
        Me.tdbCustomer.Images.Add(CType(resources.GetObject("tdbCustomer.Images"), System.Drawing.Image))
        Me.tdbCustomer.Location = New System.Drawing.Point(171, 71)
        Me.tdbCustomer.Name = "tdbCustomer"
        Me.tdbCustomer.OddRowStyle = Style14
        Me.tdbCustomer.RecordSelectorStyle = Style15
        Me.tdbCustomer.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbCustomer.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbCustomer.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbCustomer.ScrollTips = False
        Me.tdbCustomer.Size = New System.Drawing.Size(388, 209)
        Me.tdbCustomer.Style = Style16
        Me.tdbCustomer.TabIndex = 188
        Me.tdbCustomer.TabStop = False
        Me.tdbCustomer.Text = "C1TrueDBDropdown1"
        Me.tdbCustomer.ValueTranslate = True
        Me.tdbCustomer.Visible = False
        Me.tdbCustomer.PropBag = resources.GetString("tdbCustomer.PropBag")
        '
        'tdbMobile
        '
        Me.tdbMobile.AllowColMove = True
        Me.tdbMobile.AllowColSelect = True
        Me.tdbMobile.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbMobile.AlternatingRows = False
        Me.tdbMobile.CaptionStyle = Style17
        Me.tdbMobile.ColumnCaptionHeight = 17
        Me.tdbMobile.ColumnFooterHeight = 17
        Me.tdbMobile.EvenRowStyle = Style18
        Me.tdbMobile.FetchRowStyles = False
        Me.tdbMobile.FooterStyle = Style19
        Me.tdbMobile.HeadingStyle = Style20
        Me.tdbMobile.HighLightRowStyle = Style21
        Me.tdbMobile.Images.Add(CType(resources.GetObject("tdbMobile.Images"), System.Drawing.Image))
        Me.tdbMobile.Location = New System.Drawing.Point(301, 71)
        Me.tdbMobile.Name = "tdbMobile"
        Me.tdbMobile.OddRowStyle = Style22
        Me.tdbMobile.RecordSelectorStyle = Style23
        Me.tdbMobile.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbMobile.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbMobile.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbMobile.ScrollTips = False
        Me.tdbMobile.Size = New System.Drawing.Size(388, 209)
        Me.tdbMobile.Style = Style24
        Me.tdbMobile.TabIndex = 189
        Me.tdbMobile.TabStop = False
        Me.tdbMobile.Text = "C1TrueDBDropdown1"
        Me.tdbMobile.ValueTranslate = True
        Me.tdbMobile.Visible = False
        Me.tdbMobile.PropBag = resources.GetString("tdbMobile.PropBag")
        '
        'tdbPhone
        '
        Me.tdbPhone.AllowColMove = True
        Me.tdbPhone.AllowColSelect = True
        Me.tdbPhone.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbPhone.AlternatingRows = False
        Me.tdbPhone.CaptionStyle = Style25
        Me.tdbPhone.ColumnCaptionHeight = 17
        Me.tdbPhone.ColumnFooterHeight = 17
        Me.tdbPhone.EvenRowStyle = Style26
        Me.tdbPhone.FetchRowStyles = False
        Me.tdbPhone.FooterStyle = Style27
        Me.tdbPhone.HeadingStyle = Style28
        Me.tdbPhone.HighLightRowStyle = Style29
        Me.tdbPhone.Images.Add(CType(resources.GetObject("tdbPhone.Images"), System.Drawing.Image))
        Me.tdbPhone.Location = New System.Drawing.Point(399, 71)
        Me.tdbPhone.Name = "tdbPhone"
        Me.tdbPhone.OddRowStyle = Style30
        Me.tdbPhone.RecordSelectorStyle = Style31
        Me.tdbPhone.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbPhone.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbPhone.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbPhone.ScrollTips = False
        Me.tdbPhone.Size = New System.Drawing.Size(388, 209)
        Me.tdbPhone.Style = Style32
        Me.tdbPhone.TabIndex = 190
        Me.tdbPhone.TabStop = False
        Me.tdbPhone.Text = "C1TrueDBDropdown1"
        Me.tdbPhone.ValueTranslate = True
        Me.tdbPhone.Visible = False
        Me.tdbPhone.PropBag = resources.GetString("tdbPhone.PropBag")
        '
        'tdbEmail
        '
        Me.tdbEmail.AllowColMove = True
        Me.tdbEmail.AllowColSelect = True
        Me.tdbEmail.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbEmail.AlternatingRows = False
        Me.tdbEmail.CaptionStyle = Style33
        Me.tdbEmail.ColumnCaptionHeight = 17
        Me.tdbEmail.ColumnFooterHeight = 17
        Me.tdbEmail.EvenRowStyle = Style34
        Me.tdbEmail.FetchRowStyles = False
        Me.tdbEmail.FooterStyle = Style35
        Me.tdbEmail.HeadingStyle = Style36
        Me.tdbEmail.HighLightRowStyle = Style37
        Me.tdbEmail.Images.Add(CType(resources.GetObject("tdbEmail.Images"), System.Drawing.Image))
        Me.tdbEmail.Location = New System.Drawing.Point(514, 71)
        Me.tdbEmail.Name = "tdbEmail"
        Me.tdbEmail.OddRowStyle = Style38
        Me.tdbEmail.RecordSelectorStyle = Style39
        Me.tdbEmail.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbEmail.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbEmail.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbEmail.ScrollTips = False
        Me.tdbEmail.Size = New System.Drawing.Size(388, 209)
        Me.tdbEmail.Style = Style40
        Me.tdbEmail.TabIndex = 192
        Me.tdbEmail.TabStop = False
        Me.tdbEmail.Text = "C1TrueDBDropdown1"
        Me.tdbEmail.ValueTranslate = True
        Me.tdbEmail.Visible = False
        Me.tdbEmail.PropBag = resources.GetString("tdbEmail.PropBag")
        '
        'cmbProject
        '
        Me.cmbProject.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbProject.AutoDropDown = True
        Me.cmbProject.Caption = ""
        Me.cmbProject.CaptionHeight = 17
        Me.cmbProject.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbProject.ColumnCaptionHeight = 17
        Me.cmbProject.ColumnFooterHeight = 17
        Me.cmbProject.ColumnHeaders = False
        Me.cmbProject.ContentHeight = 15
        Me.cmbProject.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbProject.DisplayMember = "AccountName"
        Me.cmbProject.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbProject.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProject.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbProject.EditorHeight = 15
        Me.cmbProject.Images.Add(CType(resources.GetObject("cmbProject.Images"), System.Drawing.Image))
        Me.cmbProject.ItemHeight = 15
        Me.cmbProject.Location = New System.Drawing.Point(563, 11)
        Me.cmbProject.MatchEntryTimeout = CType(2000, Long)
        Me.cmbProject.MaxDropDownItems = CType(5, Short)
        Me.cmbProject.MaxLength = 32767
        Me.cmbProject.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbProject.Name = "cmbProject"
        Me.cmbProject.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbProject.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbProject.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbProject.Size = New System.Drawing.Size(240, 21)
        Me.cmbProject.TabIndex = 193
        Me.cmbProject.ValueMember = "AccountCode"
        Me.cmbProject.PropBag = resources.GetString("cmbProject.PropBag")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(511, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 194
        Me.Label2.Text = "Project"
        '
        'tdbUnitType
        '
        Me.tdbUnitType.AllowColMove = True
        Me.tdbUnitType.AllowColSelect = True
        Me.tdbUnitType.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbUnitType.AlternatingRows = False
        Me.tdbUnitType.CaptionStyle = Style41
        Me.tdbUnitType.ColumnCaptionHeight = 17
        Me.tdbUnitType.ColumnFooterHeight = 17
        Me.tdbUnitType.EvenRowStyle = Style42
        Me.tdbUnitType.FetchRowStyles = False
        Me.tdbUnitType.FooterStyle = Style43
        Me.tdbUnitType.HeadingStyle = Style44
        Me.tdbUnitType.HighLightRowStyle = Style45
        Me.tdbUnitType.Images.Add(CType(resources.GetObject("tdbUnitType.Images"), System.Drawing.Image))
        Me.tdbUnitType.Location = New System.Drawing.Point(12, 105)
        Me.tdbUnitType.Name = "tdbUnitType"
        Me.tdbUnitType.OddRowStyle = Style46
        Me.tdbUnitType.RecordSelectorStyle = Style47
        Me.tdbUnitType.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbUnitType.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbUnitType.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbUnitType.ScrollTips = False
        Me.tdbUnitType.Size = New System.Drawing.Size(388, 209)
        Me.tdbUnitType.Style = Style48
        Me.tdbUnitType.TabIndex = 195
        Me.tdbUnitType.TabStop = False
        Me.tdbUnitType.Text = "C1TrueDBDropdown1"
        Me.tdbUnitType.ValueTranslate = True
        Me.tdbUnitType.Visible = False
        Me.tdbUnitType.PropBag = resources.GetString("tdbUnitType.PropBag")
        '
        'frmRecoveryFollowup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(926, 512)
        Me.Controls.Add(Me.tdbUnitType)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmbProject)
        Me.Controls.Add(Me.tdbEmail)
        Me.Controls.Add(Me.tdbPhone)
        Me.Controls.Add(Me.tdbMobile)
        Me.Controls.Add(Me.tdbCustomer)
        Me.Controls.Add(Me.tdbUnit)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.cmdRefresh)
        Me.Controls.Add(Me.tdbGridFollowup)
        Me.Controls.Add(Me.cmbFollowupType)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtDate)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmRecoveryFollowup"
        Me.Text = "Recovery Followup"
        CType(Me.txtDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbGridFollowup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbUnit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbMobile, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbPhone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbEmail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbUnitType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbFollowupType As System.Windows.Forms.ComboBox
    Friend WithEvents tdbGridFollowup As C1.Win.C1TrueDBGrid.C1TrueDBGrid
    Friend WithEvents cmdRefresh As System.Windows.Forms.Button
    Friend WithEvents cmdExit As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents tdbUnit As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents tdbCustomer As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents tdbMobile As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents tdbPhone As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents tdbEmail As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents cmbProject As C1.Win.C1List.C1Combo
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tdbUnitType As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
End Class
