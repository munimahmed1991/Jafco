﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProjectFile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProjectFile))
        Me.txtCode = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.chkLoanNotApplicable = New System.Windows.Forms.CheckBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.txtUnOfficialReceiptStart = New System.Windows.Forms.TextBox
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.txtOfficialReceiptStart = New System.Windows.Forms.TextBox
        Me.cmbProjectAccount = New C1.Win.C1List.C1Combo
        Me.cmbProject = New System.Windows.Forms.Label
        Me.cmbForfietAccount = New C1.Win.C1List.C1Combo
        Me.Label27 = New System.Windows.Forms.Label
        Me.cmbChequeAccount = New C1.Win.C1List.C1Combo
        Me.Label29 = New System.Windows.Forms.Label
        Me.cmbCashAccount = New C1.Win.C1List.C1Combo
        Me.Label30 = New System.Windows.Forms.Label
        Me.cmbPenaltyPolicy = New System.Windows.Forms.ComboBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.txtPenaltyPer = New C1.Win.C1Input.C1NumericEdit
        Me.cmbSector = New C1.Win.C1List.C1Combo
        Me.Label25 = New System.Windows.Forms.Label
        Me.cmbExtraCharges15 = New C1.Win.C1List.C1Combo
        Me.Label19 = New System.Windows.Forms.Label
        Me.cmbExtraCharges13 = New C1.Win.C1List.C1Combo
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.cmbExtraCharges12 = New C1.Win.C1List.C1Combo
        Me.cmbExtraCharges14 = New C1.Win.C1List.C1Combo
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.cmbExtraCharges11 = New C1.Win.C1List.C1Combo
        Me.cmbExtraCharges3 = New C1.Win.C1List.C1Combo
        Me.Label14 = New System.Windows.Forms.Label
        Me.cmbExtraCharges10 = New C1.Win.C1List.C1Combo
        Me.Label21 = New System.Windows.Forms.Label
        Me.cmbExtraCharges8 = New C1.Win.C1List.C1Combo
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.cmbExtraCharges7 = New C1.Win.C1List.C1Combo
        Me.cmbExtraCharges9 = New C1.Win.C1List.C1Combo
        Me.Label18 = New System.Windows.Forms.Label
        Me.cmbExtraCharges5 = New C1.Win.C1List.C1Combo
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.cmbExtraCharges4 = New C1.Win.C1List.C1Combo
        Me.cmbExtraCharges6 = New C1.Win.C1List.C1Combo
        Me.Label15 = New System.Windows.Forms.Label
        Me.cmbExtraCharges2 = New C1.Win.C1List.C1Combo
        Me.Label11 = New System.Windows.Forms.Label
        Me.cmbExtraCharges1 = New C1.Win.C1List.C1Combo
        Me.Label10 = New System.Windows.Forms.Label
        Me.cmdCityList = New System.Windows.Forms.Button
        Me.cmbCity = New C1.Win.C1List.C1Combo
        Me.Label9 = New System.Windows.Forms.Label
        Me.cmbCountry = New C1.Win.C1List.C1Combo
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtPrefix = New System.Windows.Forms.TextBox
        Me.cmbRegion = New C1.Win.C1List.C1Combo
        Me.Label5 = New System.Windows.Forms.Label
        Me.cmbProjectPurpose = New C1.Win.C1List.C1Combo
        Me.Label4 = New System.Windows.Forms.Label
        Me.cmbProjectType = New C1.Win.C1List.C1Combo
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtAddress = New System.Windows.Forms.TextBox
        Me.cmbName = New C1.Win.C1List.C1Combo
        Me.cmdAdd = New System.Windows.Forms.Button
        Me.cmdExit = New System.Windows.Forms.Button
        Me.cmdUndo = New System.Windows.Forms.Button
        Me.cmdSearch = New System.Windows.Forms.Button
        Me.cmdEdit = New System.Windows.Forms.Button
        Me.cmdSave = New System.Windows.Forms.Button
        Me.cmdDelete = New System.Windows.Forms.Button
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.cmbProjectAccount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbForfietAccount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbChequeAccount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbCashAccount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPenaltyPer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbSector, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbExtraCharges1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbCity, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbCountry, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbRegion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbProjectPurpose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbProjectType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbName, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtCode
        '
        Me.txtCode.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtCode.Location = New System.Drawing.Point(118, 12)
        Me.txtCode.Name = "txtCode"
        Me.txtCode.Size = New System.Drawing.Size(100, 20)
        Me.txtCode.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(26, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Code"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(26, 39)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Name"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1})
        Me.ToolStrip1.Location = New System.Drawing.Point(2, 4)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(807, 64)
        Me.ToolStrip1.TabIndex = 112
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Trebuchet MS", 24.0!, System.Drawing.FontStyle.Bold)
        Me.ToolStripLabel1.ForeColor = System.Drawing.SystemColors.Desktop
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(227, 61)
        Me.ToolStripLabel1.Text = "PROJECT FILE"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkLoanNotApplicable)
        Me.GroupBox2.Controls.Add(Me.Label35)
        Me.GroupBox2.Controls.Add(Me.Label36)
        Me.GroupBox2.Controls.Add(Me.txtUnOfficialReceiptStart)
        Me.GroupBox2.Controls.Add(Me.Label32)
        Me.GroupBox2.Controls.Add(Me.Label31)
        Me.GroupBox2.Controls.Add(Me.txtOfficialReceiptStart)
        Me.GroupBox2.Controls.Add(Me.cmbProjectAccount)
        Me.GroupBox2.Controls.Add(Me.cmbProject)
        Me.GroupBox2.Controls.Add(Me.cmbForfietAccount)
        Me.GroupBox2.Controls.Add(Me.Label27)
        Me.GroupBox2.Controls.Add(Me.cmbChequeAccount)
        Me.GroupBox2.Controls.Add(Me.Label29)
        Me.GroupBox2.Controls.Add(Me.cmbCashAccount)
        Me.GroupBox2.Controls.Add(Me.Label30)
        Me.GroupBox2.Controls.Add(Me.cmbPenaltyPolicy)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Controls.Add(Me.Label28)
        Me.GroupBox2.Controls.Add(Me.txtPenaltyPer)
        Me.GroupBox2.Controls.Add(Me.cmbSector)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges15)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges13)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges12)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges14)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.Label24)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges11)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges3)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges10)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges8)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges7)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges9)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges5)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges4)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges6)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges2)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.cmbExtraCharges1)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.cmdCityList)
        Me.GroupBox2.Controls.Add(Me.cmbCity)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.cmbCountry)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.txtPrefix)
        Me.GroupBox2.Controls.Add(Me.cmbRegion)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.cmbProjectPurpose)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.cmbProjectType)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtAddress)
        Me.GroupBox2.Controls.Add(Me.cmbName)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.txtCode)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 71)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(813, 435)
        Me.GroupBox2.TabIndex = 113
        Me.GroupBox2.TabStop = False
        '
        'chkLoanNotApplicable
        '
        Me.chkLoanNotApplicable.AutoSize = True
        Me.chkLoanNotApplicable.Location = New System.Drawing.Point(413, 64)
        Me.chkLoanNotApplicable.Name = "chkLoanNotApplicable"
        Me.chkLoanNotApplicable.Size = New System.Drawing.Size(122, 17)
        Me.chkLoanNotApplicable.TabIndex = 284
        Me.chkLoanNotApplicable.Text = "Loan Not Applicable"
        Me.chkLoanNotApplicable.UseVisualStyleBackColor = True
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(612, 39)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(79, 13)
        Me.Label35.TabIndex = 283
        Me.Label35.Text = "Receipt # Start"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(612, 16)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(67, 13)
        Me.Label36.TabIndex = 282
        Me.Label36.Text = "Un Official"
        '
        'txtUnOfficialReceiptStart
        '
        Me.txtUnOfficialReceiptStart.Location = New System.Drawing.Point(701, 36)
        Me.txtUnOfficialReceiptStart.MaxLength = 10
        Me.txtUnOfficialReceiptStart.Name = "txtUnOfficialReceiptStart"
        Me.txtUnOfficialReceiptStart.Size = New System.Drawing.Size(100, 20)
        Me.txtUnOfficialReceiptStart.TabIndex = 281
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(410, 38)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(79, 13)
        Me.Label32.TabIndex = 278
        Me.Label32.Text = "Receipt # Start"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(410, 15)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(44, 13)
        Me.Label31.TabIndex = 277
        Me.Label31.Text = "Offical"
        '
        'txtOfficialReceiptStart
        '
        Me.txtOfficialReceiptStart.Location = New System.Drawing.Point(499, 35)
        Me.txtOfficialReceiptStart.MaxLength = 10
        Me.txtOfficialReceiptStart.Name = "txtOfficialReceiptStart"
        Me.txtOfficialReceiptStart.Size = New System.Drawing.Size(100, 20)
        Me.txtOfficialReceiptStart.TabIndex = 276
        '
        'cmbProjectAccount
        '
        Me.cmbProjectAccount.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbProjectAccount.Caption = ""
        Me.cmbProjectAccount.CaptionHeight = 17
        Me.cmbProjectAccount.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbProjectAccount.ColumnCaptionHeight = 17
        Me.cmbProjectAccount.ColumnFooterHeight = 17
        Me.cmbProjectAccount.ContentHeight = 15
        Me.cmbProjectAccount.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbProjectAccount.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbProjectAccount.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProjectAccount.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbProjectAccount.EditorHeight = 15
        Me.cmbProjectAccount.Images.Add(CType(resources.GetObject("cmbProjectAccount.Images"), System.Drawing.Image))
        Me.cmbProjectAccount.ItemHeight = 15
        Me.cmbProjectAccount.Location = New System.Drawing.Point(499, 166)
        Me.cmbProjectAccount.MatchEntryTimeout = CType(2000, Long)
        Me.cmbProjectAccount.MaxDropDownItems = CType(5, Short)
        Me.cmbProjectAccount.MaxLength = 32767
        Me.cmbProjectAccount.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbProjectAccount.Name = "cmbProjectAccount"
        Me.cmbProjectAccount.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbProjectAccount.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbProjectAccount.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbProjectAccount.Size = New System.Drawing.Size(278, 21)
        Me.cmbProjectAccount.TabIndex = 274
        Me.cmbProjectAccount.PropBag = resources.GetString("cmbProjectAccount.PropBag")
        '
        'cmbProject
        '
        Me.cmbProject.AutoSize = True
        Me.cmbProject.Location = New System.Drawing.Point(410, 170)
        Me.cmbProject.Name = "cmbProject"
        Me.cmbProject.Size = New System.Drawing.Size(40, 13)
        Me.cmbProject.TabIndex = 275
        Me.cmbProject.Text = "Project"
        '
        'cmbForfietAccount
        '
        Me.cmbForfietAccount.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbForfietAccount.Caption = ""
        Me.cmbForfietAccount.CaptionHeight = 17
        Me.cmbForfietAccount.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbForfietAccount.ColumnCaptionHeight = 17
        Me.cmbForfietAccount.ColumnFooterHeight = 17
        Me.cmbForfietAccount.ContentHeight = 15
        Me.cmbForfietAccount.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbForfietAccount.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbForfietAccount.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbForfietAccount.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbForfietAccount.EditorHeight = 15
        Me.cmbForfietAccount.Images.Add(CType(resources.GetObject("cmbForfietAccount.Images"), System.Drawing.Image))
        Me.cmbForfietAccount.ItemHeight = 15
        Me.cmbForfietAccount.Location = New System.Drawing.Point(499, 140)
        Me.cmbForfietAccount.MatchEntryTimeout = CType(2000, Long)
        Me.cmbForfietAccount.MaxDropDownItems = CType(5, Short)
        Me.cmbForfietAccount.MaxLength = 32767
        Me.cmbForfietAccount.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbForfietAccount.Name = "cmbForfietAccount"
        Me.cmbForfietAccount.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbForfietAccount.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbForfietAccount.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbForfietAccount.Size = New System.Drawing.Size(278, 21)
        Me.cmbForfietAccount.TabIndex = 270
        Me.cmbForfietAccount.PropBag = resources.GetString("cmbForfietAccount.PropBag")
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(410, 144)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(82, 13)
        Me.Label27.TabIndex = 273
        Me.Label27.Text = "Fortfiet Account"
        '
        'cmbChequeAccount
        '
        Me.cmbChequeAccount.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbChequeAccount.Caption = ""
        Me.cmbChequeAccount.CaptionHeight = 17
        Me.cmbChequeAccount.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbChequeAccount.ColumnCaptionHeight = 17
        Me.cmbChequeAccount.ColumnFooterHeight = 17
        Me.cmbChequeAccount.ContentHeight = 15
        Me.cmbChequeAccount.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbChequeAccount.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbChequeAccount.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbChequeAccount.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbChequeAccount.EditorHeight = 15
        Me.cmbChequeAccount.Images.Add(CType(resources.GetObject("cmbChequeAccount.Images"), System.Drawing.Image))
        Me.cmbChequeAccount.ItemHeight = 15
        Me.cmbChequeAccount.Location = New System.Drawing.Point(499, 114)
        Me.cmbChequeAccount.MatchEntryTimeout = CType(2000, Long)
        Me.cmbChequeAccount.MaxDropDownItems = CType(5, Short)
        Me.cmbChequeAccount.MaxLength = 32767
        Me.cmbChequeAccount.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbChequeAccount.Name = "cmbChequeAccount"
        Me.cmbChequeAccount.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbChequeAccount.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbChequeAccount.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbChequeAccount.Size = New System.Drawing.Size(278, 21)
        Me.cmbChequeAccount.TabIndex = 269
        Me.cmbChequeAccount.PropBag = resources.GetString("cmbChequeAccount.PropBag")
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(410, 118)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(87, 13)
        Me.Label29.TabIndex = 272
        Me.Label29.Text = "Cheque Account"
        '
        'cmbCashAccount
        '
        Me.cmbCashAccount.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbCashAccount.Caption = ""
        Me.cmbCashAccount.CaptionHeight = 17
        Me.cmbCashAccount.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbCashAccount.ColumnCaptionHeight = 17
        Me.cmbCashAccount.ColumnFooterHeight = 17
        Me.cmbCashAccount.ContentHeight = 15
        Me.cmbCashAccount.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbCashAccount.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbCashAccount.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCashAccount.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbCashAccount.EditorHeight = 15
        Me.cmbCashAccount.Images.Add(CType(resources.GetObject("cmbCashAccount.Images"), System.Drawing.Image))
        Me.cmbCashAccount.ItemHeight = 15
        Me.cmbCashAccount.Location = New System.Drawing.Point(499, 88)
        Me.cmbCashAccount.MatchEntryTimeout = CType(2000, Long)
        Me.cmbCashAccount.MaxDropDownItems = CType(5, Short)
        Me.cmbCashAccount.MaxLength = 32767
        Me.cmbCashAccount.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbCashAccount.Name = "cmbCashAccount"
        Me.cmbCashAccount.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbCashAccount.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbCashAccount.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbCashAccount.Size = New System.Drawing.Size(278, 21)
        Me.cmbCashAccount.TabIndex = 268
        Me.cmbCashAccount.PropBag = resources.GetString("cmbCashAccount.PropBag")
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(410, 92)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(74, 13)
        Me.Label30.TabIndex = 271
        Me.Label30.Text = "Cash Account"
        '
        'cmbPenaltyPolicy
        '
        Me.cmbPenaltyPolicy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPenaltyPolicy.FormattingEnabled = True
        Me.cmbPenaltyPolicy.Items.AddRange(New Object() {"Normal", "Compounded"})
        Me.cmbPenaltyPolicy.Location = New System.Drawing.Point(381, 245)
        Me.cmbPenaltyPolicy.Name = "cmbPenaltyPolicy"
        Me.cmbPenaltyPolicy.Size = New System.Drawing.Size(166, 21)
        Me.cmbPenaltyPolicy.TabIndex = 266
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(290, 249)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(73, 13)
        Me.Label26.TabIndex = 267
        Me.Label26.Text = "Penalty Policy"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(26, 249)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(53, 13)
        Me.Label28.TabIndex = 265
        Me.Label28.Text = "Penalty %"
        '
        'txtPenaltyPer
        '
        Me.txtPenaltyPer.AutoSize = False
        Me.txtPenaltyPer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPenaltyPer.DisplayFormat.CustomFormat = "###,###,##0"
        Me.txtPenaltyPer.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtPenaltyPer.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
                    Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtPenaltyPer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPenaltyPer.Location = New System.Drawing.Point(118, 246)
        Me.txtPenaltyPer.Name = "txtPenaltyPer"
        Me.txtPenaltyPer.Size = New System.Drawing.Size(88, 20)
        Me.txtPenaltyPer.TabIndex = 264
        Me.txtPenaltyPer.Tag = Nothing
        Me.txtPenaltyPer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtPenaltyPer.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtPenaltyPer.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtPenaltyPer.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtPenaltyPer.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'cmbSector
        '
        Me.cmbSector.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbSector.Caption = ""
        Me.cmbSector.CaptionHeight = 17
        Me.cmbSector.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbSector.ColumnCaptionHeight = 17
        Me.cmbSector.ColumnFooterHeight = 17
        Me.cmbSector.ContentHeight = 15
        Me.cmbSector.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbSector.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbSector.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbSector.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbSector.EditorHeight = 15
        Me.cmbSector.Images.Add(CType(resources.GetObject("cmbSector.Images"), System.Drawing.Image))
        Me.cmbSector.ItemHeight = 15
        Me.cmbSector.Location = New System.Drawing.Point(118, 220)
        Me.cmbSector.MatchEntryTimeout = CType(2000, Long)
        Me.cmbSector.MaxDropDownItems = CType(5, Short)
        Me.cmbSector.MaxLength = 32767
        Me.cmbSector.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbSector.Name = "cmbSector"
        Me.cmbSector.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbSector.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbSector.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbSector.Size = New System.Drawing.Size(278, 21)
        Me.cmbSector.TabIndex = 184
        Me.cmbSector.PropBag = resources.GetString("cmbSector.PropBag")
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(26, 224)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(38, 13)
        Me.Label25.TabIndex = 185
        Me.Label25.Text = "Sector"
        '
        'cmbExtraCharges15
        '
        Me.cmbExtraCharges15.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges15.Caption = ""
        Me.cmbExtraCharges15.CaptionHeight = 17
        Me.cmbExtraCharges15.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges15.ColumnCaptionHeight = 17
        Me.cmbExtraCharges15.ColumnFooterHeight = 17
        Me.cmbExtraCharges15.ContentHeight = 15
        Me.cmbExtraCharges15.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges15.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges15.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges15.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges15.EditorHeight = 15
        Me.cmbExtraCharges15.Images.Add(CType(resources.GetObject("cmbExtraCharges15.Images"), System.Drawing.Image))
        Me.cmbExtraCharges15.ItemHeight = 15
        Me.cmbExtraCharges15.Location = New System.Drawing.Point(643, 377)
        Me.cmbExtraCharges15.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges15.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges15.MaxLength = 32767
        Me.cmbExtraCharges15.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges15.Name = "cmbExtraCharges15"
        Me.cmbExtraCharges15.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges15.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges15.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges15.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges15.TabIndex = 178
        Me.cmbExtraCharges15.PropBag = resources.GetString("cmbExtraCharges15.PropBag")
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(553, 381)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(88, 13)
        Me.Label19.TabIndex = 183
        Me.Label19.Text = "Extra Charges 15"
        '
        'cmbExtraCharges13
        '
        Me.cmbExtraCharges13.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges13.Caption = ""
        Me.cmbExtraCharges13.CaptionHeight = 17
        Me.cmbExtraCharges13.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges13.ColumnCaptionHeight = 17
        Me.cmbExtraCharges13.ColumnFooterHeight = 17
        Me.cmbExtraCharges13.ContentHeight = 15
        Me.cmbExtraCharges13.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges13.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges13.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges13.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges13.EditorHeight = 15
        Me.cmbExtraCharges13.Images.Add(CType(resources.GetObject("cmbExtraCharges13.Images"), System.Drawing.Image))
        Me.cmbExtraCharges13.ItemHeight = 15
        Me.cmbExtraCharges13.Location = New System.Drawing.Point(643, 325)
        Me.cmbExtraCharges13.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges13.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges13.MaxLength = 32767
        Me.cmbExtraCharges13.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges13.Name = "cmbExtraCharges13"
        Me.cmbExtraCharges13.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges13.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges13.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges13.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges13.TabIndex = 176
        Me.cmbExtraCharges13.PropBag = resources.GetString("cmbExtraCharges13.PropBag")
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(553, 355)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(88, 13)
        Me.Label20.TabIndex = 182
        Me.Label20.Text = "Extra Charges 14"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(553, 329)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(88, 13)
        Me.Label22.TabIndex = 181
        Me.Label22.Text = "Extra Charges 13"
        '
        'cmbExtraCharges12
        '
        Me.cmbExtraCharges12.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges12.Caption = ""
        Me.cmbExtraCharges12.CaptionHeight = 17
        Me.cmbExtraCharges12.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges12.ColumnCaptionHeight = 17
        Me.cmbExtraCharges12.ColumnFooterHeight = 17
        Me.cmbExtraCharges12.ContentHeight = 15
        Me.cmbExtraCharges12.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges12.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges12.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges12.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges12.EditorHeight = 15
        Me.cmbExtraCharges12.Images.Add(CType(resources.GetObject("cmbExtraCharges12.Images"), System.Drawing.Image))
        Me.cmbExtraCharges12.ItemHeight = 15
        Me.cmbExtraCharges12.Location = New System.Drawing.Point(643, 298)
        Me.cmbExtraCharges12.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges12.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges12.MaxLength = 32767
        Me.cmbExtraCharges12.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges12.Name = "cmbExtraCharges12"
        Me.cmbExtraCharges12.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges12.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges12.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges12.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges12.TabIndex = 175
        Me.cmbExtraCharges12.PropBag = resources.GetString("cmbExtraCharges12.PropBag")
        '
        'cmbExtraCharges14
        '
        Me.cmbExtraCharges14.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges14.Caption = ""
        Me.cmbExtraCharges14.CaptionHeight = 17
        Me.cmbExtraCharges14.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges14.ColumnCaptionHeight = 17
        Me.cmbExtraCharges14.ColumnFooterHeight = 17
        Me.cmbExtraCharges14.ContentHeight = 15
        Me.cmbExtraCharges14.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges14.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges14.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges14.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges14.EditorHeight = 15
        Me.cmbExtraCharges14.Images.Add(CType(resources.GetObject("cmbExtraCharges14.Images"), System.Drawing.Image))
        Me.cmbExtraCharges14.ItemHeight = 15
        Me.cmbExtraCharges14.Location = New System.Drawing.Point(643, 351)
        Me.cmbExtraCharges14.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges14.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges14.MaxLength = 32767
        Me.cmbExtraCharges14.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges14.Name = "cmbExtraCharges14"
        Me.cmbExtraCharges14.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges14.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges14.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges14.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges14.TabIndex = 177
        Me.cmbExtraCharges14.PropBag = resources.GetString("cmbExtraCharges14.PropBag")
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(553, 302)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(88, 13)
        Me.Label23.TabIndex = 180
        Me.Label23.Text = "Extra Charges 12"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(553, 275)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(88, 13)
        Me.Label24.TabIndex = 179
        Me.Label24.Text = "Extra Charges 11"
        '
        'cmbExtraCharges11
        '
        Me.cmbExtraCharges11.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges11.Caption = ""
        Me.cmbExtraCharges11.CaptionHeight = 17
        Me.cmbExtraCharges11.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges11.ColumnCaptionHeight = 17
        Me.cmbExtraCharges11.ColumnFooterHeight = 17
        Me.cmbExtraCharges11.ContentHeight = 15
        Me.cmbExtraCharges11.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges11.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges11.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges11.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges11.EditorHeight = 15
        Me.cmbExtraCharges11.Images.Add(CType(resources.GetObject("cmbExtraCharges11.Images"), System.Drawing.Image))
        Me.cmbExtraCharges11.ItemHeight = 15
        Me.cmbExtraCharges11.Location = New System.Drawing.Point(643, 271)
        Me.cmbExtraCharges11.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges11.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges11.MaxLength = 32767
        Me.cmbExtraCharges11.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges11.Name = "cmbExtraCharges11"
        Me.cmbExtraCharges11.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges11.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges11.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges11.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges11.TabIndex = 174
        Me.cmbExtraCharges11.PropBag = resources.GetString("cmbExtraCharges11.PropBag")
        '
        'cmbExtraCharges3
        '
        Me.cmbExtraCharges3.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges3.Caption = ""
        Me.cmbExtraCharges3.CaptionHeight = 17
        Me.cmbExtraCharges3.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges3.ColumnCaptionHeight = 17
        Me.cmbExtraCharges3.ColumnFooterHeight = 17
        Me.cmbExtraCharges3.ContentHeight = 15
        Me.cmbExtraCharges3.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges3.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges3.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges3.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges3.EditorHeight = 15
        Me.cmbExtraCharges3.Images.Add(CType(resources.GetObject("cmbExtraCharges3.Images"), System.Drawing.Image))
        Me.cmbExtraCharges3.ItemHeight = 15
        Me.cmbExtraCharges3.Location = New System.Drawing.Point(118, 325)
        Me.cmbExtraCharges3.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges3.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges3.MaxLength = 32767
        Me.cmbExtraCharges3.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges3.Name = "cmbExtraCharges3"
        Me.cmbExtraCharges3.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges3.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges3.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges3.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges3.TabIndex = 11
        Me.cmbExtraCharges3.PropBag = resources.GetString("cmbExtraCharges3.PropBag")
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(26, 329)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(82, 13)
        Me.Label14.TabIndex = 159
        Me.Label14.Text = "Extra Charges 3"
        '
        'cmbExtraCharges10
        '
        Me.cmbExtraCharges10.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges10.Caption = ""
        Me.cmbExtraCharges10.CaptionHeight = 17
        Me.cmbExtraCharges10.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges10.ColumnCaptionHeight = 17
        Me.cmbExtraCharges10.ColumnFooterHeight = 17
        Me.cmbExtraCharges10.ContentHeight = 15
        Me.cmbExtraCharges10.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges10.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges10.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges10.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges10.EditorHeight = 15
        Me.cmbExtraCharges10.Images.Add(CType(resources.GetObject("cmbExtraCharges10.Images"), System.Drawing.Image))
        Me.cmbExtraCharges10.ItemHeight = 15
        Me.cmbExtraCharges10.Location = New System.Drawing.Point(381, 377)
        Me.cmbExtraCharges10.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges10.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges10.MaxLength = 32767
        Me.cmbExtraCharges10.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges10.Name = "cmbExtraCharges10"
        Me.cmbExtraCharges10.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges10.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges10.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges10.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges10.TabIndex = 18
        Me.cmbExtraCharges10.PropBag = resources.GetString("cmbExtraCharges10.PropBag")
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(290, 381)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(88, 13)
        Me.Label21.TabIndex = 173
        Me.Label21.Text = "Extra Charges 10"
        '
        'cmbExtraCharges8
        '
        Me.cmbExtraCharges8.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges8.Caption = ""
        Me.cmbExtraCharges8.CaptionHeight = 17
        Me.cmbExtraCharges8.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges8.ColumnCaptionHeight = 17
        Me.cmbExtraCharges8.ColumnFooterHeight = 17
        Me.cmbExtraCharges8.ContentHeight = 15
        Me.cmbExtraCharges8.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges8.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges8.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges8.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges8.EditorHeight = 15
        Me.cmbExtraCharges8.Images.Add(CType(resources.GetObject("cmbExtraCharges8.Images"), System.Drawing.Image))
        Me.cmbExtraCharges8.ItemHeight = 15
        Me.cmbExtraCharges8.Location = New System.Drawing.Point(381, 325)
        Me.cmbExtraCharges8.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges8.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges8.MaxLength = 32767
        Me.cmbExtraCharges8.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges8.Name = "cmbExtraCharges8"
        Me.cmbExtraCharges8.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges8.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges8.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges8.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges8.TabIndex = 16
        Me.cmbExtraCharges8.PropBag = resources.GetString("cmbExtraCharges8.PropBag")
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(290, 355)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(82, 13)
        Me.Label16.TabIndex = 171
        Me.Label16.Text = "Extra Charges 9"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(290, 329)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(82, 13)
        Me.Label17.TabIndex = 169
        Me.Label17.Text = "Extra Charges 8"
        '
        'cmbExtraCharges7
        '
        Me.cmbExtraCharges7.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges7.Caption = ""
        Me.cmbExtraCharges7.CaptionHeight = 17
        Me.cmbExtraCharges7.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges7.ColumnCaptionHeight = 17
        Me.cmbExtraCharges7.ColumnFooterHeight = 17
        Me.cmbExtraCharges7.ContentHeight = 15
        Me.cmbExtraCharges7.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges7.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges7.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges7.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges7.EditorHeight = 15
        Me.cmbExtraCharges7.Images.Add(CType(resources.GetObject("cmbExtraCharges7.Images"), System.Drawing.Image))
        Me.cmbExtraCharges7.ItemHeight = 15
        Me.cmbExtraCharges7.Location = New System.Drawing.Point(381, 298)
        Me.cmbExtraCharges7.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges7.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges7.MaxLength = 32767
        Me.cmbExtraCharges7.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges7.Name = "cmbExtraCharges7"
        Me.cmbExtraCharges7.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges7.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges7.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges7.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges7.TabIndex = 15
        Me.cmbExtraCharges7.PropBag = resources.GetString("cmbExtraCharges7.PropBag")
        '
        'cmbExtraCharges9
        '
        Me.cmbExtraCharges9.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges9.Caption = ""
        Me.cmbExtraCharges9.CaptionHeight = 17
        Me.cmbExtraCharges9.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges9.ColumnCaptionHeight = 17
        Me.cmbExtraCharges9.ColumnFooterHeight = 17
        Me.cmbExtraCharges9.ContentHeight = 15
        Me.cmbExtraCharges9.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges9.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges9.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges9.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges9.EditorHeight = 15
        Me.cmbExtraCharges9.Images.Add(CType(resources.GetObject("cmbExtraCharges9.Images"), System.Drawing.Image))
        Me.cmbExtraCharges9.ItemHeight = 15
        Me.cmbExtraCharges9.Location = New System.Drawing.Point(381, 351)
        Me.cmbExtraCharges9.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges9.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges9.MaxLength = 32767
        Me.cmbExtraCharges9.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges9.Name = "cmbExtraCharges9"
        Me.cmbExtraCharges9.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges9.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges9.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges9.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges9.TabIndex = 17
        Me.cmbExtraCharges9.PropBag = resources.GetString("cmbExtraCharges9.PropBag")
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(290, 302)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(82, 13)
        Me.Label18.TabIndex = 167
        Me.Label18.Text = "Extra Charges 7"
        '
        'cmbExtraCharges5
        '
        Me.cmbExtraCharges5.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges5.Caption = ""
        Me.cmbExtraCharges5.CaptionHeight = 17
        Me.cmbExtraCharges5.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges5.ColumnCaptionHeight = 17
        Me.cmbExtraCharges5.ColumnFooterHeight = 17
        Me.cmbExtraCharges5.ContentHeight = 15
        Me.cmbExtraCharges5.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges5.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges5.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges5.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges5.EditorHeight = 15
        Me.cmbExtraCharges5.Images.Add(CType(resources.GetObject("cmbExtraCharges5.Images"), System.Drawing.Image))
        Me.cmbExtraCharges5.ItemHeight = 15
        Me.cmbExtraCharges5.Location = New System.Drawing.Point(118, 377)
        Me.cmbExtraCharges5.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges5.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges5.MaxLength = 32767
        Me.cmbExtraCharges5.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges5.Name = "cmbExtraCharges5"
        Me.cmbExtraCharges5.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges5.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges5.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges5.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges5.TabIndex = 13
        Me.cmbExtraCharges5.PropBag = resources.GetString("cmbExtraCharges5.PropBag")
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(290, 275)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 13)
        Me.Label12.TabIndex = 165
        Me.Label12.Text = "Extra Charges 6"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(26, 381)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(82, 13)
        Me.Label13.TabIndex = 163
        Me.Label13.Text = "Extra Charges 5"
        '
        'cmbExtraCharges4
        '
        Me.cmbExtraCharges4.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges4.Caption = ""
        Me.cmbExtraCharges4.CaptionHeight = 17
        Me.cmbExtraCharges4.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges4.ColumnCaptionHeight = 17
        Me.cmbExtraCharges4.ColumnFooterHeight = 17
        Me.cmbExtraCharges4.ContentHeight = 15
        Me.cmbExtraCharges4.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges4.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges4.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges4.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges4.EditorHeight = 15
        Me.cmbExtraCharges4.Images.Add(CType(resources.GetObject("cmbExtraCharges4.Images"), System.Drawing.Image))
        Me.cmbExtraCharges4.ItemHeight = 15
        Me.cmbExtraCharges4.Location = New System.Drawing.Point(118, 351)
        Me.cmbExtraCharges4.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges4.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges4.MaxLength = 32767
        Me.cmbExtraCharges4.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges4.Name = "cmbExtraCharges4"
        Me.cmbExtraCharges4.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges4.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges4.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges4.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges4.TabIndex = 12
        Me.cmbExtraCharges4.PropBag = resources.GetString("cmbExtraCharges4.PropBag")
        '
        'cmbExtraCharges6
        '
        Me.cmbExtraCharges6.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges6.Caption = ""
        Me.cmbExtraCharges6.CaptionHeight = 17
        Me.cmbExtraCharges6.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges6.ColumnCaptionHeight = 17
        Me.cmbExtraCharges6.ColumnFooterHeight = 17
        Me.cmbExtraCharges6.ContentHeight = 15
        Me.cmbExtraCharges6.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges6.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges6.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges6.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges6.EditorHeight = 15
        Me.cmbExtraCharges6.Images.Add(CType(resources.GetObject("cmbExtraCharges6.Images"), System.Drawing.Image))
        Me.cmbExtraCharges6.ItemHeight = 15
        Me.cmbExtraCharges6.Location = New System.Drawing.Point(381, 271)
        Me.cmbExtraCharges6.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges6.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges6.MaxLength = 32767
        Me.cmbExtraCharges6.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges6.Name = "cmbExtraCharges6"
        Me.cmbExtraCharges6.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges6.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges6.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges6.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges6.TabIndex = 14
        Me.cmbExtraCharges6.PropBag = resources.GetString("cmbExtraCharges6.PropBag")
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(26, 355)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(82, 13)
        Me.Label15.TabIndex = 161
        Me.Label15.Text = "Extra Charges 4"
        '
        'cmbExtraCharges2
        '
        Me.cmbExtraCharges2.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges2.Caption = ""
        Me.cmbExtraCharges2.CaptionHeight = 17
        Me.cmbExtraCharges2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges2.ColumnCaptionHeight = 17
        Me.cmbExtraCharges2.ColumnFooterHeight = 17
        Me.cmbExtraCharges2.ContentHeight = 15
        Me.cmbExtraCharges2.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges2.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges2.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges2.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges2.EditorHeight = 15
        Me.cmbExtraCharges2.Images.Add(CType(resources.GetObject("cmbExtraCharges2.Images"), System.Drawing.Image))
        Me.cmbExtraCharges2.ItemHeight = 15
        Me.cmbExtraCharges2.Location = New System.Drawing.Point(118, 298)
        Me.cmbExtraCharges2.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges2.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges2.MaxLength = 32767
        Me.cmbExtraCharges2.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges2.Name = "cmbExtraCharges2"
        Me.cmbExtraCharges2.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges2.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges2.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges2.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges2.TabIndex = 10
        Me.cmbExtraCharges2.PropBag = resources.GetString("cmbExtraCharges2.PropBag")
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(26, 302)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(82, 13)
        Me.Label11.TabIndex = 153
        Me.Label11.Text = "Extra Charges 2"
        '
        'cmbExtraCharges1
        '
        Me.cmbExtraCharges1.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbExtraCharges1.Caption = ""
        Me.cmbExtraCharges1.CaptionHeight = 17
        Me.cmbExtraCharges1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbExtraCharges1.ColumnCaptionHeight = 17
        Me.cmbExtraCharges1.ColumnFooterHeight = 17
        Me.cmbExtraCharges1.ContentHeight = 15
        Me.cmbExtraCharges1.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbExtraCharges1.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbExtraCharges1.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbExtraCharges1.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbExtraCharges1.EditorHeight = 15
        Me.cmbExtraCharges1.Images.Add(CType(resources.GetObject("cmbExtraCharges1.Images"), System.Drawing.Image))
        Me.cmbExtraCharges1.ItemHeight = 15
        Me.cmbExtraCharges1.Location = New System.Drawing.Point(118, 271)
        Me.cmbExtraCharges1.MatchEntryTimeout = CType(2000, Long)
        Me.cmbExtraCharges1.MaxDropDownItems = CType(5, Short)
        Me.cmbExtraCharges1.MaxLength = 32767
        Me.cmbExtraCharges1.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbExtraCharges1.Name = "cmbExtraCharges1"
        Me.cmbExtraCharges1.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges1.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbExtraCharges1.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbExtraCharges1.Size = New System.Drawing.Size(166, 21)
        Me.cmbExtraCharges1.TabIndex = 9
        Me.cmbExtraCharges1.PropBag = resources.GetString("cmbExtraCharges1.PropBag")
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(26, 275)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(82, 13)
        Me.Label10.TabIndex = 151
        Me.Label10.Text = "Extra Charges 1"
        '
        'cmdCityList
        '
        Me.cmdCityList.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdCityList.Image = Global.General_Ledger.My.Resources.Resources.Find_Small
        Me.cmdCityList.Location = New System.Drawing.Point(396, 193)
        Me.cmdCityList.Name = "cmdCityList"
        Me.cmdCityList.Size = New System.Drawing.Size(22, 21)
        Me.cmdCityList.TabIndex = 8
        Me.cmdCityList.UseVisualStyleBackColor = True
        '
        'cmbCity
        '
        Me.cmbCity.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbCity.Caption = ""
        Me.cmbCity.CaptionHeight = 17
        Me.cmbCity.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbCity.ColumnCaptionHeight = 17
        Me.cmbCity.ColumnFooterHeight = 17
        Me.cmbCity.ContentHeight = 15
        Me.cmbCity.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbCity.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbCity.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCity.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbCity.EditorHeight = 15
        Me.cmbCity.Images.Add(CType(resources.GetObject("cmbCity.Images"), System.Drawing.Image))
        Me.cmbCity.ItemHeight = 15
        Me.cmbCity.Location = New System.Drawing.Point(118, 193)
        Me.cmbCity.MatchEntryTimeout = CType(2000, Long)
        Me.cmbCity.MaxDropDownItems = CType(5, Short)
        Me.cmbCity.MaxLength = 32767
        Me.cmbCity.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbCity.Name = "cmbCity"
        Me.cmbCity.ReadOnly = True
        Me.cmbCity.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbCity.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbCity.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbCity.Size = New System.Drawing.Size(278, 21)
        Me.cmbCity.TabIndex = 149
        Me.cmbCity.PropBag = resources.GetString("cmbCity.PropBag")
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(26, 197)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(24, 13)
        Me.Label9.TabIndex = 148
        Me.Label9.Text = "City"
        '
        'cmbCountry
        '
        Me.cmbCountry.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbCountry.Caption = ""
        Me.cmbCountry.CaptionHeight = 17
        Me.cmbCountry.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbCountry.ColumnCaptionHeight = 17
        Me.cmbCountry.ColumnFooterHeight = 17
        Me.cmbCountry.ContentHeight = 15
        Me.cmbCountry.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbCountry.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbCountry.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCountry.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbCountry.EditorHeight = 15
        Me.cmbCountry.Images.Add(CType(resources.GetObject("cmbCountry.Images"), System.Drawing.Image))
        Me.cmbCountry.ItemHeight = 15
        Me.cmbCountry.Location = New System.Drawing.Point(118, 166)
        Me.cmbCountry.MatchEntryTimeout = CType(2000, Long)
        Me.cmbCountry.MaxDropDownItems = CType(5, Short)
        Me.cmbCountry.MaxLength = 32767
        Me.cmbCountry.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbCountry.Name = "cmbCountry"
        Me.cmbCountry.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbCountry.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbCountry.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbCountry.Size = New System.Drawing.Size(278, 21)
        Me.cmbCountry.TabIndex = 7
        Me.cmbCountry.PropBag = resources.GetString("cmbCountry.PropBag")
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(26, 170)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(43, 13)
        Me.Label8.TabIndex = 146
        Me.Label8.Text = "Country"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(263, 15)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 13)
        Me.Label7.TabIndex = 145
        Me.Label7.Text = "Project Prefix"
        '
        'txtPrefix
        '
        Me.txtPrefix.Location = New System.Drawing.Point(348, 12)
        Me.txtPrefix.MaxLength = 3
        Me.txtPrefix.Name = "txtPrefix"
        Me.txtPrefix.Size = New System.Drawing.Size(48, 20)
        Me.txtPrefix.TabIndex = 2
        '
        'cmbRegion
        '
        Me.cmbRegion.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbRegion.Caption = ""
        Me.cmbRegion.CaptionHeight = 17
        Me.cmbRegion.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbRegion.ColumnCaptionHeight = 17
        Me.cmbRegion.ColumnFooterHeight = 17
        Me.cmbRegion.ContentHeight = 15
        Me.cmbRegion.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbRegion.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbRegion.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbRegion.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbRegion.EditorHeight = 15
        Me.cmbRegion.Images.Add(CType(resources.GetObject("cmbRegion.Images"), System.Drawing.Image))
        Me.cmbRegion.ItemHeight = 15
        Me.cmbRegion.Location = New System.Drawing.Point(118, 140)
        Me.cmbRegion.MatchEntryTimeout = CType(2000, Long)
        Me.cmbRegion.MaxDropDownItems = CType(5, Short)
        Me.cmbRegion.MaxLength = 32767
        Me.cmbRegion.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbRegion.Name = "cmbRegion"
        Me.cmbRegion.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbRegion.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbRegion.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbRegion.Size = New System.Drawing.Size(278, 21)
        Me.cmbRegion.TabIndex = 6
        Me.cmbRegion.PropBag = resources.GetString("cmbRegion.PropBag")
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(26, 144)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 13)
        Me.Label5.TabIndex = 142
        Me.Label5.Text = "Region"
        '
        'cmbProjectPurpose
        '
        Me.cmbProjectPurpose.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbProjectPurpose.Caption = ""
        Me.cmbProjectPurpose.CaptionHeight = 17
        Me.cmbProjectPurpose.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbProjectPurpose.ColumnCaptionHeight = 17
        Me.cmbProjectPurpose.ColumnFooterHeight = 17
        Me.cmbProjectPurpose.ContentHeight = 15
        Me.cmbProjectPurpose.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbProjectPurpose.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbProjectPurpose.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProjectPurpose.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbProjectPurpose.EditorHeight = 15
        Me.cmbProjectPurpose.Images.Add(CType(resources.GetObject("cmbProjectPurpose.Images"), System.Drawing.Image))
        Me.cmbProjectPurpose.ItemHeight = 15
        Me.cmbProjectPurpose.Location = New System.Drawing.Point(118, 114)
        Me.cmbProjectPurpose.MatchEntryTimeout = CType(2000, Long)
        Me.cmbProjectPurpose.MaxDropDownItems = CType(5, Short)
        Me.cmbProjectPurpose.MaxLength = 32767
        Me.cmbProjectPurpose.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbProjectPurpose.Name = "cmbProjectPurpose"
        Me.cmbProjectPurpose.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbProjectPurpose.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbProjectPurpose.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbProjectPurpose.Size = New System.Drawing.Size(278, 21)
        Me.cmbProjectPurpose.TabIndex = 5
        Me.cmbProjectPurpose.PropBag = resources.GetString("cmbProjectPurpose.PropBag")
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 118)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(82, 13)
        Me.Label4.TabIndex = 140
        Me.Label4.Text = "Project Purpose"
        '
        'cmbProjectType
        '
        Me.cmbProjectType.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbProjectType.Caption = ""
        Me.cmbProjectType.CaptionHeight = 17
        Me.cmbProjectType.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbProjectType.ColumnCaptionHeight = 17
        Me.cmbProjectType.ColumnFooterHeight = 17
        Me.cmbProjectType.ContentHeight = 15
        Me.cmbProjectType.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbProjectType.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbProjectType.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProjectType.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbProjectType.EditorHeight = 15
        Me.cmbProjectType.Images.Add(CType(resources.GetObject("cmbProjectType.Images"), System.Drawing.Image))
        Me.cmbProjectType.ItemHeight = 15
        Me.cmbProjectType.Location = New System.Drawing.Point(118, 88)
        Me.cmbProjectType.MatchEntryTimeout = CType(2000, Long)
        Me.cmbProjectType.MaxDropDownItems = CType(5, Short)
        Me.cmbProjectType.MaxLength = 32767
        Me.cmbProjectType.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbProjectType.Name = "cmbProjectType"
        Me.cmbProjectType.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbProjectType.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbProjectType.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbProjectType.Size = New System.Drawing.Size(278, 21)
        Me.cmbProjectType.TabIndex = 4
        Me.cmbProjectType.PropBag = resources.GetString("cmbProjectType.PropBag")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(26, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 13)
        Me.Label3.TabIndex = 138
        Me.Label3.Text = "Project Type"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(26, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 13)
        Me.Label2.TabIndex = 137
        Me.Label2.Text = "Address"
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(118, 61)
        Me.txtAddress.MaxLength = 200
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(278, 20)
        Me.txtAddress.TabIndex = 3
        '
        'cmbName
        '
        Me.cmbName.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbName.Caption = ""
        Me.cmbName.CaptionHeight = 17
        Me.cmbName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbName.ColumnCaptionHeight = 17
        Me.cmbName.ColumnFooterHeight = 17
        Me.cmbName.ContentHeight = 15
        Me.cmbName.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbName.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbName.EditorFont = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbName.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbName.EditorHeight = 15
        Me.cmbName.Images.Add(CType(resources.GetObject("cmbName.Images"), System.Drawing.Image))
        Me.cmbName.ItemHeight = 15
        Me.cmbName.Location = New System.Drawing.Point(118, 35)
        Me.cmbName.MatchEntryTimeout = CType(2000, Long)
        Me.cmbName.MaxDropDownItems = CType(5, Short)
        Me.cmbName.MaxLength = 32767
        Me.cmbName.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbName.Name = "cmbName"
        Me.cmbName.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.cmbName.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbName.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbName.Size = New System.Drawing.Size(278, 21)
        Me.cmbName.TabIndex = 1
        Me.cmbName.PropBag = resources.GetString("cmbName.PropBag")
        '
        'cmdAdd
        '
        Me.cmdAdd.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdAdd.Image = Global.General_Ledger.My.Resources.Resources.folder_add
        Me.cmdAdd.Location = New System.Drawing.Point(497, 5)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(51, 56)
        Me.cmdAdd.TabIndex = 0
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdAdd.UseVisualStyleBackColor = True
        '
        'cmdExit
        '
        Me.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdExit.Image = Global.General_Ledger.My.Resources.Resources.folder_out
        Me.cmdExit.Location = New System.Drawing.Point(755, 5)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(51, 56)
        Me.cmdExit.TabIndex = 7
        Me.cmdExit.Text = "E&xit"
        Me.cmdExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdExit.UseVisualStyleBackColor = True
        '
        'cmdUndo
        '
        Me.cmdUndo.Image = Global.General_Ledger.My.Resources.Resources.folder_refresh
        Me.cmdUndo.Location = New System.Drawing.Point(704, 5)
        Me.cmdUndo.Name = "cmdUndo"
        Me.cmdUndo.Size = New System.Drawing.Size(51, 56)
        Me.cmdUndo.TabIndex = 5
        Me.cmdUndo.Text = "&Undo"
        Me.cmdUndo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdUndo.UseVisualStyleBackColor = True
        '
        'cmdSearch
        '
        Me.cmdSearch.Image = Global.General_Ledger.My.Resources.Resources.folder_view
        Me.cmdSearch.Location = New System.Drawing.Point(445, 5)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.Size = New System.Drawing.Size(51, 56)
        Me.cmdSearch.TabIndex = 1
        Me.cmdSearch.Text = "Searc&h"
        Me.cmdSearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdSearch.UseVisualStyleBackColor = True
        '
        'cmdEdit
        '
        Me.cmdEdit.Image = Global.General_Ledger.My.Resources.Resources.folder_edit
        Me.cmdEdit.Location = New System.Drawing.Point(549, 5)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(51, 56)
        Me.cmdEdit.TabIndex = 2
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdEdit.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Image = Global.General_Ledger.My.Resources.Resources.folder_new
        Me.cmdSave.Location = New System.Drawing.Point(601, 5)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(51, 56)
        Me.cmdSave.TabIndex = 9
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cmdDelete
        '
        Me.cmdDelete.Image = Global.General_Ledger.My.Resources.Resources.folder_delete
        Me.cmdDelete.Location = New System.Drawing.Point(652, 5)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(51, 56)
        Me.cmdDelete.TabIndex = 4
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdDelete.UseVisualStyleBackColor = True
        '
        'frmProjectFile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(818, 505)
        Me.Controls.Add(Me.cmdAdd)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.cmdUndo)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.GroupBox2)
        Me.MaximizeBox = False
        Me.Name = "frmProjectFile"
        Me.Text = "Project File"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.cmbProjectAccount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbForfietAccount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbChequeAccount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbCashAccount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPenaltyPer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbSector, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbExtraCharges1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbCity, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbCountry, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbRegion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbProjectPurpose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbProjectType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbName, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents cmdUndo As System.Windows.Forms.Button
    Friend WithEvents cmdEdit As System.Windows.Forms.Button
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents txtCode As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdSearch As System.Windows.Forms.Button
    Friend WithEvents cmdExit As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbName As C1.Win.C1List.C1Combo
    Friend WithEvents cmbCity As C1.Win.C1List.C1Combo
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cmbCountry As C1.Win.C1List.C1Combo
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtPrefix As System.Windows.Forms.TextBox
    Friend WithEvents cmbRegion As C1.Win.C1List.C1Combo
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cmbProjectPurpose As C1.Win.C1List.C1Combo
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmbProjectType As C1.Win.C1List.C1Combo
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents cmdCityList As System.Windows.Forms.Button
    Friend WithEvents cmbExtraCharges10 As C1.Win.C1List.C1Combo
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges8 As C1.Win.C1List.C1Combo
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges7 As C1.Win.C1List.C1Combo
    Friend WithEvents cmbExtraCharges9 As C1.Win.C1List.C1Combo
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges5 As C1.Win.C1List.C1Combo
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges4 As C1.Win.C1List.C1Combo
    Friend WithEvents cmbExtraCharges6 As C1.Win.C1List.C1Combo
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges2 As C1.Win.C1List.C1Combo
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges1 As C1.Win.C1List.C1Combo
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges3 As C1.Win.C1List.C1Combo
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges15 As C1.Win.C1List.C1Combo
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges13 As C1.Win.C1List.C1Combo
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges12 As C1.Win.C1List.C1Combo
    Friend WithEvents cmbExtraCharges14 As C1.Win.C1List.C1Combo
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents cmbExtraCharges11 As C1.Win.C1List.C1Combo
    Friend WithEvents cmbSector As C1.Win.C1List.C1Combo
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtPenaltyPer As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents cmbPenaltyPolicy As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents cmbForfietAccount As C1.Win.C1List.C1Combo
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents cmbChequeAccount As C1.Win.C1List.C1Combo
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents cmbCashAccount As C1.Win.C1List.C1Combo
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents cmbProjectAccount As C1.Win.C1List.C1Combo
    Friend WithEvents cmbProject As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents txtUnOfficialReceiptStart As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtOfficialReceiptStart As System.Windows.Forms.TextBox
    Friend WithEvents chkLoanNotApplicable As System.Windows.Forms.CheckBox
    'Friend WithEvents CachedReport1 As CrystalDecisions.ReportSource.CachedReport
End Class
