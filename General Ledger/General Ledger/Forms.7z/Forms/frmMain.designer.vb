<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.FileMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountsPayableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SuppliersFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator30 = New System.Windows.Forms.ToolStripSeparator()
        Me.ProjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegionFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CountryFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CityFileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ProjectTypeFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProjectPurposeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExtraChargesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SchemeFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.ProjectFIleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LandInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnitsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlockFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnitsTypeFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.UnitsInventoryFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateUnbookedUnitPricesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TodaysStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentPlanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentGroupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentTypesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StandardPaymentPlanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConstructionStageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator()
        Me.AgentCompanyFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AgentFIleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator25 = New System.Windows.Forms.ToolStripSeparator()
        Me.CustomerReservationFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InternalDocumentAuditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CancelUnitsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator()
        Me.GenerateInvoiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GeneratePenaltyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GenerateInvoicesForNotDecidedPaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InvoicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator18 = New System.Windows.Forms.ToolStripSeparator()
        Me.TokenMoneyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReceiptsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransferLetterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerRelationshipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AreaFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerMasterFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator20 = New System.Windows.Forms.ToolStripSeparator()
        Me.LettersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator21 = New System.Windows.Forms.ToolStripSeparator()
        Me.GenerateWelcomeLetterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReminderNotice1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.GenerateFinalNoticeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DocumentsDeficitLetterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CancelLetterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransferLetterToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator22 = New System.Windows.Forms.ToolStripSeparator()
        Me.PrintLettersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SentLettersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator23 = New System.Windows.Forms.ToolStripSeparator()
        Me.FOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PriceListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecoveryReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TokenMoneyReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConstructionStageReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReceptionModuleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator24 = New System.Windows.Forms.ToolStripSeparator()
        Me.ReceptionModuleToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MasterFilesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CurrencyFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesmanFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompanyFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LocationFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DepartmentFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentTermsFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecurityFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator45 = New System.Windows.Forms.ToolStripSeparator()
        Me.UpdateVariableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.CascadeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TileVerticalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TileHorizontalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ArrangeIconsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolBarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusBarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccessoriesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductMasterFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator86 = New System.Windows.Forms.ToolStripSeparator()
        Me.PurchaseRequisitionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PurchaseOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GoodsReceivedNoteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LocalBillAccessoriesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator26 = New System.Windows.Forms.ToolStripSeparator()
        Me.IssueAccessoriesGeneralToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator27 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator28 = New System.Windows.Forms.ToolStripSeparator()
        Me.PurchaseOrderGRNReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccessoriesStockReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.POReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip = New System.Windows.Forms.ToolStrip()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.TaskPane = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel5 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton10 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel3 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel4 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel8 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel18 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel14 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel7 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel6 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel9 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel13 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel12 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel10 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel17 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel16 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel15 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel11 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator19 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripProgressBar1 = New System.Windows.Forms.ToolStripProgressBar()
        Me.PackingTypeFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip.SuspendLayout()
        Me.TaskPane.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.AllowItemReorder = True
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileMenu, Me.AccountsPayableToolStripMenuItem, Me.ProjectToolStripMenuItem, Me.UnitsToolStripMenuItem, Me.PaymentPlanToolStripMenuItem, Me.CustomerRelationshipToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.ReceptionModuleToolStripMenuItem, Me.MasterFilesToolStripMenuItem1, Me.ToolStripMenuItem7, Me.WindowsMenu, Me.ExitToolStripMenuItem1, Me.AccessoriesToolStripMenuItem})
        Me.MenuStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.MdiWindowListItem = Me.WindowsMenu
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(1020, 42)
        Me.MenuStrip.TabIndex = 5
        Me.MenuStrip.Text = "MenuStrip"
        '
        'FileMenu
        '
        Me.FileMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LogOffToolStripMenuItem, Me.ToolStripSeparator5, Me.ExitToolStripMenuItem})
        Me.FileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder
        Me.FileMenu.Name = "FileMenu"
        Me.FileMenu.Size = New System.Drawing.Size(37, 19)
        Me.FileMenu.Text = "&File"
        '
        'LogOffToolStripMenuItem
        '
        Me.LogOffToolStripMenuItem.Image = CType(resources.GetObject("LogOffToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LogOffToolStripMenuItem.Name = "LogOffToolStripMenuItem"
        Me.LogOffToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.LogOffToolStripMenuItem.Text = "&Log off"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(109, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'AccountsPayableToolStripMenuItem
        '
        Me.AccountsPayableToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SuppliersFileToolStripMenuItem, Me.ToolStripSeparator30})
        Me.AccountsPayableToolStripMenuItem.Name = "AccountsPayableToolStripMenuItem"
        Me.AccountsPayableToolStripMenuItem.Size = New System.Drawing.Size(65, 19)
        Me.AccountsPayableToolStripMenuItem.Text = "Payables"
        '
        'SuppliersFileToolStripMenuItem
        '
        Me.SuppliersFileToolStripMenuItem.Name = "SuppliersFileToolStripMenuItem"
        Me.SuppliersFileToolStripMenuItem.Size = New System.Drawing.Size(143, 22)
        Me.SuppliersFileToolStripMenuItem.Text = "Suppliers File"
        '
        'ToolStripSeparator30
        '
        Me.ToolStripSeparator30.Name = "ToolStripSeparator30"
        Me.ToolStripSeparator30.Size = New System.Drawing.Size(140, 6)
        '
        'ProjectToolStripMenuItem
        '
        Me.ProjectToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegionFileToolStripMenuItem, Me.CountryFileToolStripMenuItem, Me.CityFileToolStripMenuItem1, Me.ToolStripSeparator2, Me.ProjectTypeFileToolStripMenuItem, Me.ProjectPurposeToolStripMenuItem, Me.ExtraChargesToolStripMenuItem, Me.SchemeFileToolStripMenuItem, Me.ToolStripSeparator8, Me.ProjectFIleToolStripMenuItem, Me.LandInformationToolStripMenuItem})
        Me.ProjectToolStripMenuItem.Name = "ProjectToolStripMenuItem"
        Me.ProjectToolStripMenuItem.Size = New System.Drawing.Size(56, 19)
        Me.ProjectToolStripMenuItem.Text = "Project"
        '
        'RegionFileToolStripMenuItem
        '
        Me.RegionFileToolStripMenuItem.Name = "RegionFileToolStripMenuItem"
        Me.RegionFileToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.RegionFileToolStripMenuItem.Text = "Region File"
        '
        'CountryFileToolStripMenuItem
        '
        Me.CountryFileToolStripMenuItem.Name = "CountryFileToolStripMenuItem"
        Me.CountryFileToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.CountryFileToolStripMenuItem.Text = "Country File"
        '
        'CityFileToolStripMenuItem1
        '
        Me.CityFileToolStripMenuItem1.Name = "CityFileToolStripMenuItem1"
        Me.CityFileToolStripMenuItem1.Size = New System.Drawing.Size(166, 22)
        Me.CityFileToolStripMenuItem1.Text = "City File"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(163, 6)
        '
        'ProjectTypeFileToolStripMenuItem
        '
        Me.ProjectTypeFileToolStripMenuItem.Name = "ProjectTypeFileToolStripMenuItem"
        Me.ProjectTypeFileToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.ProjectTypeFileToolStripMenuItem.Text = "Project Type File"
        '
        'ProjectPurposeToolStripMenuItem
        '
        Me.ProjectPurposeToolStripMenuItem.Name = "ProjectPurposeToolStripMenuItem"
        Me.ProjectPurposeToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.ProjectPurposeToolStripMenuItem.Text = "Project Purpose"
        '
        'ExtraChargesToolStripMenuItem
        '
        Me.ExtraChargesToolStripMenuItem.Name = "ExtraChargesToolStripMenuItem"
        Me.ExtraChargesToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.ExtraChargesToolStripMenuItem.Text = "Extra Charges"
        '
        'SchemeFileToolStripMenuItem
        '
        Me.SchemeFileToolStripMenuItem.Name = "SchemeFileToolStripMenuItem"
        Me.SchemeFileToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.SchemeFileToolStripMenuItem.Text = "Scheme File"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(163, 6)
        '
        'ProjectFIleToolStripMenuItem
        '
        Me.ProjectFIleToolStripMenuItem.Name = "ProjectFIleToolStripMenuItem"
        Me.ProjectFIleToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.ProjectFIleToolStripMenuItem.Text = "Project FIle"
        '
        'LandInformationToolStripMenuItem
        '
        Me.LandInformationToolStripMenuItem.Name = "LandInformationToolStripMenuItem"
        Me.LandInformationToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.LandInformationToolStripMenuItem.Text = "Land Information"
        '
        'UnitsToolStripMenuItem
        '
        Me.UnitsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BlockFileToolStripMenuItem, Me.UnitsTypeFileToolStripMenuItem, Me.ToolStripSeparator13, Me.UnitsInventoryFileToolStripMenuItem, Me.UpdateUnbookedUnitPricesToolStripMenuItem, Me.TodaysStatusToolStripMenuItem})
        Me.UnitsToolStripMenuItem.Name = "UnitsToolStripMenuItem"
        Me.UnitsToolStripMenuItem.Size = New System.Drawing.Size(46, 19)
        Me.UnitsToolStripMenuItem.Text = "Units"
        '
        'BlockFileToolStripMenuItem
        '
        Me.BlockFileToolStripMenuItem.Name = "BlockFileToolStripMenuItem"
        Me.BlockFileToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.BlockFileToolStripMenuItem.Text = "Block File"
        '
        'UnitsTypeFileToolStripMenuItem
        '
        Me.UnitsTypeFileToolStripMenuItem.Name = "UnitsTypeFileToolStripMenuItem"
        Me.UnitsTypeFileToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.UnitsTypeFileToolStripMenuItem.Text = "Units Type File"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(226, 6)
        '
        'UnitsInventoryFileToolStripMenuItem
        '
        Me.UnitsInventoryFileToolStripMenuItem.Name = "UnitsInventoryFileToolStripMenuItem"
        Me.UnitsInventoryFileToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.UnitsInventoryFileToolStripMenuItem.Text = "Units Inventory File"
        '
        'UpdateUnbookedUnitPricesToolStripMenuItem
        '
        Me.UpdateUnbookedUnitPricesToolStripMenuItem.Name = "UpdateUnbookedUnitPricesToolStripMenuItem"
        Me.UpdateUnbookedUnitPricesToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.UpdateUnbookedUnitPricesToolStripMenuItem.Text = "Update Unbooked Unit Prices"
        '
        'TodaysStatusToolStripMenuItem
        '
        Me.TodaysStatusToolStripMenuItem.Name = "TodaysStatusToolStripMenuItem"
        Me.TodaysStatusToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.TodaysStatusToolStripMenuItem.Text = "Todays Status"
        '
        'PaymentPlanToolStripMenuItem
        '
        Me.PaymentPlanToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PaymentGroupToolStripMenuItem, Me.PaymentTypesToolStripMenuItem, Me.StandardPaymentPlanToolStripMenuItem, Me.ConstructionStageToolStripMenuItem, Me.ToolStripSeparator16, Me.AgentCompanyFileToolStripMenuItem, Me.AgentFIleToolStripMenuItem, Me.ToolStripSeparator25, Me.CustomerReservationFormToolStripMenuItem, Me.InternalDocumentAuditToolStripMenuItem, Me.CancelUnitsToolStripMenuItem, Me.ToolStripSeparator17, Me.GenerateInvoiceToolStripMenuItem, Me.GeneratePenaltyToolStripMenuItem, Me.GenerateInvoicesForNotDecidedPaymentToolStripMenuItem, Me.InvoicesToolStripMenuItem, Me.ToolStripSeparator18, Me.TokenMoneyToolStripMenuItem, Me.ReceiptsToolStripMenuItem, Me.TransferLetterToolStripMenuItem})
        Me.PaymentPlanToolStripMenuItem.Name = "PaymentPlanToolStripMenuItem"
        Me.PaymentPlanToolStripMenuItem.Size = New System.Drawing.Size(164, 19)
        Me.PaymentPlanToolStripMenuItem.Text = "Payment Plan / Reservation"
        '
        'PaymentGroupToolStripMenuItem
        '
        Me.PaymentGroupToolStripMenuItem.Name = "PaymentGroupToolStripMenuItem"
        Me.PaymentGroupToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.PaymentGroupToolStripMenuItem.Text = "Payment Group"
        '
        'PaymentTypesToolStripMenuItem
        '
        Me.PaymentTypesToolStripMenuItem.Name = "PaymentTypesToolStripMenuItem"
        Me.PaymentTypesToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.PaymentTypesToolStripMenuItem.Text = "Payment Types"
        '
        'StandardPaymentPlanToolStripMenuItem
        '
        Me.StandardPaymentPlanToolStripMenuItem.Name = "StandardPaymentPlanToolStripMenuItem"
        Me.StandardPaymentPlanToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.StandardPaymentPlanToolStripMenuItem.Text = "Standard Payment Plan"
        '
        'ConstructionStageToolStripMenuItem
        '
        Me.ConstructionStageToolStripMenuItem.Name = "ConstructionStageToolStripMenuItem"
        Me.ConstructionStageToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.ConstructionStageToolStripMenuItem.Text = "Construction Stage"
        '
        'ToolStripSeparator16
        '
        Me.ToolStripSeparator16.Name = "ToolStripSeparator16"
        Me.ToolStripSeparator16.Size = New System.Drawing.Size(301, 6)
        '
        'AgentCompanyFileToolStripMenuItem
        '
        Me.AgentCompanyFileToolStripMenuItem.Name = "AgentCompanyFileToolStripMenuItem"
        Me.AgentCompanyFileToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.AgentCompanyFileToolStripMenuItem.Text = "Agent Company File"
        '
        'AgentFIleToolStripMenuItem
        '
        Me.AgentFIleToolStripMenuItem.Name = "AgentFIleToolStripMenuItem"
        Me.AgentFIleToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.AgentFIleToolStripMenuItem.Text = "Agent FIle"
        '
        'ToolStripSeparator25
        '
        Me.ToolStripSeparator25.Name = "ToolStripSeparator25"
        Me.ToolStripSeparator25.Size = New System.Drawing.Size(301, 6)
        '
        'CustomerReservationFormToolStripMenuItem
        '
        Me.CustomerReservationFormToolStripMenuItem.Name = "CustomerReservationFormToolStripMenuItem"
        Me.CustomerReservationFormToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.CustomerReservationFormToolStripMenuItem.Text = "Customer Reservation Form"
        '
        'InternalDocumentAuditToolStripMenuItem
        '
        Me.InternalDocumentAuditToolStripMenuItem.Name = "InternalDocumentAuditToolStripMenuItem"
        Me.InternalDocumentAuditToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.InternalDocumentAuditToolStripMenuItem.Text = "Internal Document Audit"
        '
        'CancelUnitsToolStripMenuItem
        '
        Me.CancelUnitsToolStripMenuItem.Name = "CancelUnitsToolStripMenuItem"
        Me.CancelUnitsToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.CancelUnitsToolStripMenuItem.Text = "Cancel Units"
        '
        'ToolStripSeparator17
        '
        Me.ToolStripSeparator17.Name = "ToolStripSeparator17"
        Me.ToolStripSeparator17.Size = New System.Drawing.Size(301, 6)
        '
        'GenerateInvoiceToolStripMenuItem
        '
        Me.GenerateInvoiceToolStripMenuItem.Name = "GenerateInvoiceToolStripMenuItem"
        Me.GenerateInvoiceToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.GenerateInvoiceToolStripMenuItem.Text = "Generate Invoice"
        '
        'GeneratePenaltyToolStripMenuItem
        '
        Me.GeneratePenaltyToolStripMenuItem.Name = "GeneratePenaltyToolStripMenuItem"
        Me.GeneratePenaltyToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.GeneratePenaltyToolStripMenuItem.Text = "Generate Penalty"
        '
        'GenerateInvoicesForNotDecidedPaymentToolStripMenuItem
        '
        Me.GenerateInvoicesForNotDecidedPaymentToolStripMenuItem.Name = "GenerateInvoicesForNotDecidedPaymentToolStripMenuItem"
        Me.GenerateInvoicesForNotDecidedPaymentToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.GenerateInvoicesForNotDecidedPaymentToolStripMenuItem.Text = "Generate Invoices for Not Decided Payment"
        '
        'InvoicesToolStripMenuItem
        '
        Me.InvoicesToolStripMenuItem.Name = "InvoicesToolStripMenuItem"
        Me.InvoicesToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.InvoicesToolStripMenuItem.Text = "Invoices"
        '
        'ToolStripSeparator18
        '
        Me.ToolStripSeparator18.Name = "ToolStripSeparator18"
        Me.ToolStripSeparator18.Size = New System.Drawing.Size(301, 6)
        '
        'TokenMoneyToolStripMenuItem
        '
        Me.TokenMoneyToolStripMenuItem.Name = "TokenMoneyToolStripMenuItem"
        Me.TokenMoneyToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.TokenMoneyToolStripMenuItem.Text = "Token Money"
        '
        'ReceiptsToolStripMenuItem
        '
        Me.ReceiptsToolStripMenuItem.Name = "ReceiptsToolStripMenuItem"
        Me.ReceiptsToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.ReceiptsToolStripMenuItem.Text = "Receipts"
        '
        'TransferLetterToolStripMenuItem
        '
        Me.TransferLetterToolStripMenuItem.Name = "TransferLetterToolStripMenuItem"
        Me.TransferLetterToolStripMenuItem.Size = New System.Drawing.Size(304, 22)
        Me.TransferLetterToolStripMenuItem.Text = "Transfer Unit"
        '
        'CustomerRelationshipToolStripMenuItem
        '
        Me.CustomerRelationshipToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AreaFileToolStripMenuItem, Me.CustomerMasterFileToolStripMenuItem, Me.ToolStripSeparator20, Me.LettersToolStripMenuItem, Me.ToolStripSeparator21, Me.GenerateWelcomeLetterToolStripMenuItem, Me.ReminderNotice1ToolStripMenuItem, Me.ToolStripMenuItem3, Me.GenerateFinalNoticeToolStripMenuItem, Me.DocumentsDeficitLetterToolStripMenuItem, Me.CancelLetterToolStripMenuItem, Me.TransferLetterToolStripMenuItem1, Me.ToolStripSeparator22, Me.PrintLettersToolStripMenuItem, Me.SentLettersToolStripMenuItem, Me.ToolStripSeparator23, Me.FOToolStripMenuItem})
        Me.CustomerRelationshipToolStripMenuItem.Name = "CustomerRelationshipToolStripMenuItem"
        Me.CustomerRelationshipToolStripMenuItem.Size = New System.Drawing.Size(139, 19)
        Me.CustomerRelationshipToolStripMenuItem.Text = "Customer Relationship"
        '
        'AreaFileToolStripMenuItem
        '
        Me.AreaFileToolStripMenuItem.Name = "AreaFileToolStripMenuItem"
        Me.AreaFileToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.AreaFileToolStripMenuItem.Text = "Area File"
        '
        'CustomerMasterFileToolStripMenuItem
        '
        Me.CustomerMasterFileToolStripMenuItem.Name = "CustomerMasterFileToolStripMenuItem"
        Me.CustomerMasterFileToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.CustomerMasterFileToolStripMenuItem.Text = "Customer Master File"
        '
        'ToolStripSeparator20
        '
        Me.ToolStripSeparator20.Name = "ToolStripSeparator20"
        Me.ToolStripSeparator20.Size = New System.Drawing.Size(219, 6)
        '
        'LettersToolStripMenuItem
        '
        Me.LettersToolStripMenuItem.Name = "LettersToolStripMenuItem"
        Me.LettersToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.LettersToolStripMenuItem.Text = "Letters History"
        '
        'ToolStripSeparator21
        '
        Me.ToolStripSeparator21.Name = "ToolStripSeparator21"
        Me.ToolStripSeparator21.Size = New System.Drawing.Size(219, 6)
        '
        'GenerateWelcomeLetterToolStripMenuItem
        '
        Me.GenerateWelcomeLetterToolStripMenuItem.Name = "GenerateWelcomeLetterToolStripMenuItem"
        Me.GenerateWelcomeLetterToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.GenerateWelcomeLetterToolStripMenuItem.Text = "Generate Welcome Letter"
        '
        'ReminderNotice1ToolStripMenuItem
        '
        Me.ReminderNotice1ToolStripMenuItem.Name = "ReminderNotice1ToolStripMenuItem"
        Me.ReminderNotice1ToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.ReminderNotice1ToolStripMenuItem.Text = "Generate Reminder Notice 1"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(222, 22)
        Me.ToolStripMenuItem3.Text = "Generate Demand Notice 1"
        '
        'GenerateFinalNoticeToolStripMenuItem
        '
        Me.GenerateFinalNoticeToolStripMenuItem.Name = "GenerateFinalNoticeToolStripMenuItem"
        Me.GenerateFinalNoticeToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.GenerateFinalNoticeToolStripMenuItem.Text = "Generate Final Notice"
        '
        'DocumentsDeficitLetterToolStripMenuItem
        '
        Me.DocumentsDeficitLetterToolStripMenuItem.Name = "DocumentsDeficitLetterToolStripMenuItem"
        Me.DocumentsDeficitLetterToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.DocumentsDeficitLetterToolStripMenuItem.Text = "Documents Deficit Letter"
        '
        'CancelLetterToolStripMenuItem
        '
        Me.CancelLetterToolStripMenuItem.Name = "CancelLetterToolStripMenuItem"
        Me.CancelLetterToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.CancelLetterToolStripMenuItem.Text = "Cancel Letter"
        '
        'TransferLetterToolStripMenuItem1
        '
        Me.TransferLetterToolStripMenuItem1.Name = "TransferLetterToolStripMenuItem1"
        Me.TransferLetterToolStripMenuItem1.Size = New System.Drawing.Size(222, 22)
        Me.TransferLetterToolStripMenuItem1.Text = "Transfer Letter"
        '
        'ToolStripSeparator22
        '
        Me.ToolStripSeparator22.Name = "ToolStripSeparator22"
        Me.ToolStripSeparator22.Size = New System.Drawing.Size(219, 6)
        '
        'PrintLettersToolStripMenuItem
        '
        Me.PrintLettersToolStripMenuItem.Name = "PrintLettersToolStripMenuItem"
        Me.PrintLettersToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.PrintLettersToolStripMenuItem.Text = "Print Letters"
        '
        'SentLettersToolStripMenuItem
        '
        Me.SentLettersToolStripMenuItem.Name = "SentLettersToolStripMenuItem"
        Me.SentLettersToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.SentLettersToolStripMenuItem.Text = "Sent Letters"
        '
        'ToolStripSeparator23
        '
        Me.ToolStripSeparator23.Name = "ToolStripSeparator23"
        Me.ToolStripSeparator23.Size = New System.Drawing.Size(219, 6)
        '
        'FOToolStripMenuItem
        '
        Me.FOToolStripMenuItem.Name = "FOToolStripMenuItem"
        Me.FOToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.FOToolStripMenuItem.Text = "Recovery Followup"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PriceListToolStripMenuItem, Me.RecoveryReportToolStripMenuItem, Me.TokenMoneyReportToolStripMenuItem, Me.ConstructionStageReportToolStripMenuItem, Me.ToolStripMenuItem4})
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(59, 19)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        '
        'PriceListToolStripMenuItem
        '
        Me.PriceListToolStripMenuItem.Name = "PriceListToolStripMenuItem"
        Me.PriceListToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.PriceListToolStripMenuItem.Text = "Inventory Report"
        '
        'RecoveryReportToolStripMenuItem
        '
        Me.RecoveryReportToolStripMenuItem.Name = "RecoveryReportToolStripMenuItem"
        Me.RecoveryReportToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.RecoveryReportToolStripMenuItem.Text = "Recovery Report"
        '
        'TokenMoneyReportToolStripMenuItem
        '
        Me.TokenMoneyReportToolStripMenuItem.Name = "TokenMoneyReportToolStripMenuItem"
        Me.TokenMoneyReportToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.TokenMoneyReportToolStripMenuItem.Text = "Token Money Report"
        '
        'ConstructionStageReportToolStripMenuItem
        '
        Me.ConstructionStageReportToolStripMenuItem.Name = "ConstructionStageReportToolStripMenuItem"
        Me.ConstructionStageReportToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.ConstructionStageReportToolStripMenuItem.Text = "Construction Stage Report"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(213, 22)
        Me.ToolStripMenuItem4.Text = "Receipt Report"
        '
        'ReceptionModuleToolStripMenuItem
        '
        Me.ReceptionModuleToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TaskFToolStripMenuItem, Me.ToolStripSeparator24, Me.ReceptionModuleToolStripMenuItem1})
        Me.ReceptionModuleToolStripMenuItem.Name = "ReceptionModuleToolStripMenuItem"
        Me.ReceptionModuleToolStripMenuItem.Size = New System.Drawing.Size(116, 19)
        Me.ReceptionModuleToolStripMenuItem.Text = "Reception Module"
        '
        'TaskFToolStripMenuItem
        '
        Me.TaskFToolStripMenuItem.Name = "TaskFToolStripMenuItem"
        Me.TaskFToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.TaskFToolStripMenuItem.Text = "Task Master File"
        '
        'ToolStripSeparator24
        '
        Me.ToolStripSeparator24.Name = "ToolStripSeparator24"
        Me.ToolStripSeparator24.Size = New System.Drawing.Size(168, 6)
        '
        'ReceptionModuleToolStripMenuItem1
        '
        Me.ReceptionModuleToolStripMenuItem1.Name = "ReceptionModuleToolStripMenuItem1"
        Me.ReceptionModuleToolStripMenuItem1.Size = New System.Drawing.Size(171, 22)
        Me.ReceptionModuleToolStripMenuItem1.Text = "Reception Module"
        '
        'MasterFilesToolStripMenuItem1
        '
        Me.MasterFilesToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CurrencyFileToolStripMenuItem, Me.SalesmanFileToolStripMenuItem, Me.CompanyFileToolStripMenuItem, Me.LocationFileToolStripMenuItem, Me.DepartmentFileToolStripMenuItem, Me.PaymentTermsFileToolStripMenuItem, Me.PackingTypeFileToolStripMenuItem})
        Me.MasterFilesToolStripMenuItem1.Name = "MasterFilesToolStripMenuItem1"
        Me.MasterFilesToolStripMenuItem1.Size = New System.Drawing.Size(81, 19)
        Me.MasterFilesToolStripMenuItem1.Text = "Master Files"
        '
        'CurrencyFileToolStripMenuItem
        '
        Me.CurrencyFileToolStripMenuItem.Name = "CurrencyFileToolStripMenuItem"
        Me.CurrencyFileToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.CurrencyFileToolStripMenuItem.Text = "Currency File"
        '
        'SalesmanFileToolStripMenuItem
        '
        Me.SalesmanFileToolStripMenuItem.Name = "SalesmanFileToolStripMenuItem"
        Me.SalesmanFileToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SalesmanFileToolStripMenuItem.Text = "Salesman File"
        '
        'CompanyFileToolStripMenuItem
        '
        Me.CompanyFileToolStripMenuItem.Name = "CompanyFileToolStripMenuItem"
        Me.CompanyFileToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.CompanyFileToolStripMenuItem.Text = "Company File"
        '
        'LocationFileToolStripMenuItem
        '
        Me.LocationFileToolStripMenuItem.Name = "LocationFileToolStripMenuItem"
        Me.LocationFileToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.LocationFileToolStripMenuItem.Text = "Location File"
        '
        'DepartmentFileToolStripMenuItem
        '
        Me.DepartmentFileToolStripMenuItem.Name = "DepartmentFileToolStripMenuItem"
        Me.DepartmentFileToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.DepartmentFileToolStripMenuItem.Text = "Department File"
        '
        'PaymentTermsFileToolStripMenuItem
        '
        Me.PaymentTermsFileToolStripMenuItem.Name = "PaymentTermsFileToolStripMenuItem"
        Me.PaymentTermsFileToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.PaymentTermsFileToolStripMenuItem.Text = "Payment Terms File"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SecurityFileToolStripMenuItem, Me.ToolStripSeparator45, Me.UpdateVariableToolStripMenuItem})
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(98, 19)
        Me.ToolStripMenuItem7.Text = "&Administration"
        '
        'SecurityFileToolStripMenuItem
        '
        Me.SecurityFileToolStripMenuItem.Name = "SecurityFileToolStripMenuItem"
        Me.SecurityFileToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.SecurityFileToolStripMenuItem.Text = "&Security File"
        '
        'ToolStripSeparator45
        '
        Me.ToolStripSeparator45.Name = "ToolStripSeparator45"
        Me.ToolStripSeparator45.Size = New System.Drawing.Size(153, 6)
        '
        'UpdateVariableToolStripMenuItem
        '
        Me.UpdateVariableToolStripMenuItem.Name = "UpdateVariableToolStripMenuItem"
        Me.UpdateVariableToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.UpdateVariableToolStripMenuItem.Text = "Update Variable"
        '
        'WindowsMenu
        '
        Me.WindowsMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CascadeToolStripMenuItem, Me.TileVerticalToolStripMenuItem, Me.TileHorizontalToolStripMenuItem, Me.CloseAllToolStripMenuItem, Me.ArrangeIconsToolStripMenuItem, Me.ToolStripSeparator1, Me.ToolBarToolStripMenuItem, Me.StatusBarToolStripMenuItem, Me.ToolStripMenuItem1})
        Me.WindowsMenu.Name = "WindowsMenu"
        Me.WindowsMenu.Size = New System.Drawing.Size(68, 19)
        Me.WindowsMenu.Text = "&Windows"
        '
        'CascadeToolStripMenuItem
        '
        Me.CascadeToolStripMenuItem.Name = "CascadeToolStripMenuItem"
        Me.CascadeToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.CascadeToolStripMenuItem.Text = "&Cascade"
        '
        'TileVerticalToolStripMenuItem
        '
        Me.TileVerticalToolStripMenuItem.Name = "TileVerticalToolStripMenuItem"
        Me.TileVerticalToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.TileVerticalToolStripMenuItem.Text = "Tile &Vertical"
        '
        'TileHorizontalToolStripMenuItem
        '
        Me.TileHorizontalToolStripMenuItem.Name = "TileHorizontalToolStripMenuItem"
        Me.TileHorizontalToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.TileHorizontalToolStripMenuItem.Text = "Tile &Horizontal"
        '
        'CloseAllToolStripMenuItem
        '
        Me.CloseAllToolStripMenuItem.Name = "CloseAllToolStripMenuItem"
        Me.CloseAllToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.CloseAllToolStripMenuItem.Text = "C&lose All"
        '
        'ArrangeIconsToolStripMenuItem
        '
        Me.ArrangeIconsToolStripMenuItem.Name = "ArrangeIconsToolStripMenuItem"
        Me.ArrangeIconsToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.ArrangeIconsToolStripMenuItem.Text = "&Arrange Icons"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(147, 6)
        '
        'ToolBarToolStripMenuItem
        '
        Me.ToolBarToolStripMenuItem.Checked = True
        Me.ToolBarToolStripMenuItem.CheckOnClick = True
        Me.ToolBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolBarToolStripMenuItem.Name = "ToolBarToolStripMenuItem"
        Me.ToolBarToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.ToolBarToolStripMenuItem.Text = "&Tool Bar"
        '
        'StatusBarToolStripMenuItem
        '
        Me.StatusBarToolStripMenuItem.Checked = True
        Me.StatusBarToolStripMenuItem.CheckOnClick = True
        Me.StatusBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.StatusBarToolStripMenuItem.Name = "StatusBarToolStripMenuItem"
        Me.StatusBarToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.StatusBarToolStripMenuItem.Text = "&Status Bar"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Checked = True
        Me.ToolStripMenuItem1.CheckOnClick = True
        Me.ToolStripMenuItem1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(150, 22)
        Me.ToolStripMenuItem1.Text = "Task &Pane"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(37, 17)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        Me.ExitToolStripMenuItem1.Visible = False
        '
        'AccessoriesToolStripMenuItem
        '
        Me.AccessoriesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProductMasterFileToolStripMenuItem, Me.ToolStripSeparator86, Me.PurchaseRequisitionToolStripMenuItem, Me.PurchaseOrderToolStripMenuItem, Me.GoodsReceivedNoteToolStripMenuItem, Me.LocalBillAccessoriesToolStripMenuItem, Me.ToolStripSeparator26, Me.IssueAccessoriesGeneralToolStripMenuItem, Me.ToolStripSeparator27, Me.ToolStripSeparator28, Me.PurchaseOrderGRNReportToolStripMenuItem, Me.AccessoriesStockReportToolStripMenuItem, Me.POReportToolStripMenuItem})
        Me.AccessoriesToolStripMenuItem.Name = "AccessoriesToolStripMenuItem"
        Me.AccessoriesToolStripMenuItem.Size = New System.Drawing.Size(114, 19)
        Me.AccessoriesToolStripMenuItem.Text = "Product Inventory"
        '
        'ProductMasterFileToolStripMenuItem
        '
        Me.ProductMasterFileToolStripMenuItem.Name = "ProductMasterFileToolStripMenuItem"
        Me.ProductMasterFileToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.ProductMasterFileToolStripMenuItem.Text = "Product Master File"
        '
        'ToolStripSeparator86
        '
        Me.ToolStripSeparator86.Name = "ToolStripSeparator86"
        Me.ToolStripSeparator86.Size = New System.Drawing.Size(184, 6)
        '
        'PurchaseRequisitionToolStripMenuItem
        '
        Me.PurchaseRequisitionToolStripMenuItem.Name = "PurchaseRequisitionToolStripMenuItem"
        Me.PurchaseRequisitionToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.PurchaseRequisitionToolStripMenuItem.Text = "Purchase Requisition"
        '
        'PurchaseOrderToolStripMenuItem
        '
        Me.PurchaseOrderToolStripMenuItem.Name = "PurchaseOrderToolStripMenuItem"
        Me.PurchaseOrderToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.PurchaseOrderToolStripMenuItem.Text = "Purchase Order"
        '
        'GoodsReceivedNoteToolStripMenuItem
        '
        Me.GoodsReceivedNoteToolStripMenuItem.Name = "GoodsReceivedNoteToolStripMenuItem"
        Me.GoodsReceivedNoteToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.GoodsReceivedNoteToolStripMenuItem.Text = "Goods Received Note"
        '
        'LocalBillAccessoriesToolStripMenuItem
        '
        Me.LocalBillAccessoriesToolStripMenuItem.Name = "LocalBillAccessoriesToolStripMenuItem"
        Me.LocalBillAccessoriesToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.LocalBillAccessoriesToolStripMenuItem.Text = "Purchase Bill Product"
        '
        'ToolStripSeparator26
        '
        Me.ToolStripSeparator26.Name = "ToolStripSeparator26"
        Me.ToolStripSeparator26.Size = New System.Drawing.Size(184, 6)
        '
        'IssueAccessoriesGeneralToolStripMenuItem
        '
        Me.IssueAccessoriesGeneralToolStripMenuItem.Name = "IssueAccessoriesGeneralToolStripMenuItem"
        Me.IssueAccessoriesGeneralToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.IssueAccessoriesGeneralToolStripMenuItem.Text = "Issue Product"
        '
        'ToolStripSeparator27
        '
        Me.ToolStripSeparator27.Name = "ToolStripSeparator27"
        Me.ToolStripSeparator27.Size = New System.Drawing.Size(184, 6)
        '
        'ToolStripSeparator28
        '
        Me.ToolStripSeparator28.Name = "ToolStripSeparator28"
        Me.ToolStripSeparator28.Size = New System.Drawing.Size(184, 6)
        '
        'PurchaseOrderGRNReportToolStripMenuItem
        '
        Me.PurchaseOrderGRNReportToolStripMenuItem.Name = "PurchaseOrderGRNReportToolStripMenuItem"
        Me.PurchaseOrderGRNReportToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.PurchaseOrderGRNReportToolStripMenuItem.Text = "Product Reports"
        '
        'AccessoriesStockReportToolStripMenuItem
        '
        Me.AccessoriesStockReportToolStripMenuItem.Name = "AccessoriesStockReportToolStripMenuItem"
        Me.AccessoriesStockReportToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.AccessoriesStockReportToolStripMenuItem.Text = "Product Stock Report"
        '
        'POReportToolStripMenuItem
        '
        Me.POReportToolStripMenuItem.Name = "POReportToolStripMenuItem"
        Me.POReportToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.POReportToolStripMenuItem.Text = "PO Report"
        '
        'ToolStrip
        '
        Me.ToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip.Location = New System.Drawing.Point(0, 42)
        Me.ToolStrip.Name = "ToolStrip"
        Me.ToolStrip.Size = New System.Drawing.Size(1020, 25)
        Me.ToolStrip.TabIndex = 6
        Me.ToolStrip.Text = "ToolStrip"
        '
        'TaskPane
        '
        Me.TaskPane.AutoSize = False
        Me.TaskPane.Dock = System.Windows.Forms.DockStyle.Left
        Me.TaskPane.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.TaskPane.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1, Me.ToolStripLabel5, Me.ToolStripSeparator3, Me.ToolStripButton2, Me.ToolStripButton10, Me.ToolStripButton5, Me.ToolStripSeparator11, Me.ToolStripLabel2, Me.ToolStripLabel3, Me.ToolStripLabel4, Me.ToolStripSeparator4, Me.ToolStripLabel8, Me.ToolStripLabel18, Me.ToolStripLabel14, Me.ToolStripLabel7, Me.ToolStripLabel6, Me.ToolStripSeparator6})
        Me.TaskPane.Location = New System.Drawing.Point(0, 67)
        Me.TaskPane.Name = "TaskPane"
        Me.TaskPane.Size = New System.Drawing.Size(181, 626)
        Me.TaskPane.TabIndex = 9
        Me.TaskPane.Text = "ToolStrip1"
        Me.TaskPane.Visible = False
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.AutoSize = False
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel1.Image = CType(resources.GetObject("ToolStripLabel1.Image"), System.Drawing.Image)
        Me.ToolStripLabel1.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(130, 40)
        Me.ToolStripLabel1.Text = "Short Menu"
        Me.ToolStripLabel1.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'ToolStripLabel5
        '
        Me.ToolStripLabel5.Font = New System.Drawing.Font("Microsoft Sans Serif", 4.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel5.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.ToolStripLabel5.Name = "ToolStripLabel5"
        Me.ToolStripLabel5.Size = New System.Drawing.Size(179, 7)
        Me.ToolStripLabel5.Text = " "
        Me.ToolStripLabel5.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.AutoSize = False
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(144, 6)
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.AutoSize = False
        Me.ToolStripButton2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never
        Me.ToolStripButton2.Size = New System.Drawing.Size(140, 35)
        Me.ToolStripButton2.Text = "   Log Out"
        Me.ToolStripButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripButton10
        '
        Me.ToolStripButton10.AutoSize = False
        Me.ToolStripButton10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripButton10.Image = CType(resources.GetObject("ToolStripButton10.Image"), System.Drawing.Image)
        Me.ToolStripButton10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ToolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton10.Name = "ToolStripButton10"
        Me.ToolStripButton10.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never
        Me.ToolStripButton10.Size = New System.Drawing.Size(140, 35)
        Me.ToolStripButton10.Text = "   Change Password"
        Me.ToolStripButton10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.AutoSize = False
        Me.ToolStripButton5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripButton5.Image = CType(resources.GetObject("ToolStripButton5.Image"), System.Drawing.Image)
        Me.ToolStripButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never
        Me.ToolStripButton5.Size = New System.Drawing.Size(140, 35)
        Me.ToolStripButton5.Text = "   About G-Tech"
        Me.ToolStripButton5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.AutoSize = False
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(144, 6)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.AutoSize = False
        Me.ToolStripLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel2.Image = CType(resources.GetObject("ToolStripLabel2.Image"), System.Drawing.Image)
        Me.ToolStripLabel2.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(130, 30)
        Me.ToolStripLabel2.Text = "Today"
        Me.ToolStripLabel2.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'ToolStripLabel3
        '
        Me.ToolStripLabel3.AutoSize = False
        Me.ToolStripLabel3.Name = "ToolStripLabel3"
        Me.ToolStripLabel3.Size = New System.Drawing.Size(140, 13)
        Me.ToolStripLabel3.Text = "        Date :  Sep 30, 2006"
        Me.ToolStripLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripLabel4
        '
        Me.ToolStripLabel4.AutoSize = False
        Me.ToolStripLabel4.Name = "ToolStripLabel4"
        Me.ToolStripLabel4.Size = New System.Drawing.Size(140, 13)
        Me.ToolStripLabel4.Text = "        Time : 11:43 AM"
        Me.ToolStripLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.AutoSize = False
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(144, 20)
        '
        'ToolStripLabel8
        '
        Me.ToolStripLabel8.AutoSize = False
        Me.ToolStripLabel8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel8.Image = CType(resources.GetObject("ToolStripLabel8.Image"), System.Drawing.Image)
        Me.ToolStripLabel8.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.ToolStripLabel8.Name = "ToolStripLabel8"
        Me.ToolStripLabel8.Size = New System.Drawing.Size(130, 25)
        Me.ToolStripLabel8.Text = "Login"
        Me.ToolStripLabel8.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'ToolStripLabel18
        '
        Me.ToolStripLabel18.AutoSize = False
        Me.ToolStripLabel18.Name = "ToolStripLabel18"
        Me.ToolStripLabel18.Size = New System.Drawing.Size(140, 13)
        Me.ToolStripLabel18.Text = "        Data Server :  Server"
        Me.ToolStripLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripLabel14
        '
        Me.ToolStripLabel14.AutoSize = False
        Me.ToolStripLabel14.Name = "ToolStripLabel14"
        Me.ToolStripLabel14.Size = New System.Drawing.Size(140, 13)
        Me.ToolStripLabel14.Text = "        Data Year     :  2009"
        Me.ToolStripLabel14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripLabel7
        '
        Me.ToolStripLabel7.AutoSize = False
        Me.ToolStripLabel7.Name = "ToolStripLabel7"
        Me.ToolStripLabel7.Size = New System.Drawing.Size(140, 13)
        Me.ToolStripLabel7.Text = "             User :  "
        Me.ToolStripLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripLabel6
        '
        Me.ToolStripLabel6.AutoSize = False
        Me.ToolStripLabel6.Name = "ToolStripLabel6"
        Me.ToolStripLabel6.Size = New System.Drawing.Size(140, 13)
        Me.ToolStripLabel6.Text = "             Time : "
        Me.ToolStripLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.AutoSize = False
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(144, 20)
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'StatusStrip
        '
        Me.StatusStrip.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.StatusStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel9, Me.ToolStripSeparator7, Me.ToolStripLabel13, Me.ToolStripSeparator10, Me.ToolStripLabel12, Me.ToolStripSeparator12, Me.ToolStripLabel10, Me.ToolStripSeparator9, Me.ToolStripLabel17, Me.ToolStripSeparator14, Me.ToolStripLabel16, Me.ToolStripSeparator15, Me.ToolStripLabel15, Me.ToolStripLabel11, Me.ToolStripSeparator19, Me.ToolStripProgressBar1})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 676)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(1020, 25)
        Me.StatusStrip.TabIndex = 11
        Me.StatusStrip.Text = "ToolStrip1"
        '
        'ToolStripLabel9
        '
        Me.ToolStripLabel9.AutoSize = False
        Me.ToolStripLabel9.Name = "ToolStripLabel9"
        Me.ToolStripLabel9.Size = New System.Drawing.Size(180, 20)
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel13
        '
        Me.ToolStripLabel13.AutoSize = False
        Me.ToolStripLabel13.Name = "ToolStripLabel13"
        Me.ToolStripLabel13.Size = New System.Drawing.Size(120, 20)
        Me.ToolStripLabel13.Text = "Date : Sep 30, 2007"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel12
        '
        Me.ToolStripLabel12.AutoSize = False
        Me.ToolStripLabel12.Name = "ToolStripLabel12"
        Me.ToolStripLabel12.Size = New System.Drawing.Size(120, 20)
        Me.ToolStripLabel12.Text = "Time : 11:43 AM"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel10
        '
        Me.ToolStripLabel10.AutoSize = False
        Me.ToolStripLabel10.Name = "ToolStripLabel10"
        Me.ToolStripLabel10.Size = New System.Drawing.Size(35, 20)
        Me.ToolStripLabel10.Text = "Caps"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel17
        '
        Me.ToolStripLabel17.AutoSize = False
        Me.ToolStripLabel17.Name = "ToolStripLabel17"
        Me.ToolStripLabel17.Size = New System.Drawing.Size(35, 20)
        Me.ToolStripLabel17.Text = "Num"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel16
        '
        Me.ToolStripLabel16.AutoSize = False
        Me.ToolStripLabel16.Name = "ToolStripLabel16"
        Me.ToolStripLabel16.Size = New System.Drawing.Size(35, 20)
        Me.ToolStripLabel16.Text = "Scrl"
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel15
        '
        Me.ToolStripLabel15.Name = "ToolStripLabel15"
        Me.ToolStripLabel15.Size = New System.Drawing.Size(0, 22)
        '
        'ToolStripLabel11
        '
        Me.ToolStripLabel11.Name = "ToolStripLabel11"
        Me.ToolStripLabel11.Size = New System.Drawing.Size(272, 22)
        Me.ToolStripLabel11.Text = " A Product of G-TECH  (Last Updated : 10-02-2012)"
        '
        'ToolStripSeparator19
        '
        Me.ToolStripSeparator19.Name = "ToolStripSeparator19"
        Me.ToolStripSeparator19.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripProgressBar1
        '
        Me.ToolStripProgressBar1.AutoSize = False
        Me.ToolStripProgressBar1.Name = "ToolStripProgressBar1"
        Me.ToolStripProgressBar1.Size = New System.Drawing.Size(208, 16)
        Me.ToolStripProgressBar1.Visible = False
        '
        'PackingTypeFileToolStripMenuItem
        '
        Me.PackingTypeFileToolStripMenuItem.Name = "PackingTypeFileToolStripMenuItem"
        Me.PackingTypeFileToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.PackingTypeFileToolStripMenuItem.Text = "Packing Type File"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1020, 701)
        Me.Controls.Add(Me.TaskPane)
        Me.Controls.Add(Me.ToolStrip)
        Me.Controls.Add(Me.MenuStrip)
        Me.Controls.Add(Me.StatusStrip)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip
        Me.Name = "frmMain"
        Me.Text = " "
        Me.TransparencyKey = System.Drawing.SystemColors.AppWorkspace
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.TaskPane.ResumeLayout(False)
        Me.TaskPane.PerformLayout()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ArrangeIconsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WindowsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CascadeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TileVerticalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TileHorizontalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents ToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents LogOffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents TaskPane As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton5 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel2 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel3 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel4 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel5 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel8 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel7 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel6 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents StatusStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton10 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel9 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel10 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel13 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel12 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel17 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel16 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator15 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel15 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator19 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel11 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripProgressBar1 As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SecurityFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripLabel18 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel14 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolBarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusBarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccountsPayableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SuppliersFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterFilesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CurrencyFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator30 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SalesmanFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CompanyFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator45 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ProjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CountryFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CityFileToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegionFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ProjectTypeFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProjectPurposeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExtraChargesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ProjectFIleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LandInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnitsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnitsTypeFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents UnitsInventoryFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BlockFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerRelationshipToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerMasterFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AreaFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentPlanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentTypesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StandardPaymentPlanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator16 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CustomerReservationFormToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator17 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GenerateInvoiceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InvoicesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator18 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ReceiptsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateUnbookedUnitPricesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateVariableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SchemeFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PriceListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecoveryReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransferLetterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CancelUnitsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator20 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents LettersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator21 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GenerateWelcomeLetterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DocumentsDeficitLetterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CancelLetterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransferLetterToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator22 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PrintLettersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SentLettersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GenerateInvoicesForNotDecidedPaymentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GeneratePenaltyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TodaysStatusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TokenMoneyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TokenMoneyReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConstructionStageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConstructionStageReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator23 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ReceptionModuleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaskFToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator24 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ReceptionModuleToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentGroupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AgentCompanyFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AgentFIleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator25 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GenerateFinalNoticeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InternalDocumentAuditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReminderNotice1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccessoriesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProductMasterFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator86 As ToolStripSeparator
    Friend WithEvents PurchaseRequisitionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PurchaseOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GoodsReceivedNoteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LocalBillAccessoriesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator26 As ToolStripSeparator
    Friend WithEvents IssueAccessoriesGeneralToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator27 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator28 As ToolStripSeparator
    Friend WithEvents PurchaseOrderGRNReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AccessoriesStockReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents POReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LocationFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DepartmentFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PaymentTermsFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PackingTypeFileToolStripMenuItem As ToolStripMenuItem
End Class
