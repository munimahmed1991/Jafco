﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPurRequisitionProduct
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPurRequisitionProduct))
        Dim Style101 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style102 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style103 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style104 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style105 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style106 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style107 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style108 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style109 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style110 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style111 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style112 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style113 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style114 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style115 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style116 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style117 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style118 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style119 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style120 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtGeneratedBy = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtNeedByDate = New C1.Win.C1Input.C1DateEdit()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmbPurpose = New C1.Win.C1List.C1Combo()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbDeliveryLocation = New C1.Win.C1List.C1Combo()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtCancelUser = New System.Windows.Forms.TextBox()
        Me.txtCancelDate = New C1.Win.C1Input.C1DateEdit()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtCancelRemarks = New System.Windows.Forms.TextBox()
        Me.chkCancel = New System.Windows.Forms.CheckBox()
        Me.cmbDepartment = New C1.Win.C1List.C1Combo()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtReqDate = New C1.Win.C1Input.C1DateEdit()
        Me.txtReqNo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cmdUndo = New System.Windows.Forms.Button()
        Me.cmdSearch = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.tdbSupplier = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown()
        Me.cmdPickProduct = New System.Windows.Forms.Button()
        Me.tdbProduct = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown()
        Me.tdbGridOrderDetail = New C1.Win.C1TrueDBGrid.C1TrueDBGrid()
        Me.cmdPrint = New System.Windows.Forms.Button()
        Me.lblFlag = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cmbProject = New C1.Win.C1List.C1Combo()
        Me.GroupBox1.SuspendLayout()
        CType(Me.txtNeedByDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbPurpose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbDeliveryLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCancelDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbDepartment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtReqDate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.tdbSupplier, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbProduct, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbGridOrderDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbProject, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtGeneratedBy)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtNeedByDate)
        Me.GroupBox1.Controls.Add(Me.cmdCancel)
        Me.GroupBox1.Controls.Add(Me.cmbPurpose)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.cmbDeliveryLocation)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtCancelUser)
        Me.GroupBox1.Controls.Add(Me.txtCancelDate)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtCancelRemarks)
        Me.GroupBox1.Controls.Add(Me.chkCancel)
        Me.GroupBox1.Controls.Add(Me.cmbProject)
        Me.GroupBox1.Controls.Add(Me.cmbDepartment)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtDescription)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtReqDate)
        Me.GroupBox1.Controls.Add(Me.txtReqNo)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 95)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(758, 203)
        Me.GroupBox1.TabIndex = 177
        Me.GroupBox1.TabStop = False
        '
        'txtGeneratedBy
        '
        Me.txtGeneratedBy.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtGeneratedBy.Location = New System.Drawing.Point(395, 93)
        Me.txtGeneratedBy.Name = "txtGeneratedBy"
        Me.txtGeneratedBy.Size = New System.Drawing.Size(122, 20)
        Me.txtGeneratedBy.TabIndex = 256
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(317, 97)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(66, 13)
        Me.Label9.TabIndex = 255
        Me.Label9.Text = "Generted By"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(317, 70)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 13)
        Me.Label4.TabIndex = 254
        Me.Label4.Text = "Need by Date"
        '
        'txtNeedByDate
        '
        Me.txtNeedByDate.AllowSpinLoop = False
        Me.txtNeedByDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtNeedByDate.Calendar.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtNeedByDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtNeedByDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtNeedByDate.Culture = 1056
        Me.txtNeedByDate.CustomFormat = "dd/MM/yyyy"
        Me.txtNeedByDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtNeedByDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtNeedByDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNeedByDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtNeedByDate.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtNeedByDate.Location = New System.Drawing.Point(394, 67)
        Me.txtNeedByDate.Name = "txtNeedByDate"
        Me.txtNeedByDate.Size = New System.Drawing.Size(126, 19)
        Me.txtNeedByDate.TabIndex = 253
        Me.txtNeedByDate.Tag = Nothing
        Me.txtNeedByDate.TrimEnd = False
        Me.txtNeedByDate.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtNeedByDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtNeedByDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(393, 174)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(62, 22)
        Me.cmdCancel.TabIndex = 250
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmbPurpose
        '
        Me.cmbPurpose.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbPurpose.Caption = ""
        Me.cmbPurpose.CaptionHeight = 17
        Me.cmbPurpose.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbPurpose.ColumnCaptionHeight = 17
        Me.cmbPurpose.ColumnFooterHeight = 17
        Me.cmbPurpose.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbPurpose.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbPurpose.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbPurpose.Images.Add(CType(resources.GetObject("cmbPurpose.Images"), System.Drawing.Image))
        Me.cmbPurpose.ItemHeight = 15
        Me.cmbPurpose.Location = New System.Drawing.Point(94, 93)
        Me.cmbPurpose.MatchEntryTimeout = CType(2000, Long)
        Me.cmbPurpose.MaxDropDownItems = CType(5, Short)
        Me.cmbPurpose.MaxLength = 32767
        Me.cmbPurpose.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbPurpose.Name = "cmbPurpose"
        Me.cmbPurpose.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbPurpose.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbPurpose.Size = New System.Drawing.Size(214, 21)
        Me.cmbPurpose.TabIndex = 246
        Me.cmbPurpose.PropBag = resources.GetString("cmbPurpose.PropBag")
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 97)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 13)
        Me.Label6.TabIndex = 247
        Me.Label6.Text = "Purpose"
        '
        'cmbDeliveryLocation
        '
        Me.cmbDeliveryLocation.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbDeliveryLocation.Caption = ""
        Me.cmbDeliveryLocation.CaptionHeight = 17
        Me.cmbDeliveryLocation.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbDeliveryLocation.ColumnCaptionHeight = 17
        Me.cmbDeliveryLocation.ColumnFooterHeight = 17
        Me.cmbDeliveryLocation.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbDeliveryLocation.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbDeliveryLocation.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbDeliveryLocation.Images.Add(CType(resources.GetObject("cmbDeliveryLocation.Images"), System.Drawing.Image))
        Me.cmbDeliveryLocation.ItemHeight = 15
        Me.cmbDeliveryLocation.Location = New System.Drawing.Point(94, 120)
        Me.cmbDeliveryLocation.MatchEntryTimeout = CType(2000, Long)
        Me.cmbDeliveryLocation.MaxDropDownItems = CType(5, Short)
        Me.cmbDeliveryLocation.MaxLength = 32767
        Me.cmbDeliveryLocation.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbDeliveryLocation.Name = "cmbDeliveryLocation"
        Me.cmbDeliveryLocation.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbDeliveryLocation.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbDeliveryLocation.Size = New System.Drawing.Size(214, 21)
        Me.cmbDeliveryLocation.TabIndex = 242
        Me.cmbDeliveryLocation.PropBag = resources.GetString("cmbDeliveryLocation.PropBag")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 124)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 13)
        Me.Label3.TabIndex = 243
        Me.Label3.Text = "Warehouse"
        '
        'txtCancelUser
        '
        Me.txtCancelUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtCancelUser.Location = New System.Drawing.Point(222, 175)
        Me.txtCancelUser.Name = "txtCancelUser"
        Me.txtCancelUser.ReadOnly = True
        Me.txtCancelUser.Size = New System.Drawing.Size(169, 20)
        Me.txtCancelUser.TabIndex = 238
        '
        'txtCancelDate
        '
        Me.txtCancelDate.AllowSpinLoop = False
        Me.txtCancelDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtCancelDate.Calendar.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtCancelDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtCancelDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtCancelDate.Culture = 1056
        Me.txtCancelDate.CustomFormat = "dd/MM/yyyy"
        Me.txtCancelDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtCancelDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtCancelDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCancelDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtCancelDate.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtCancelDate.Location = New System.Drawing.Point(94, 176)
        Me.txtCancelDate.Name = "txtCancelDate"
        Me.txtCancelDate.ReadOnly = True
        Me.txtCancelDate.Size = New System.Drawing.Size(126, 19)
        Me.txtCancelDate.TabIndex = 237
        Me.txtCancelDate.Tag = Nothing
        Me.txtCancelDate.TrimEnd = False
        Me.txtCancelDate.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtCancelDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtCancelDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(461, 178)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(49, 13)
        Me.Label8.TabIndex = 234
        Me.Label8.Text = "Remarks"
        '
        'txtCancelRemarks
        '
        Me.txtCancelRemarks.Location = New System.Drawing.Point(516, 175)
        Me.txtCancelRemarks.MaxLength = 100
        Me.txtCancelRemarks.Name = "txtCancelRemarks"
        Me.txtCancelRemarks.Size = New System.Drawing.Size(236, 20)
        Me.txtCancelRemarks.TabIndex = 14
        '
        'chkCancel
        '
        Me.chkCancel.AutoSize = True
        Me.chkCancel.Location = New System.Drawing.Point(7, 177)
        Me.chkCancel.Name = "chkCancel"
        Me.chkCancel.Size = New System.Drawing.Size(59, 17)
        Me.chkCancel.TabIndex = 232
        Me.chkCancel.Text = "Cancel"
        Me.chkCancel.UseVisualStyleBackColor = True
        '
        'cmbDepartment
        '
        Me.cmbDepartment.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbDepartment.Caption = ""
        Me.cmbDepartment.CaptionHeight = 17
        Me.cmbDepartment.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbDepartment.ColumnCaptionHeight = 17
        Me.cmbDepartment.ColumnFooterHeight = 17
        Me.cmbDepartment.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbDepartment.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbDepartment.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbDepartment.Images.Add(CType(resources.GetObject("cmbDepartment.Images"), System.Drawing.Image))
        Me.cmbDepartment.ItemHeight = 15
        Me.cmbDepartment.Location = New System.Drawing.Point(94, 66)
        Me.cmbDepartment.MatchEntryTimeout = CType(2000, Long)
        Me.cmbDepartment.MaxDropDownItems = CType(5, Short)
        Me.cmbDepartment.MaxLength = 32767
        Me.cmbDepartment.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbDepartment.Name = "cmbDepartment"
        Me.cmbDepartment.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbDepartment.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbDepartment.Size = New System.Drawing.Size(214, 21)
        Me.cmbDepartment.TabIndex = 13
        Me.cmbDepartment.PropBag = resources.GetString("cmbDepartment.PropBag")
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 70)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 13)
        Me.Label7.TabIndex = 222
        Me.Label7.Text = "Department"
        '
        'txtDescription
        '
        Me.txtDescription.Location = New System.Drawing.Point(94, 147)
        Me.txtDescription.MaxLength = 300
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(423, 20)
        Me.txtDescription.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 151)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 199
        Me.Label5.Text = "Description"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(317, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 193
        Me.Label2.Text = "Req Date"
        '
        'txtReqDate
        '
        Me.txtReqDate.AllowSpinLoop = False
        Me.txtReqDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtReqDate.Calendar.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtReqDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtReqDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtReqDate.Culture = 1056
        Me.txtReqDate.CustomFormat = "dd/MM/yyyy"
        Me.txtReqDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtReqDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtReqDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReqDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtReqDate.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtReqDate.Location = New System.Drawing.Point(394, 41)
        Me.txtReqDate.Name = "txtReqDate"
        Me.txtReqDate.Size = New System.Drawing.Size(126, 19)
        Me.txtReqDate.TabIndex = 1
        Me.txtReqDate.Tag = Nothing
        Me.txtReqDate.TrimEnd = False
        Me.txtReqDate.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtReqDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtReqDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'txtReqNo
        '
        Me.txtReqNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtReqNo.Location = New System.Drawing.Point(94, 40)
        Me.txtReqNo.Name = "txtReqNo"
        Me.txtReqNo.Size = New System.Drawing.Size(150, 20)
        Me.txtReqNo.TabIndex = 178
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 176
        Me.Label1.Text = "Req #"
        '
        'cmdAdd
        '
        Me.cmdAdd.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdAdd.Image = Global.General_Ledger.My.Resources.Resources.folder_add
        Me.cmdAdd.Location = New System.Drawing.Point(459, 2)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(51, 56)
        Me.cmdAdd.TabIndex = 0
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdAdd.UseVisualStyleBackColor = True
        '
        'cmdExit
        '
        Me.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdExit.Image = Global.General_Ledger.My.Resources.Resources.folder_out
        Me.cmdExit.Location = New System.Drawing.Point(715, 2)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(51, 56)
        Me.cmdExit.TabIndex = 176
        Me.cmdExit.Text = "E&xit"
        Me.cmdExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdExit.UseVisualStyleBackColor = True
        '
        'cmdUndo
        '
        Me.cmdUndo.Image = Global.General_Ledger.My.Resources.Resources.folder_refresh
        Me.cmdUndo.Location = New System.Drawing.Point(663, 2)
        Me.cmdUndo.Name = "cmdUndo"
        Me.cmdUndo.Size = New System.Drawing.Size(51, 56)
        Me.cmdUndo.TabIndex = 175
        Me.cmdUndo.Text = "&Undo"
        Me.cmdUndo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdUndo.UseVisualStyleBackColor = True
        '
        'cmdSearch
        '
        Me.cmdSearch.Image = Global.General_Ledger.My.Resources.Resources.folder_view
        Me.cmdSearch.Location = New System.Drawing.Point(407, 2)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.Size = New System.Drawing.Size(51, 56)
        Me.cmdSearch.TabIndex = 171
        Me.cmdSearch.Text = "Searc&h"
        Me.cmdSearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdSearch.UseVisualStyleBackColor = True
        '
        'cmdEdit
        '
        Me.cmdEdit.Image = Global.General_Ledger.My.Resources.Resources.folder_edit
        Me.cmdEdit.Location = New System.Drawing.Point(510, 2)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(51, 56)
        Me.cmdEdit.TabIndex = 173
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdEdit.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Image = Global.General_Ledger.My.Resources.Resources.folder_new
        Me.cmdSave.Location = New System.Drawing.Point(561, 2)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(51, 56)
        Me.cmdSave.TabIndex = 172
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cmdDelete
        '
        Me.cmdDelete.Image = Global.General_Ledger.My.Resources.Resources.folder_delete
        Me.cmdDelete.Location = New System.Drawing.Point(612, 2)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(51, 56)
        Me.cmdDelete.TabIndex = 174
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdDelete.UseVisualStyleBackColor = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1})
        Me.ToolStrip1.Location = New System.Drawing.Point(9, -1)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Padding = New System.Windows.Forms.Padding(0, 0, 2, 0)
        Me.ToolStrip1.Size = New System.Drawing.Size(762, 64)
        Me.ToolStrip1.TabIndex = 169
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Trebuchet MS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel1.ForeColor = System.Drawing.SystemColors.Desktop
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(247, 61)
        Me.ToolStripLabel1.Text = "Pur. Requisition Product"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(11, 304)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(757, 273)
        Me.TabControl1.TabIndex = 178
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.tdbSupplier)
        Me.TabPage1.Controls.Add(Me.cmdPickProduct)
        Me.TabPage1.Controls.Add(Me.tdbProduct)
        Me.TabPage1.Controls.Add(Me.tdbGridOrderDetail)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(749, 247)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Reqisition Details"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'tdbSupplier
        '
        Me.tdbSupplier.AllowColMove = True
        Me.tdbSupplier.AllowColSelect = True
        Me.tdbSupplier.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbSupplier.AlternatingRows = False
        Me.tdbSupplier.CaptionStyle = Style101
        Me.tdbSupplier.ColumnCaptionHeight = 17
        Me.tdbSupplier.ColumnFooterHeight = 17
        Me.tdbSupplier.ColumnSelectorStyle = Style102
        Me.tdbSupplier.EvenRowStyle = Style103
        Me.tdbSupplier.FetchRowStyles = False
        Me.tdbSupplier.FooterStyle = Style104
        Me.tdbSupplier.HeadingStyle = Style105
        Me.tdbSupplier.HighLightRowStyle = Style106
        Me.tdbSupplier.Images.Add(CType(resources.GetObject("tdbSupplier.Images"), System.Drawing.Image))
        Me.tdbSupplier.Location = New System.Drawing.Point(340, 33)
        Me.tdbSupplier.Name = "tdbSupplier"
        Me.tdbSupplier.OddRowStyle = Style107
        Me.tdbSupplier.RecordSelectorStyle = Style108
        Me.tdbSupplier.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbSupplier.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbSupplier.RowSelectorStyle = Style109
        Me.tdbSupplier.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbSupplier.ScrollTips = False
        Me.tdbSupplier.Size = New System.Drawing.Size(388, 114)
        Me.tdbSupplier.Style = Style110
        Me.tdbSupplier.TabIndex = 263
        Me.tdbSupplier.TabStop = False
        Me.tdbSupplier.Text = "C1TrueDBDropdown1"
        Me.tdbSupplier.UseCompatibleTextRendering = False
        Me.tdbSupplier.ValueTranslate = True
        Me.tdbSupplier.Visible = False
        Me.tdbSupplier.PropBag = resources.GetString("tdbSupplier.PropBag")
        '
        'cmdPickProduct
        '
        Me.cmdPickProduct.Location = New System.Drawing.Point(7, 220)
        Me.cmdPickProduct.Name = "cmdPickProduct"
        Me.cmdPickProduct.Size = New System.Drawing.Size(110, 23)
        Me.cmdPickProduct.TabIndex = 33
        Me.cmdPickProduct.Text = "Pick Product"
        Me.cmdPickProduct.UseVisualStyleBackColor = True
        '
        'tdbProduct
        '
        Me.tdbProduct.AllowColMove = True
        Me.tdbProduct.AllowColSelect = True
        Me.tdbProduct.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbProduct.AlternatingRows = False
        Me.tdbProduct.CaptionStyle = Style111
        Me.tdbProduct.ColumnCaptionHeight = 17
        Me.tdbProduct.ColumnFooterHeight = 17
        Me.tdbProduct.ColumnSelectorStyle = Style112
        Me.tdbProduct.EvenRowStyle = Style113
        Me.tdbProduct.FetchRowStyles = False
        Me.tdbProduct.FooterStyle = Style114
        Me.tdbProduct.HeadingStyle = Style115
        Me.tdbProduct.HighLightRowStyle = Style116
        Me.tdbProduct.Images.Add(CType(resources.GetObject("tdbProduct.Images"), System.Drawing.Image))
        Me.tdbProduct.Location = New System.Drawing.Point(123, 30)
        Me.tdbProduct.Name = "tdbProduct"
        Me.tdbProduct.OddRowStyle = Style117
        Me.tdbProduct.RecordSelectorStyle = Style118
        Me.tdbProduct.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbProduct.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbProduct.RowSelectorStyle = Style119
        Me.tdbProduct.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbProduct.ScrollTips = False
        Me.tdbProduct.Size = New System.Drawing.Size(388, 112)
        Me.tdbProduct.Style = Style120
        Me.tdbProduct.TabIndex = 186
        Me.tdbProduct.TabStop = False
        Me.tdbProduct.Text = "C1TrueDBDropdown1"
        Me.tdbProduct.UseCompatibleTextRendering = False
        Me.tdbProduct.ValueTranslate = True
        Me.tdbProduct.Visible = False
        Me.tdbProduct.PropBag = resources.GetString("tdbProduct.PropBag")
        '
        'tdbGridOrderDetail
        '
        Me.tdbGridOrderDetail.AllowDelete = True
        Me.tdbGridOrderDetail.ColumnFooters = True
        Me.tdbGridOrderDetail.EmptyRows = True
        Me.tdbGridOrderDetail.GroupByCaption = "Drag a column header here to group by that column"
        Me.tdbGridOrderDetail.Images.Add(CType(resources.GetObject("tdbGridOrderDetail.Images"), System.Drawing.Image))
        Me.tdbGridOrderDetail.Images.Add(CType(resources.GetObject("tdbGridOrderDetail.Images1"), System.Drawing.Image))
        Me.tdbGridOrderDetail.Images.Add(CType(resources.GetObject("tdbGridOrderDetail.Images2"), System.Drawing.Image))
        Me.tdbGridOrderDetail.Location = New System.Drawing.Point(9, 6)
        Me.tdbGridOrderDetail.Name = "tdbGridOrderDetail"
        Me.tdbGridOrderDetail.PreviewInfo.Location = New System.Drawing.Point(0, 0)
        Me.tdbGridOrderDetail.PreviewInfo.Size = New System.Drawing.Size(0, 0)
        Me.tdbGridOrderDetail.PreviewInfo.ZoomFactor = 75.0R
        Me.tdbGridOrderDetail.PrintInfo.MeasurementDevice = C1.Win.C1TrueDBGrid.PrintInfo.MeasurementDeviceEnum.Screen
        Me.tdbGridOrderDetail.PrintInfo.MeasurementPrinterName = Nothing
        Me.tdbGridOrderDetail.PrintInfo.PageSettings = CType(resources.GetObject("tdbGridOrderDetail.PrintInfo.PageSettings"), System.Drawing.Printing.PageSettings)
        Me.tdbGridOrderDetail.RecordSelectors = False
        Me.tdbGridOrderDetail.Size = New System.Drawing.Size(737, 212)
        Me.tdbGridOrderDetail.TabIndex = 179
        Me.tdbGridOrderDetail.Text = "C1TrueDBGrid1"
        Me.tdbGridOrderDetail.UseCompatibleTextRendering = False
        Me.tdbGridOrderDetail.VisualStyle = C1.Win.C1TrueDBGrid.VisualStyle.Office2007Silver
        Me.tdbGridOrderDetail.WrapCellPointer = True
        Me.tdbGridOrderDetail.PropBag = resources.GetString("tdbGridOrderDetail.PropBag")
        '
        'cmdPrint
        '
        Me.cmdPrint.Image = Global.General_Ledger.My.Resources.Resources.folder_document
        Me.cmdPrint.Location = New System.Drawing.Point(355, 2)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.Size = New System.Drawing.Size(51, 56)
        Me.cmdPrint.TabIndex = 180
        Me.cmdPrint.Text = "&Print"
        Me.cmdPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdPrint.UseVisualStyleBackColor = True
        '
        'lblFlag
        '
        Me.lblFlag.Font = New System.Drawing.Font("Calibri", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFlag.ForeColor = System.Drawing.Color.Red
        Me.lblFlag.Location = New System.Drawing.Point(12, 62)
        Me.lblFlag.Name = "lblFlag"
        Me.lblFlag.Size = New System.Drawing.Size(758, 33)
        Me.lblFlag.TabIndex = 181
        Me.lblFlag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblFlag.Visible = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(3, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(40, 13)
        Me.Label10.TabIndex = 222
        Me.Label10.Text = "Project"
        '
        'cmbProject
        '
        Me.cmbProject.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbProject.Caption = ""
        Me.cmbProject.CaptionHeight = 17
        Me.cmbProject.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbProject.ColumnCaptionHeight = 17
        Me.cmbProject.ColumnFooterHeight = 17
        Me.cmbProject.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbProject.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbProject.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbProject.Images.Add(CType(resources.GetObject("cmbProject.Images"), System.Drawing.Image))
        Me.cmbProject.ItemHeight = 15
        Me.cmbProject.Location = New System.Drawing.Point(93, 12)
        Me.cmbProject.MatchEntryTimeout = CType(2000, Long)
        Me.cmbProject.MaxDropDownItems = CType(5, Short)
        Me.cmbProject.MaxLength = 32767
        Me.cmbProject.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbProject.Name = "cmbProject"
        Me.cmbProject.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbProject.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbProject.Size = New System.Drawing.Size(427, 21)
        Me.cmbProject.TabIndex = 13
        Me.cmbProject.PropBag = resources.GetString("cmbProject.PropBag")
        '
        'frmPurRequisitionProduct
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(778, 580)
        Me.Controls.Add(Me.lblFlag)
        Me.Controls.Add(Me.cmdPrint)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmdAdd)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.cmdUndo)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.ToolStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.Name = "frmPurRequisitionProduct"
        Me.Text = "Purchase Requisition Product"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.txtNeedByDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbPurpose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbDeliveryLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCancelDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbDepartment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtReqDate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.tdbSupplier, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbProduct, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbGridOrderDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbProject, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtReqDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents txtReqNo As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents cmdExit As System.Windows.Forms.Button
    Friend WithEvents cmdUndo As System.Windows.Forms.Button
    Friend WithEvents cmdSearch As System.Windows.Forms.Button
    Friend WithEvents cmdEdit As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents tdbProduct As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents tdbGridOrderDetail As C1.Win.C1TrueDBGrid.C1TrueDBGrid
    Friend WithEvents cmdPrint As System.Windows.Forms.Button
    Friend WithEvents cmdPickProduct As System.Windows.Forms.Button
    Friend WithEvents cmbDepartment As C1.Win.C1List.C1Combo
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtCancelRemarks As System.Windows.Forms.TextBox
    Friend WithEvents chkCancel As System.Windows.Forms.CheckBox
    Friend WithEvents txtCancelUser As TextBox
    Friend WithEvents txtCancelDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents cmbDeliveryLocation As C1.Win.C1List.C1Combo
    Friend WithEvents Label3 As Label
    Friend WithEvents tdbSupplier As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents Label6 As Label
    Friend WithEvents cmdCancel As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents txtNeedByDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents cmbPurpose As C1.Win.C1List.C1Combo
    Friend WithEvents lblFlag As Label
    Friend WithEvents txtGeneratedBy As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents cmbProject As C1.Win.C1List.C1Combo
    Friend WithEvents Label10 As Label
End Class
