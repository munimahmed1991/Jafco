﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPurOrderProduct
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPurOrderProduct))
        Dim Style1 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style2 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style3 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style4 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style5 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style6 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style7 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style8 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style9 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style10 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style11 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style12 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style13 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style14 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style15 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style16 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style17 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style18 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style19 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Dim Style20 As C1.Win.C1TrueDBGrid.Style = New C1.Win.C1TrueDBGrid.Style()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cmdClosed = New System.Windows.Forms.Button()
        Me.txtCloseUser = New System.Windows.Forms.TextBox()
        Me.txtCloseDate = New C1.Win.C1Input.C1DateEdit()
        Me.chkFinalized = New System.Windows.Forms.CheckBox()
        Me.cmbPackingType = New C1.Win.C1List.C1Combo()
        Me.cmbProject = New C1.Win.C1List.C1Combo()
        Me.cmbPaymentTerms = New C1.Win.C1List.C1Combo()
        Me.txtGeneratedBy = New System.Windows.Forms.TextBox()
        Me.chkWithoutGST = New System.Windows.Forms.CheckBox()
        Me.txtBalancePayment = New C1.Win.C1Input.C1NumericEdit()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtNetAmount = New C1.Win.C1Input.C1NumericEdit()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtTransportationCharges = New C1.Win.C1Input.C1NumericEdit()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtSalesTax = New C1.Win.C1Input.C1NumericEdit()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtDiscount = New C1.Win.C1Input.C1NumericEdit()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtGrossAmount = New C1.Win.C1Input.C1NumericEdit()
        Me.txtAdvanceAmount = New C1.Win.C1Input.C1NumericEdit()
        Me.txtAdvancePer = New C1.Win.C1Input.C1NumericEdit()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.txtCancelUser = New System.Windows.Forms.TextBox()
        Me.txtCancelDate = New C1.Win.C1Input.C1DateEdit()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtCancelRemarks = New System.Windows.Forms.TextBox()
        Me.chkCancel = New System.Windows.Forms.CheckBox()
        Me.cmbLocalImport = New System.Windows.Forms.ComboBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.chkClosed = New System.Windows.Forms.CheckBox()
        Me.cmbDepartment = New C1.Win.C1List.C1Combo()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmbCurrency = New C1.Win.C1List.C1Combo()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtETA = New C1.Win.C1Input.C1DateEdit()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtETD = New C1.Win.C1Input.C1DateEdit()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtDeliveryTerms = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtPoDate = New C1.Win.C1Input.C1DateEdit()
        Me.cmdVendorList = New System.Windows.Forms.Button()
        Me.cmbSupplier = New C1.Win.C1List.C1Combo()
        Me.txtPoNo = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.cmdPickRequisition = New System.Windows.Forms.Button()
        Me.tdbColor = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown()
        Me.tdbProduct = New C1.Win.C1TrueDBGrid.C1TrueDBDropdown()
        Me.tdbGridOrderDetail = New C1.Win.C1TrueDBGrid.C1TrueDBGrid()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.txtSpecialInstructions = New System.Windows.Forms.RichTextBox()
        Me.lblFlag = New System.Windows.Forms.Label()
        Me.cmdPrint = New System.Windows.Forms.Button()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cmdUndo = New System.Windows.Forms.Button()
        Me.cmdSearch = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.txtCloseDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbPackingType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbPaymentTerms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtBalancePayment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNetAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTransportationCharges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSalesTax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDiscount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGrossAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAdvanceAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAdvancePer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCancelDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbDepartment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbCurrency, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtETA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtETD, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPoDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbSupplier, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.tdbColor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbProduct, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbGridOrderDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmdClosed)
        Me.GroupBox1.Controls.Add(Me.txtCloseUser)
        Me.GroupBox1.Controls.Add(Me.txtCloseDate)
        Me.GroupBox1.Controls.Add(Me.chkFinalized)
        Me.GroupBox1.Controls.Add(Me.cmbPackingType)
        Me.GroupBox1.Controls.Add(Me.cmbProject)
        Me.GroupBox1.Controls.Add(Me.cmbPaymentTerms)
        Me.GroupBox1.Controls.Add(Me.txtGeneratedBy)
        Me.GroupBox1.Controls.Add(Me.chkWithoutGST)
        Me.GroupBox1.Controls.Add(Me.txtBalancePayment)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.txtNetAmount)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.txtTransportationCharges)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.txtSalesTax)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.txtDiscount)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.txtGrossAmount)
        Me.GroupBox1.Controls.Add(Me.txtAdvanceAmount)
        Me.GroupBox1.Controls.Add(Me.txtAdvancePer)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.cmdCancel)
        Me.GroupBox1.Controls.Add(Me.txtCancelUser)
        Me.GroupBox1.Controls.Add(Me.txtCancelDate)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtCancelRemarks)
        Me.GroupBox1.Controls.Add(Me.chkCancel)
        Me.GroupBox1.Controls.Add(Me.cmbLocalImport)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.chkClosed)
        Me.GroupBox1.Controls.Add(Me.cmbDepartment)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.cmbCurrency)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtETA)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtETD)
        Me.GroupBox1.Controls.Add(Me.txtDescription)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtDeliveryTerms)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtPoDate)
        Me.GroupBox1.Controls.Add(Me.cmdVendorList)
        Me.GroupBox1.Controls.Add(Me.cmbSupplier)
        Me.GroupBox1.Controls.Add(Me.txtPoNo)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 90)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(761, 299)
        Me.GroupBox1.TabIndex = 177
        Me.GroupBox1.TabStop = False
        '
        'cmdClosed
        '
        Me.cmdClosed.Location = New System.Drawing.Point(678, 37)
        Me.cmdClosed.Name = "cmdClosed"
        Me.cmdClosed.Size = New System.Drawing.Size(62, 22)
        Me.cmdClosed.TabIndex = 292
        Me.cmdClosed.Text = "Closed"
        Me.cmdClosed.UseVisualStyleBackColor = True
        '
        'txtCloseUser
        '
        Me.txtCloseUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtCloseUser.Location = New System.Drawing.Point(563, 38)
        Me.txtCloseUser.Name = "txtCloseUser"
        Me.txtCloseUser.ReadOnly = True
        Me.txtCloseUser.Size = New System.Drawing.Size(115, 20)
        Me.txtCloseUser.TabIndex = 291
        '
        'txtCloseDate
        '
        Me.txtCloseDate.AllowSpinLoop = False
        Me.txtCloseDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtCloseDate.Calendar.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtCloseDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtCloseDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtCloseDate.Culture = 1056
        Me.txtCloseDate.CustomFormat = "dd/MM/yyyy"
        Me.txtCloseDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtCloseDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtCloseDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCloseDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtCloseDate.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtCloseDate.Location = New System.Drawing.Point(431, 39)
        Me.txtCloseDate.Name = "txtCloseDate"
        Me.txtCloseDate.ReadOnly = True
        Me.txtCloseDate.Size = New System.Drawing.Size(126, 19)
        Me.txtCloseDate.TabIndex = 290
        Me.txtCloseDate.Tag = Nothing
        Me.txtCloseDate.TrimEnd = False
        Me.txtCloseDate.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtCloseDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtCloseDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'chkFinalized
        '
        Me.chkFinalized.AutoSize = True
        Me.chkFinalized.Location = New System.Drawing.Point(563, 65)
        Me.chkFinalized.Name = "chkFinalized"
        Me.chkFinalized.Size = New System.Drawing.Size(62, 17)
        Me.chkFinalized.TabIndex = 289
        Me.chkFinalized.Text = "Finalied"
        Me.chkFinalized.UseVisualStyleBackColor = True
        Me.chkFinalized.Visible = False
        '
        'cmbPackingType
        '
        Me.cmbPackingType.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbPackingType.Caption = ""
        Me.cmbPackingType.CaptionHeight = 17
        Me.cmbPackingType.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbPackingType.ColumnCaptionHeight = 17
        Me.cmbPackingType.ColumnFooterHeight = 17
        Me.cmbPackingType.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbPackingType.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbPackingType.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbPackingType.Images.Add(CType(resources.GetObject("cmbPackingType.Images"), System.Drawing.Image))
        Me.cmbPackingType.ItemHeight = 15
        Me.cmbPackingType.Location = New System.Drawing.Point(98, 144)
        Me.cmbPackingType.MatchEntryTimeout = CType(2000, Long)
        Me.cmbPackingType.MaxDropDownItems = CType(5, Short)
        Me.cmbPackingType.MaxLength = 32767
        Me.cmbPackingType.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbPackingType.Name = "cmbPackingType"
        Me.cmbPackingType.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbPackingType.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbPackingType.Size = New System.Drawing.Size(226, 21)
        Me.cmbPackingType.TabIndex = 288
        Me.cmbPackingType.PropBag = resources.GetString("cmbPackingType.PropBag")
        '
        'cmbProject
        '
        Me.cmbProject.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbProject.Caption = ""
        Me.cmbProject.CaptionHeight = 17
        Me.cmbProject.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbProject.ColumnCaptionHeight = 17
        Me.cmbProject.ColumnFooterHeight = 17
        Me.cmbProject.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbProject.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbProject.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbProject.Images.Add(CType(resources.GetObject("cmbProject.Images"), System.Drawing.Image))
        Me.cmbProject.ItemHeight = 15
        Me.cmbProject.Location = New System.Drawing.Point(98, 12)
        Me.cmbProject.MatchEntryTimeout = CType(2000, Long)
        Me.cmbProject.MaxDropDownItems = CType(5, Short)
        Me.cmbProject.MaxLength = 32767
        Me.cmbProject.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbProject.Name = "cmbProject"
        Me.cmbProject.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbProject.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbProject.Size = New System.Drawing.Size(459, 21)
        Me.cmbProject.TabIndex = 287
        Me.cmbProject.PropBag = resources.GetString("cmbProject.PropBag")
        '
        'cmbPaymentTerms
        '
        Me.cmbPaymentTerms.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbPaymentTerms.Caption = ""
        Me.cmbPaymentTerms.CaptionHeight = 17
        Me.cmbPaymentTerms.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbPaymentTerms.ColumnCaptionHeight = 17
        Me.cmbPaymentTerms.ColumnFooterHeight = 17
        Me.cmbPaymentTerms.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbPaymentTerms.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbPaymentTerms.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbPaymentTerms.Images.Add(CType(resources.GetObject("cmbPaymentTerms.Images"), System.Drawing.Image))
        Me.cmbPaymentTerms.ItemHeight = 15
        Me.cmbPaymentTerms.Location = New System.Drawing.Point(98, 91)
        Me.cmbPaymentTerms.MatchEntryTimeout = CType(2000, Long)
        Me.cmbPaymentTerms.MaxDropDownItems = CType(5, Short)
        Me.cmbPaymentTerms.MaxLength = 32767
        Me.cmbPaymentTerms.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbPaymentTerms.Name = "cmbPaymentTerms"
        Me.cmbPaymentTerms.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbPaymentTerms.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbPaymentTerms.Size = New System.Drawing.Size(226, 21)
        Me.cmbPaymentTerms.TabIndex = 287
        Me.cmbPaymentTerms.PropBag = resources.GetString("cmbPaymentTerms.PropBag")
        '
        'txtGeneratedBy
        '
        Me.txtGeneratedBy.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtGeneratedBy.Location = New System.Drawing.Point(634, 63)
        Me.txtGeneratedBy.Name = "txtGeneratedBy"
        Me.txtGeneratedBy.ReadOnly = True
        Me.txtGeneratedBy.Size = New System.Drawing.Size(118, 20)
        Me.txtGeneratedBy.TabIndex = 285
        Me.txtGeneratedBy.Visible = False
        '
        'chkWithoutGST
        '
        Me.chkWithoutGST.AutoSize = True
        Me.chkWithoutGST.Location = New System.Drawing.Point(254, 40)
        Me.chkWithoutGST.Name = "chkWithoutGST"
        Me.chkWithoutGST.Size = New System.Drawing.Size(88, 17)
        Me.chkWithoutGST.TabIndex = 284
        Me.chkWithoutGST.Text = "Without GST"
        Me.chkWithoutGST.UseVisualStyleBackColor = True
        '
        'txtBalancePayment
        '
        Me.txtBalancePayment.AutoSize = False
        Me.txtBalancePayment.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtBalancePayment.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.txtBalancePayment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBalancePayment.DisplayFormat.CustomFormat = "###,###,##0.00"
        Me.txtBalancePayment.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtBalancePayment.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtBalancePayment.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtBalancePayment.Location = New System.Drawing.Point(656, 275)
        Me.txtBalancePayment.Name = "txtBalancePayment"
        Me.txtBalancePayment.ReadOnly = True
        Me.txtBalancePayment.Size = New System.Drawing.Size(87, 20)
        Me.txtBalancePayment.TabIndex = 283
        Me.txtBalancePayment.Tag = Nothing
        Me.txtBalancePayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtBalancePayment.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtBalancePayment.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtBalancePayment.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtBalancePayment.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(567, 278)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(90, 13)
        Me.Label19.TabIndex = 282
        Me.Label19.Text = "Balance Payment"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(567, 252)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(50, 13)
        Me.Label18.TabIndex = 281
        Me.Label18.Text = "Advance"
        '
        'txtNetAmount
        '
        Me.txtNetAmount.AutoSize = False
        Me.txtNetAmount.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtNetAmount.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.txtNetAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNetAmount.DisplayFormat.CustomFormat = "###,###,##0.00"
        Me.txtNetAmount.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtNetAmount.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtNetAmount.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtNetAmount.Location = New System.Drawing.Point(656, 226)
        Me.txtNetAmount.Name = "txtNetAmount"
        Me.txtNetAmount.ReadOnly = True
        Me.txtNetAmount.Size = New System.Drawing.Size(87, 20)
        Me.txtNetAmount.TabIndex = 280
        Me.txtNetAmount.Tag = Nothing
        Me.txtNetAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtNetAmount.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtNetAmount.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtNetAmount.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtNetAmount.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(567, 226)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(63, 13)
        Me.Label17.TabIndex = 279
        Me.Label17.Text = "Net Amount"
        '
        'txtTransportationCharges
        '
        Me.txtTransportationCharges.AutoSize = False
        Me.txtTransportationCharges.BackColor = System.Drawing.Color.White
        Me.txtTransportationCharges.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.txtTransportationCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTransportationCharges.DisplayFormat.CustomFormat = "###,###,##0.00"
        Me.txtTransportationCharges.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtTransportationCharges.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtTransportationCharges.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtTransportationCharges.Location = New System.Drawing.Point(656, 199)
        Me.txtTransportationCharges.Name = "txtTransportationCharges"
        Me.txtTransportationCharges.Size = New System.Drawing.Size(87, 18)
        Me.txtTransportationCharges.TabIndex = 278
        Me.txtTransportationCharges.Tag = Nothing
        Me.txtTransportationCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtTransportationCharges.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtTransportationCharges.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtTransportationCharges.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtTransportationCharges.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(567, 200)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(80, 13)
        Me.Label16.TabIndex = 277
        Me.Label16.Text = "Add : Transport"
        '
        'txtSalesTax
        '
        Me.txtSalesTax.AutoSize = False
        Me.txtSalesTax.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtSalesTax.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.txtSalesTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSalesTax.DisplayFormat.CustomFormat = "###,###,##0.00"
        Me.txtSalesTax.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtSalesTax.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtSalesTax.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtSalesTax.Location = New System.Drawing.Point(656, 169)
        Me.txtSalesTax.Name = "txtSalesTax"
        Me.txtSalesTax.ReadOnly = True
        Me.txtSalesTax.Size = New System.Drawing.Size(87, 20)
        Me.txtSalesTax.TabIndex = 276
        Me.txtSalesTax.Tag = Nothing
        Me.txtSalesTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtSalesTax.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtSalesTax.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtSalesTax.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtSalesTax.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(567, 173)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(76, 13)
        Me.Label14.TabIndex = 275
        Me.Label14.Text = "Add Sales Tax"
        '
        'txtDiscount
        '
        Me.txtDiscount.AutoSize = False
        Me.txtDiscount.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtDiscount.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.txtDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDiscount.DisplayFormat.CustomFormat = "###,###,##0.00"
        Me.txtDiscount.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtDiscount.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtDiscount.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtDiscount.Location = New System.Drawing.Point(656, 144)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.ReadOnly = True
        Me.txtDiscount.Size = New System.Drawing.Size(87, 20)
        Me.txtDiscount.TabIndex = 274
        Me.txtDiscount.Tag = Nothing
        Me.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtDiscount.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtDiscount.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtDiscount.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtDiscount.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(567, 148)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(80, 13)
        Me.Label12.TabIndex = 273
        Me.Label12.Text = "Less : Discount"
        '
        'txtGrossAmount
        '
        Me.txtGrossAmount.AutoSize = False
        Me.txtGrossAmount.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtGrossAmount.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.txtGrossAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtGrossAmount.DisplayFormat.CustomFormat = "###,###,##0.00"
        Me.txtGrossAmount.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtGrossAmount.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtGrossAmount.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtGrossAmount.Location = New System.Drawing.Point(656, 118)
        Me.txtGrossAmount.Name = "txtGrossAmount"
        Me.txtGrossAmount.ReadOnly = True
        Me.txtGrossAmount.Size = New System.Drawing.Size(87, 20)
        Me.txtGrossAmount.TabIndex = 272
        Me.txtGrossAmount.Tag = Nothing
        Me.txtGrossAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtGrossAmount.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtGrossAmount.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtGrossAmount.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtGrossAmount.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'txtAdvanceAmount
        '
        Me.txtAdvanceAmount.AutoSize = False
        Me.txtAdvanceAmount.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtAdvanceAmount.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.txtAdvanceAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAdvanceAmount.DisplayFormat.CustomFormat = "###,###,##0.00"
        Me.txtAdvanceAmount.DisplayFormat.FormatType = C1.Win.C1Input.FormatTypeEnum.CustomFormat
        Me.txtAdvanceAmount.DisplayFormat.Inherit = CType(((C1.Win.C1Input.FormatInfoInheritFlags.NullText Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtAdvanceAmount.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtAdvanceAmount.Location = New System.Drawing.Point(656, 249)
        Me.txtAdvanceAmount.Name = "txtAdvanceAmount"
        Me.txtAdvanceAmount.ReadOnly = True
        Me.txtAdvanceAmount.Size = New System.Drawing.Size(87, 20)
        Me.txtAdvanceAmount.TabIndex = 271
        Me.txtAdvanceAmount.Tag = Nothing
        Me.txtAdvanceAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtAdvanceAmount.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtAdvanceAmount.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtAdvanceAmount.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtAdvanceAmount.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'txtAdvancePer
        '
        Me.txtAdvancePer.AutoSize = False
        Me.txtAdvancePer.BackColor = System.Drawing.Color.White
        Me.txtAdvancePer.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.txtAdvancePer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAdvancePer.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.CustomFormat) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtAdvancePer.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtAdvancePer.Location = New System.Drawing.Point(618, 249)
        Me.txtAdvancePer.Name = "txtAdvancePer"
        Me.txtAdvancePer.Size = New System.Drawing.Size(36, 20)
        Me.txtAdvancePer.TabIndex = 270
        Me.txtAdvancePer.Tag = Nothing
        Me.txtAdvancePer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtAdvancePer.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.txtAdvancePer.VerticalAlign = C1.Win.C1Input.VerticalAlignEnum.Middle
        Me.txtAdvancePer.VisibleButtons = C1.Win.C1Input.DropDownControlButtonFlags.None
        Me.txtAdvancePer.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(567, 122)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(73, 13)
        Me.Label11.TabIndex = 269
        Me.Label11.Text = "Gross Amount"
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(379, 197)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(62, 22)
        Me.cmdCancel.TabIndex = 266
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'txtCancelUser
        '
        Me.txtCancelUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtCancelUser.Location = New System.Drawing.Point(226, 198)
        Me.txtCancelUser.Name = "txtCancelUser"
        Me.txtCancelUser.ReadOnly = True
        Me.txtCancelUser.Size = New System.Drawing.Size(152, 20)
        Me.txtCancelUser.TabIndex = 260
        '
        'txtCancelDate
        '
        Me.txtCancelDate.AllowSpinLoop = False
        Me.txtCancelDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtCancelDate.Calendar.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtCancelDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtCancelDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtCancelDate.Culture = 1056
        Me.txtCancelDate.CustomFormat = "dd/MM/yyyy"
        Me.txtCancelDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtCancelDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtCancelDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCancelDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtCancelDate.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtCancelDate.Location = New System.Drawing.Point(98, 199)
        Me.txtCancelDate.Name = "txtCancelDate"
        Me.txtCancelDate.ReadOnly = True
        Me.txtCancelDate.Size = New System.Drawing.Size(126, 19)
        Me.txtCancelDate.TabIndex = 259
        Me.txtCancelDate.Tag = Nothing
        Me.txtCancelDate.TrimEnd = False
        Me.txtCancelDate.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtCancelDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtCancelDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(5, 230)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(85, 13)
        Me.Label8.TabIndex = 257
        Me.Label8.Text = "Cancel Remarks"
        '
        'txtCancelRemarks
        '
        Me.txtCancelRemarks.Location = New System.Drawing.Point(100, 226)
        Me.txtCancelRemarks.MaxLength = 100
        Me.txtCancelRemarks.Name = "txtCancelRemarks"
        Me.txtCancelRemarks.Size = New System.Drawing.Size(277, 20)
        Me.txtCancelRemarks.TabIndex = 253
        '
        'chkCancel
        '
        Me.chkCancel.AutoSize = True
        Me.chkCancel.Location = New System.Drawing.Point(5, 200)
        Me.chkCancel.Name = "chkCancel"
        Me.chkCancel.Size = New System.Drawing.Size(59, 17)
        Me.chkCancel.TabIndex = 256
        Me.chkCancel.Text = "Cancel"
        Me.chkCancel.UseVisualStyleBackColor = True
        '
        'cmbLocalImport
        '
        Me.cmbLocalImport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbLocalImport.FormattingEnabled = True
        Me.cmbLocalImport.Items.AddRange(New Object() {"Local", "Import"})
        Me.cmbLocalImport.Location = New System.Drawing.Point(431, 118)
        Me.cmbLocalImport.Name = "cmbLocalImport"
        Me.cmbLocalImport.Size = New System.Drawing.Size(101, 21)
        Me.cmbLocalImport.TabIndex = 9
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(349, 122)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(73, 13)
        Me.Label30.TabIndex = 249
        Me.Label30.Text = "Local / Import"
        '
        'chkClosed
        '
        Me.chkClosed.AutoSize = True
        Me.chkClosed.Location = New System.Drawing.Point(352, 40)
        Me.chkClosed.Name = "chkClosed"
        Me.chkClosed.Size = New System.Drawing.Size(58, 17)
        Me.chkClosed.TabIndex = 236
        Me.chkClosed.Text = "Closed"
        Me.chkClosed.UseVisualStyleBackColor = True
        '
        'cmbDepartment
        '
        Me.cmbDepartment.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbDepartment.Caption = ""
        Me.cmbDepartment.CaptionHeight = 17
        Me.cmbDepartment.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbDepartment.ColumnCaptionHeight = 17
        Me.cmbDepartment.ColumnFooterHeight = 17
        Me.cmbDepartment.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbDepartment.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbDepartment.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbDepartment.Images.Add(CType(resources.GetObject("cmbDepartment.Images"), System.Drawing.Image))
        Me.cmbDepartment.ItemHeight = 15
        Me.cmbDepartment.Location = New System.Drawing.Point(98, 169)
        Me.cmbDepartment.MatchEntryTimeout = CType(2000, Long)
        Me.cmbDepartment.MaxDropDownItems = CType(5, Short)
        Me.cmbDepartment.MaxLength = 32767
        Me.cmbDepartment.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbDepartment.Name = "cmbDepartment"
        Me.cmbDepartment.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbDepartment.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbDepartment.Size = New System.Drawing.Size(226, 21)
        Me.cmbDepartment.TabIndex = 13
        Me.cmbDepartment.PropBag = resources.GetString("cmbDepartment.PropBag")
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(5, 173)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 13)
        Me.Label7.TabIndex = 222
        Me.Label7.Text = "Department"
        '
        'cmbCurrency
        '
        Me.cmbCurrency.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbCurrency.Caption = ""
        Me.cmbCurrency.CaptionHeight = 17
        Me.cmbCurrency.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbCurrency.ColumnCaptionHeight = 17
        Me.cmbCurrency.ColumnFooterHeight = 17
        Me.cmbCurrency.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbCurrency.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbCurrency.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbCurrency.Images.Add(CType(resources.GetObject("cmbCurrency.Images"), System.Drawing.Image))
        Me.cmbCurrency.ItemHeight = 15
        Me.cmbCurrency.Location = New System.Drawing.Point(656, 91)
        Me.cmbCurrency.MatchEntryTimeout = CType(2000, Long)
        Me.cmbCurrency.MaxDropDownItems = CType(5, Short)
        Me.cmbCurrency.MaxLength = 32767
        Me.cmbCurrency.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbCurrency.Name = "cmbCurrency"
        Me.cmbCurrency.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbCurrency.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbCurrency.Size = New System.Drawing.Size(96, 21)
        Me.cmbCurrency.TabIndex = 3
        Me.cmbCurrency.PropBag = resources.GetString("cmbCurrency.PropBag")
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(567, 95)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(49, 13)
        Me.Label15.TabIndex = 218
        Me.Label15.Text = "Currency"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(5, 148)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(73, 13)
        Me.Label13.TabIndex = 213
        Me.Label13.Text = "Packing Type"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(349, 173)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(28, 13)
        Me.Label10.TabIndex = 207
        Me.Label10.Text = "ETA"
        '
        'txtETA
        '
        Me.txtETA.AllowSpinLoop = False
        Me.txtETA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtETA.Calendar.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtETA.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtETA.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtETA.Culture = 1056
        Me.txtETA.CustomFormat = "dd/MM/yyyy"
        Me.txtETA.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtETA.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtETA.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtETA.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtETA.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtETA.Location = New System.Drawing.Point(431, 170)
        Me.txtETA.Name = "txtETA"
        Me.txtETA.Size = New System.Drawing.Size(126, 19)
        Me.txtETA.TabIndex = 12
        Me.txtETA.Tag = Nothing
        Me.txtETA.TrimEnd = False
        Me.txtETA.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtETA.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtETA.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(349, 148)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(29, 13)
        Me.Label9.TabIndex = 205
        Me.Label9.Text = "ETD"
        '
        'txtETD
        '
        Me.txtETD.AllowSpinLoop = False
        Me.txtETD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtETD.Calendar.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtETD.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtETD.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtETD.Culture = 1056
        Me.txtETD.CustomFormat = "dd/MM/yyyy"
        Me.txtETD.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtETD.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtETD.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtETD.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtETD.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtETD.Location = New System.Drawing.Point(431, 145)
        Me.txtETD.Name = "txtETD"
        Me.txtETD.Size = New System.Drawing.Size(126, 19)
        Me.txtETD.TabIndex = 11
        Me.txtETD.Tag = Nothing
        Me.txtETD.TrimEnd = False
        Me.txtETD.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtETD.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtETD.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'txtDescription
        '
        Me.txtDescription.Location = New System.Drawing.Point(98, 118)
        Me.txtDescription.MaxLength = 300
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(226, 20)
        Me.txtDescription.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(5, 122)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 199
        Me.Label5.Text = "Description"
        '
        'txtDeliveryTerms
        '
        Me.txtDeliveryTerms.Location = New System.Drawing.Point(431, 91)
        Me.txtDeliveryTerms.Name = "txtDeliveryTerms"
        Me.txtDeliveryTerms.Size = New System.Drawing.Size(126, 20)
        Me.txtDeliveryTerms.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(349, 95)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(77, 13)
        Me.Label4.TabIndex = 197
        Me.Label4.Text = "Delivery Terms"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(5, 16)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(40, 13)
        Me.Label20.TabIndex = 195
        Me.Label20.Text = "Project"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(5, 95)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(80, 13)
        Me.Label3.TabIndex = 195
        Me.Label3.Text = "Payment Terms"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(349, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 193
        Me.Label2.Text = "PO Date"
        '
        'txtPoDate
        '
        Me.txtPoDate.AllowSpinLoop = False
        Me.txtPoDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        '
        '
        '
        Me.txtPoDate.Calendar.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtPoDate.Calendar.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtPoDate.Calendar.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtPoDate.Culture = 1056
        Me.txtPoDate.CustomFormat = "dd/MM/yyyy"
        Me.txtPoDate.DisplayFormat.CustomFormat = "dd/MM/yyyy"
        Me.txtPoDate.DisplayFormat.Inherit = CType(((((C1.Win.C1Input.FormatInfoInheritFlags.FormatType Or C1.Win.C1Input.FormatInfoInheritFlags.NullText) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.EmptyAsNull) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimStart) _
            Or C1.Win.C1Input.FormatInfoInheritFlags.TrimEnd), C1.Win.C1Input.FormatInfoInheritFlags)
        Me.txtPoDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPoDate.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate
        Me.txtPoDate.ImagePadding = New System.Windows.Forms.Padding(0)
        Me.txtPoDate.Location = New System.Drawing.Point(431, 64)
        Me.txtPoDate.Name = "txtPoDate"
        Me.txtPoDate.Size = New System.Drawing.Size(126, 19)
        Me.txtPoDate.TabIndex = 1
        Me.txtPoDate.Tag = Nothing
        Me.txtPoDate.TrimEnd = False
        Me.txtPoDate.Value = New Date(2007, 8, 22, 0, 0, 0, 0)
        Me.txtPoDate.VisualStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        Me.txtPoDate.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Blue
        '
        'cmdVendorList
        '
        Me.cmdVendorList.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdVendorList.Image = Global.General_Ledger.My.Resources.Resources.Find_Small
        Me.cmdVendorList.Location = New System.Drawing.Point(300, 62)
        Me.cmdVendorList.Name = "cmdVendorList"
        Me.cmdVendorList.Size = New System.Drawing.Size(22, 23)
        Me.cmdVendorList.TabIndex = 192
        Me.cmdVendorList.UseVisualStyleBackColor = True
        '
        'cmbSupplier
        '
        Me.cmbSupplier.AddItemSeparator = Global.Microsoft.VisualBasic.ChrW(59)
        Me.cmbSupplier.Caption = ""
        Me.cmbSupplier.CaptionHeight = 17
        Me.cmbSupplier.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.cmbSupplier.ColumnCaptionHeight = 17
        Me.cmbSupplier.ColumnFooterHeight = 17
        Me.cmbSupplier.DeadAreaBackColor = System.Drawing.Color.Empty
        Me.cmbSupplier.EditorBackColor = System.Drawing.SystemColors.Window
        Me.cmbSupplier.EditorForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbSupplier.Images.Add(CType(resources.GetObject("cmbSupplier.Images"), System.Drawing.Image))
        Me.cmbSupplier.ItemHeight = 15
        Me.cmbSupplier.Location = New System.Drawing.Point(98, 63)
        Me.cmbSupplier.MatchEntryTimeout = CType(2000, Long)
        Me.cmbSupplier.MaxDropDownItems = CType(5, Short)
        Me.cmbSupplier.MaxLength = 32767
        Me.cmbSupplier.MouseCursor = System.Windows.Forms.Cursors.Default
        Me.cmbSupplier.Name = "cmbSupplier"
        Me.cmbSupplier.ReadOnly = True
        Me.cmbSupplier.RowDivider.Style = C1.Win.C1List.LineStyleEnum.None
        Me.cmbSupplier.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.cmbSupplier.Size = New System.Drawing.Size(204, 21)
        Me.cmbSupplier.TabIndex = 2
        Me.cmbSupplier.PropBag = resources.GetString("cmbSupplier.PropBag")
        '
        'txtPoNo
        '
        Me.txtPoNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.txtPoNo.Location = New System.Drawing.Point(98, 38)
        Me.txtPoNo.Name = "txtPoNo"
        Me.txtPoNo.Size = New System.Drawing.Size(150, 20)
        Me.txtPoNo.TabIndex = 178
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(5, 67)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 186
        Me.Label6.Text = "Supplier"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 176
        Me.Label1.Text = "PO #"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1})
        Me.ToolStrip1.Location = New System.Drawing.Point(9, 1)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Padding = New System.Windows.Forms.Padding(0, 0, 2, 0)
        Me.ToolStrip1.Size = New System.Drawing.Size(762, 64)
        Me.ToolStrip1.TabIndex = 169
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Trebuchet MS", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel1.ForeColor = System.Drawing.SystemColors.Desktop
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(303, 61)
        Me.ToolStripLabel1.Text = "Pur. Order Product"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(11, 393)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(757, 227)
        Me.TabControl1.TabIndex = 178
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.cmdPickRequisition)
        Me.TabPage1.Controls.Add(Me.tdbColor)
        Me.TabPage1.Controls.Add(Me.tdbProduct)
        Me.TabPage1.Controls.Add(Me.tdbGridOrderDetail)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(749, 201)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Order Details"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'cmdPickRequisition
        '
        Me.cmdPickRequisition.Location = New System.Drawing.Point(7, 173)
        Me.cmdPickRequisition.Name = "cmdPickRequisition"
        Me.cmdPickRequisition.Size = New System.Drawing.Size(110, 23)
        Me.cmdPickRequisition.TabIndex = 33
        Me.cmdPickRequisition.Text = "Pick Requisition"
        Me.cmdPickRequisition.UseVisualStyleBackColor = True
        '
        'tdbColor
        '
        Me.tdbColor.AllowColMove = True
        Me.tdbColor.AllowColSelect = True
        Me.tdbColor.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbColor.AlternatingRows = False
        Me.tdbColor.CaptionStyle = Style1
        Me.tdbColor.ColumnCaptionHeight = 17
        Me.tdbColor.ColumnFooterHeight = 17
        Me.tdbColor.ColumnSelectorStyle = Style2
        Me.tdbColor.EvenRowStyle = Style3
        Me.tdbColor.FetchRowStyles = False
        Me.tdbColor.FooterStyle = Style4
        Me.tdbColor.HeadingStyle = Style5
        Me.tdbColor.HighLightRowStyle = Style6
        Me.tdbColor.Images.Add(CType(resources.GetObject("tdbColor.Images"), System.Drawing.Image))
        Me.tdbColor.Location = New System.Drawing.Point(223, 37)
        Me.tdbColor.Name = "tdbColor"
        Me.tdbColor.OddRowStyle = Style7
        Me.tdbColor.RecordSelectorStyle = Style8
        Me.tdbColor.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbColor.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbColor.RowSelectorStyle = Style9
        Me.tdbColor.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbColor.ScrollTips = False
        Me.tdbColor.Size = New System.Drawing.Size(388, 206)
        Me.tdbColor.Style = Style10
        Me.tdbColor.TabIndex = 178
        Me.tdbColor.TabStop = False
        Me.tdbColor.Text = "C1TrueDBDropdown1"
        Me.tdbColor.UseCompatibleTextRendering = False
        Me.tdbColor.ValueTranslate = True
        Me.tdbColor.Visible = False
        Me.tdbColor.PropBag = resources.GetString("tdbColor.PropBag")
        '
        'tdbProduct
        '
        Me.tdbProduct.AllowColMove = True
        Me.tdbProduct.AllowColSelect = True
        Me.tdbProduct.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows
        Me.tdbProduct.AlternatingRows = False
        Me.tdbProduct.CaptionStyle = Style11
        Me.tdbProduct.ColumnCaptionHeight = 17
        Me.tdbProduct.ColumnFooterHeight = 17
        Me.tdbProduct.ColumnSelectorStyle = Style12
        Me.tdbProduct.EvenRowStyle = Style13
        Me.tdbProduct.FetchRowStyles = False
        Me.tdbProduct.FooterStyle = Style14
        Me.tdbProduct.HeadingStyle = Style15
        Me.tdbProduct.HighLightRowStyle = Style16
        Me.tdbProduct.Images.Add(CType(resources.GetObject("tdbProduct.Images"), System.Drawing.Image))
        Me.tdbProduct.Location = New System.Drawing.Point(117, 25)
        Me.tdbProduct.Name = "tdbProduct"
        Me.tdbProduct.OddRowStyle = Style17
        Me.tdbProduct.RecordSelectorStyle = Style18
        Me.tdbProduct.RowDivider.Color = System.Drawing.Color.DarkGray
        Me.tdbProduct.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.[Single]
        Me.tdbProduct.RowSelectorStyle = Style19
        Me.tdbProduct.RowSubDividerColor = System.Drawing.Color.DarkGray
        Me.tdbProduct.ScrollTips = False
        Me.tdbProduct.Size = New System.Drawing.Size(388, 209)
        Me.tdbProduct.Style = Style20
        Me.tdbProduct.TabIndex = 186
        Me.tdbProduct.TabStop = False
        Me.tdbProduct.Text = "C1TrueDBDropdown1"
        Me.tdbProduct.UseCompatibleTextRendering = False
        Me.tdbProduct.ValueTranslate = True
        Me.tdbProduct.Visible = False
        Me.tdbProduct.PropBag = resources.GetString("tdbProduct.PropBag")
        '
        'tdbGridOrderDetail
        '
        Me.tdbGridOrderDetail.AllowDelete = True
        Me.tdbGridOrderDetail.ColumnFooters = True
        Me.tdbGridOrderDetail.EmptyRows = True
        Me.tdbGridOrderDetail.GroupByCaption = "Drag a column header here to group by that column"
        Me.tdbGridOrderDetail.Images.Add(CType(resources.GetObject("tdbGridOrderDetail.Images"), System.Drawing.Image))
        Me.tdbGridOrderDetail.Images.Add(CType(resources.GetObject("tdbGridOrderDetail.Images1"), System.Drawing.Image))
        Me.tdbGridOrderDetail.Images.Add(CType(resources.GetObject("tdbGridOrderDetail.Images2"), System.Drawing.Image))
        Me.tdbGridOrderDetail.Location = New System.Drawing.Point(9, 6)
        Me.tdbGridOrderDetail.Name = "tdbGridOrderDetail"
        Me.tdbGridOrderDetail.PreviewInfo.Location = New System.Drawing.Point(0, 0)
        Me.tdbGridOrderDetail.PreviewInfo.Size = New System.Drawing.Size(0, 0)
        Me.tdbGridOrderDetail.PreviewInfo.ZoomFactor = 75.0R
        Me.tdbGridOrderDetail.PrintInfo.MeasurementDevice = C1.Win.C1TrueDBGrid.PrintInfo.MeasurementDeviceEnum.Screen
        Me.tdbGridOrderDetail.PrintInfo.MeasurementPrinterName = Nothing
        Me.tdbGridOrderDetail.PrintInfo.PageSettings = CType(resources.GetObject("tdbGridOrderDetail.PrintInfo.PageSettings"), System.Drawing.Printing.PageSettings)
        Me.tdbGridOrderDetail.RecordSelectors = False
        Me.tdbGridOrderDetail.Size = New System.Drawing.Size(737, 164)
        Me.tdbGridOrderDetail.TabIndex = 179
        Me.tdbGridOrderDetail.Text = "C1TrueDBGrid1"
        Me.tdbGridOrderDetail.UseCompatibleTextRendering = False
        Me.tdbGridOrderDetail.VisualStyle = C1.Win.C1TrueDBGrid.VisualStyle.Office2007Silver
        Me.tdbGridOrderDetail.WrapCellPointer = True
        Me.tdbGridOrderDetail.PropBag = resources.GetString("tdbGridOrderDetail.PropBag")
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.txtSpecialInstructions)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(749, 201)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Special Instructions"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txtSpecialInstructions
        '
        Me.txtSpecialInstructions.Location = New System.Drawing.Point(6, 6)
        Me.txtSpecialInstructions.Name = "txtSpecialInstructions"
        Me.txtSpecialInstructions.Size = New System.Drawing.Size(737, 174)
        Me.txtSpecialInstructions.TabIndex = 0
        Me.txtSpecialInstructions.Text = ""
        '
        'lblFlag
        '
        Me.lblFlag.Font = New System.Drawing.Font("Calibri", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFlag.ForeColor = System.Drawing.Color.Red
        Me.lblFlag.Location = New System.Drawing.Point(14, 63)
        Me.lblFlag.Name = "lblFlag"
        Me.lblFlag.Size = New System.Drawing.Size(758, 33)
        Me.lblFlag.TabIndex = 182
        Me.lblFlag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdPrint
        '
        Me.cmdPrint.Image = Global.General_Ledger.My.Resources.Resources.folder_document
        Me.cmdPrint.Location = New System.Drawing.Point(363, 4)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.Size = New System.Drawing.Size(51, 56)
        Me.cmdPrint.TabIndex = 180
        Me.cmdPrint.Text = "&Print"
        Me.cmdPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdPrint.UseVisualStyleBackColor = True
        '
        'cmdAdd
        '
        Me.cmdAdd.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdAdd.Image = Global.General_Ledger.My.Resources.Resources.folder_add
        Me.cmdAdd.Location = New System.Drawing.Point(467, 4)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(51, 56)
        Me.cmdAdd.TabIndex = 0
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdAdd.UseVisualStyleBackColor = True
        '
        'cmdExit
        '
        Me.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdExit.Image = Global.General_Ledger.My.Resources.Resources.folder_out
        Me.cmdExit.Location = New System.Drawing.Point(723, 4)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(51, 56)
        Me.cmdExit.TabIndex = 176
        Me.cmdExit.Text = "E&xit"
        Me.cmdExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdExit.UseVisualStyleBackColor = True
        '
        'cmdUndo
        '
        Me.cmdUndo.Image = Global.General_Ledger.My.Resources.Resources.folder_refresh
        Me.cmdUndo.Location = New System.Drawing.Point(671, 4)
        Me.cmdUndo.Name = "cmdUndo"
        Me.cmdUndo.Size = New System.Drawing.Size(51, 56)
        Me.cmdUndo.TabIndex = 175
        Me.cmdUndo.Text = "&Undo"
        Me.cmdUndo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdUndo.UseVisualStyleBackColor = True
        '
        'cmdSearch
        '
        Me.cmdSearch.Image = Global.General_Ledger.My.Resources.Resources.folder_view
        Me.cmdSearch.Location = New System.Drawing.Point(415, 4)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.Size = New System.Drawing.Size(51, 56)
        Me.cmdSearch.TabIndex = 171
        Me.cmdSearch.Text = "Searc&h"
        Me.cmdSearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdSearch.UseVisualStyleBackColor = True
        '
        'cmdEdit
        '
        Me.cmdEdit.Image = Global.General_Ledger.My.Resources.Resources.folder_edit
        Me.cmdEdit.Location = New System.Drawing.Point(518, 4)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(51, 56)
        Me.cmdEdit.TabIndex = 173
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdEdit.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Image = Global.General_Ledger.My.Resources.Resources.folder_new
        Me.cmdSave.Location = New System.Drawing.Point(569, 4)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(51, 56)
        Me.cmdSave.TabIndex = 172
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cmdDelete
        '
        Me.cmdDelete.Image = Global.General_Ledger.My.Resources.Resources.folder_delete
        Me.cmdDelete.Location = New System.Drawing.Point(620, 4)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(51, 56)
        Me.cmdDelete.TabIndex = 174
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdDelete.UseVisualStyleBackColor = True
        '
        'frmPurOrderProduct
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(778, 628)
        Me.Controls.Add(Me.lblFlag)
        Me.Controls.Add(Me.cmdPrint)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmdAdd)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.cmdUndo)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.ToolStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.Name = "frmPurOrderProduct"
        Me.Text = "Purchase Order Product"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.txtCloseDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbPackingType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbPaymentTerms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtBalancePayment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNetAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTransportationCharges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSalesTax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDiscount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGrossAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAdvanceAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAdvancePer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCancelDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbDepartment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbCurrency, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtETA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtETD, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPoDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbSupplier, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.tdbColor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbProduct, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbGridOrderDetail, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbCurrency As C1.Win.C1List.C1Combo
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtETA As C1.Win.C1Input.C1DateEdit
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtETD As C1.Win.C1Input.C1DateEdit
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtDeliveryTerms As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtPoDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents cmdVendorList As System.Windows.Forms.Button
    Friend WithEvents cmbSupplier As C1.Win.C1List.C1Combo
    Friend WithEvents txtPoNo As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents cmdExit As System.Windows.Forms.Button
    Friend WithEvents cmdUndo As System.Windows.Forms.Button
    Friend WithEvents cmdSearch As System.Windows.Forms.Button
    Friend WithEvents cmdEdit As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents tdbProduct As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents tdbGridOrderDetail As C1.Win.C1TrueDBGrid.C1TrueDBGrid
    Friend WithEvents tdbColor As C1.Win.C1TrueDBGrid.C1TrueDBDropdown
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents txtSpecialInstructions As System.Windows.Forms.RichTextBox
    Friend WithEvents cmdPrint As System.Windows.Forms.Button
    Friend WithEvents cmdPickRequisition As System.Windows.Forms.Button
    Friend WithEvents cmbDepartment As C1.Win.C1List.C1Combo
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents chkClosed As System.Windows.Forms.CheckBox
    Friend WithEvents cmbLocalImport As System.Windows.Forms.ComboBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents cmdCancel As Button
    Friend WithEvents txtCancelUser As TextBox
    Friend WithEvents txtCancelDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents Label8 As Label
    Friend WithEvents txtCancelRemarks As TextBox
    Friend WithEvents chkCancel As CheckBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtAdvanceAmount As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents txtAdvancePer As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents txtBalancePayment As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txtNetAmount As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label17 As Label
    Friend WithEvents txtTransportationCharges As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label16 As Label
    Friend WithEvents txtSalesTax As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label14 As Label
    Friend WithEvents txtDiscount As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents Label12 As Label
    Friend WithEvents txtGrossAmount As C1.Win.C1Input.C1NumericEdit
    Friend WithEvents chkWithoutGST As CheckBox
    Friend WithEvents txtGeneratedBy As TextBox
    Friend WithEvents lblFlag As Label
    Friend WithEvents cmbPaymentTerms As C1.Win.C1List.C1Combo
    Friend WithEvents cmbPackingType As C1.Win.C1List.C1Combo
    Friend WithEvents chkFinalized As CheckBox
    Friend WithEvents cmdClosed As Button
    Friend WithEvents txtCloseUser As TextBox
    Friend WithEvents txtCloseDate As C1.Win.C1Input.C1DateEdit
    Friend WithEvents cmbProject As C1.Win.C1List.C1Combo
    Friend WithEvents Label20 As Label
End Class
